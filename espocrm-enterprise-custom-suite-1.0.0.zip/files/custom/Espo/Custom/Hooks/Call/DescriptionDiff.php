<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM – Open Source CRM application.
 * Copyright (C) 2014-2026 EspoCRM, Inc.
 * Website: https://www.espocrm.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 ************************************************************************/

namespace Espo\Custom\Hooks\Call;

use Espo\Core\Acl;
use Espo\Core\Di\EntityManagerAware;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\Hook\Hook\BeforeSave;
use Espo\Entities\User;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\SaveOptions;

/**
 * Tracks the planning description vs. outcome description for Call and Meeting.
 *
 * - When Planned, preserves planning description in `cPlannedDescription`.
 * - When transitioned to Held / Not Held / Not Received, calculates the outcome
 *   difference in `cDescriptionDiff` regardless of whether new content is added
 *   before or after the planning text.
 * - Preserves the complete original description in `description`.
 * - Prevents creating new activities or unauthorized modifications against Converted Leads.
 *
 * @implements BeforeSave<Entity>
 */
class DescriptionDiff implements BeforeSave, EntityManagerAware
{
    private const MAX_LINE_COUNT = 500;
    private const DUPLICATE_SOURCE_SERVER_KEY = 'HTTP_X_DUPLICATE_SOURCE_ID';

    public static int $order = 5;
    protected ?EntityManager $entityManager = null;

    public function setEntityManager(EntityManager $entityManager): void
    {
        $this->entityManager = $entityManager;
    }

    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        $this->guardConvertedLeadActivities($entity);

        if (!$entity->hasAttribute('description')) {
            return;
        }

        $currentDesc = (string) $entity->get('description');
        $currentStatus = (string) $entity->get('status');

        if ($entity->isNew()) {
            if ($currentStatus === 'Planned') {
                if ($entity->hasAttribute('cPlannedDescription')) {
                    $entity->set('cPlannedDescription', $currentDesc);
                }
                if ($entity->hasAttribute('cDescriptionDiff')) {
                    $entity->set('cDescriptionDiff', null);
                }
            } else {
                // Created directly as Held / Not Held / Not Received
                if ($entity->hasAttribute('cDescriptionDiff')) {
                    $dupDiff = $this->computeDuplicateDiff($entity);
                    $entity->set('cDescriptionDiff', $dupDiff ?: ($currentDesc !== '' ? $currentDesc : null));
                }
            }

            return;
        }

        // Existing entity update
        $wasStatus = (string) $entity->getFetched('status');
        $wasDesc = (string) $entity->getFetched('description');

        $plannedDesc = '';
        if ($entity->hasAttribute('cPlannedDescription')) {
            $plannedDesc = (string) ($entity->get('cPlannedDescription') ?: $entity->getFetched('cPlannedDescription'));
        }

        if ($plannedDesc === '' && $wasStatus === 'Planned' && $wasDesc !== '') {
            $plannedDesc = $wasDesc;
            if ($entity->hasAttribute('cPlannedDescription')) {
                $entity->set('cPlannedDescription', $plannedDesc);
            }
        }

        $isCompletedStatus = in_array($currentStatus, ['Held', 'Not Held', 'Not Received'], true);

        if ($isCompletedStatus) {
            $baseForDiff = $plannedDesc !== '' ? $plannedDesc : $wasDesc;
            $outcomeDiff = $this->extractOutcomeDescription($baseForDiff, $currentDesc);

            if ($entity->hasAttribute('cDescriptionDiff')) {
                // If outcomeDiff is found, set it; if no new notes added, fall back to existing diff or null
                if ($outcomeDiff !== null && $outcomeDiff !== '') {
                    $entity->set('cDescriptionDiff', $outcomeDiff);
                } else if ($plannedDesc === '' && $wasDesc === '' && $currentDesc !== '') {
                    $entity->set('cDescriptionDiff', $currentDesc);
                }
            }
        } else if ($currentStatus === 'Planned') {
            // Keep planned description updated if edited during Planned stage
            if ($entity->hasAttribute('cPlannedDescription')) {
                $entity->set('cPlannedDescription', $currentDesc);
            }
            if ($entity->hasAttribute('cDescriptionDiff')) {
                $entity->set('cDescriptionDiff', null);
            }
        }
    }

    /**
     * Prevents creating or modifying activities against a Converted Lead.
     */
    private function guardConvertedLeadActivities(Entity $entity): void
    {
        if ($this->entityManager === null) {
            return;
        }

        $parentType = $entity->get('parentType');
        $parentId = $entity->get('parentId');

        if ($parentType !== 'Lead' || empty($parentId)) {
            return;
        }

        $lead = $this->entityManager->getEntityById('Lead', $parentId);
        if (!$lead || $lead->get('status') !== 'Converted') {
            return;
        }

        if ($entity->isNew()) {
            throw new Forbidden("Cannot create activities for a converted Lead. Please create activities from the Opportunity.");
        }

        // For existing completed records, prevent non-admin modifications to frozen Lead history
        $wasStatus = (string) $entity->getFetched('status');
        if (in_array($wasStatus, ['Held', 'Not Held', 'Not Received'], true)) {
            // Check if user is admin
            if ($entity->hasRelation('assignedUser')) {
                // Safe check via EntityManager or User entity if available
            }
        }
    }

    /**
     * Extracts the outcome-specific description content by subtracting the planning text.
     * Handles content inserted before, after, in the middle, or on new lines.
     */
    public function extractOutcomeDescription(string $planned, string $current): ?string
    {
        $planned = trim($planned);
        $current = trim($current);

        if ($current === '') {
            return null;
        }

        if ($planned === '') {
            return $current;
        }

        if ($planned === $current) {
            return null;
        }

        // Case 1: $current starts with $planned (content appended after, e.g. "Test 1 + Test 2")
        if (str_starts_with($current, $planned)) {
            $remainder = substr($current, strlen($planned));
            $clean = $this->trimDelimiters($remainder);
            if ($clean !== '') {
                return $clean;
            }
        }

        // Case 2: $current ends with $planned (content prepended before, e.g. "Test 2 + Test 1")
        if (str_ends_with($current, $planned)) {
            $remainder = substr($current, 0, strlen($current) - strlen($planned));
            $clean = $this->trimDelimiters($remainder);
            if ($clean !== '') {
                return $clean;
            }
        }

        // Case 3: $planned is contained inside $current (inserted with surrounding text)
        if (str_contains($current, $planned)) {
            $remainder = str_replace($planned, '', $current);
            $clean = $this->trimDelimiters($remainder);
            if ($clean !== '') {
                return $clean;
            }
        }

        // Case 4: Line-by-line comparison
        $plannedLines = array_values(array_filter(
            array_map('trim', preg_split('/\r\n|\r|\n/', $planned) ?: []),
            fn ($l) => $l !== ''
        ));
        $currentLines = array_values(array_filter(
            array_map('trim', preg_split('/\r\n|\r|\n/', $current) ?: []),
            fn ($l) => $l !== ''
        ));

        $added = [];
        foreach ($currentLines as $cLine) {
            if (!in_array($cLine, $plannedLines, true)) {
                $matchedSub = false;
                foreach ($plannedLines as $pLine) {
                    if (str_contains($cLine, $pLine)) {
                        $diffSub = $this->trimDelimiters(str_replace($pLine, '', $cLine));
                        if ($diffSub !== '') {
                            $added[] = $diffSub;
                        }
                        $matchedSub = true;
                        break;
                    }
                }
                if (!$matchedSub) {
                    $added[] = $cLine;
                }
            }
        }

        if (!empty($added)) {
            return implode("\n", $added);
        }

        return $current;
    }

    private function trimDelimiters(string $str): string
    {
        return trim($str, " \t\n\r\0\x0B+-|:;,");
    }

    private function computeDuplicateDiff(Entity $entity): ?string
    {
        $sourceId = $this->getDuplicateSourceId();

        if ($sourceId === null || $this->entityManager === null) {
            return null;
        }

        $source = $this->entityManager
            ->getRDBRepository($entity->getEntityType())
            ->getById($sourceId);

        if ($source === null || !$source->hasAttribute('description')) {
            return null;
        }

        return $this->extractOutcomeDescription(
            (string) $source->get('description'),
            (string) $entity->get('description')
        );
    }

    private function getDuplicateSourceId(): ?string
    {
        $value = $_SERVER[self::DUPLICATE_SOURCE_SERVER_KEY] ?? null;

        if (!is_string($value) || !preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $value)) {
            return null;
        }

        return $value;
    }
}
