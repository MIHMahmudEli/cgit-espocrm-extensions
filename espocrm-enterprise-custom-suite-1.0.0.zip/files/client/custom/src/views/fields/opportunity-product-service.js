define('custom:views/fields/opportunity-product-service', ['views/fields/link'], function (Dep) {
    return Dep.extend({
        getSelectFilters: function () {
            return Object.assign({}, Dep.prototype.getSelectFilters.call(this) || {}, {
                active: {
                    type: 'equals',
                    attribute: 'status',
                    value: 'Active'
                }
            });
        },

        setup: function () {
            Dep.prototype.setup.call(this);

            var hasSubScope = Boolean(
                this.getMetadata() &&
                typeof this.getMetadata().hasScope === 'function' &&
                this.getMetadata().hasScope('CSubscriptionPlan')
            );
            if (!hasSubScope) {
                return;
            }

            // Sync cWonProductId whenever cProductService changes
            this.listenTo(this.model, 'change:cProductServiceId', function (model, id, options) {
                if (!options || !options.fromWonProduct) {
                    this.model.set({
                        cWonProductId: id || null,
                        cWonProductName: id ? this.model.get('cProductServiceName') : null
                    }, { fromProductService: true });
                }

                if (this.model.get('stage') === 'Closed Won') {
                    this.model.set({
                        cWonPlanId: null,
                        cWonPlanName: null,
                        cWonPlanPrice: null,
                        cWonPeriod: null,
                        cWonInitialTotal: null
                    }, { ui: true, fromField: 'cProductService' });
                }

                if (id && /^[a-z0-9]{17}$/i.test(id)) {
                    this.checkAndPromptPlans(id);
                }
            });

            // When stage changes to Closed Won, check if product has subscriptions and open popup
            this.listenTo(this.model, 'change:stage', function (model, stage, options) {
                if (stage === 'Closed Won') {
                    var productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                    if (productId) {
                        this.model.set({
                            cWonProductId: productId,
                            cWonProductName: this.model.get('cProductServiceName')
                        }, { fromProductService: true });

                        if (!this.model.get('cWonPlanId')) {
                            this.checkAndPromptPlans(productId);
                        }
                    }
                }
            });
        },

        checkAndPromptPlans: async function (productId) {
            var hasSubScope = Boolean(
                this.getMetadata() &&
                typeof this.getMetadata().hasScope === 'function' &&
                this.getMetadata().hasScope('CSubscriptionPlan')
            );
            if (!hasSubScope || !productId || !/^[a-z0-9]{17}$/i.test(productId)) {
                return;
            }
            try {
                var res = await Espo.Ajax.getRequest('CSubscriptionPlan', {
                    where: [
                        { type: 'equals', attribute: 'productId', value: productId },
                        { type: 'equals', attribute: 'status', value: 'Active' }
                    ],
                    maxSize: 20
                }, { returnError: true });
                if (!res) return;
                var list = res.list || [];
                var total = (typeof res.total === 'number') ? res.total : list.length;

                if (total === 1 && list.length === 1) {
                    var singlePlan = list[0];
                    var values = {
                        cWonPlanId: singlePlan.id,
                        cWonPlanName: singlePlan.name
                    };
                    if (singlePlan.monthlyPrice != null) {
                        values.cWonPlanPrice = singlePlan.monthlyPrice;
                        values.cWonPlanPriceCurrency = singlePlan.monthlyPriceCurrency;
                    }
                    if (singlePlan.billingPeriod) {
                        values.cWonPeriod = singlePlan.billingPeriod;
                    }
                    this.model.set(values, { ui: true, fromField: 'opportunityProductService' });

                    var parentView = typeof this.getParentView === 'function' ? this.getParentView() : null;
                    if (parentView && typeof parentView.syncWonPlanFieldUI === 'function') {
                        parentView.syncWonPlanFieldUI(singlePlan.id, singlePlan.name);
                    } else {
                        var planFieldView = parentView && typeof parentView.getFieldView === 'function' ? parentView.getFieldView('cWonPlan') : null;
                        if (planFieldView) {
                            if (planFieldView.$elementName) planFieldView.$elementName.val(singlePlan.name);
                            if (planFieldView.$elementId) planFieldView.$elementId.val(singlePlan.id);
                            if (typeof planFieldView.loadPlan === 'function') planFieldView.loadPlan();
                            else if (typeof planFieldView.reRender === 'function') planFieldView.reRender();
                        }
                    }
                } else if (total > 1 || list.length > 1) {
                    this.openPlanPicker(productId);
                }
            } catch (e) {
                // Non-blocking warning only
                console.warn('Subscription plans check skipped or unavailable:', e);
            }
        },

        openPlanPicker: async function (productId) {
            var hasSubScope = Boolean(
                this.getMetadata() &&
                typeof this.getMetadata().hasScope === 'function' &&
                this.getMetadata().hasScope('CSubscriptionPlan')
            );
            if (!hasSubScope || !productId || !/^[a-z0-9]{17}$/i.test(productId)) {
                return;
            }
            if (this.hasView('wonPlanPicker') || this.isOpeningPlanPicker) {
                return;
            }
            this.isOpeningPlanPicker = true;

            var onPlanSelected = (record) => {
                this.isOpeningPlanPicker = false;
                if (Array.isArray(record)) record = record[0];
                if (!record) return;
                var currentProductId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                if (currentProductId !== productId) {
                    return;
                }

                var planId = record.id || (typeof record.get === 'function' ? record.get('id') : null);
                var planName = (typeof record.get === 'function' ? record.get('name') : record.name) || '';
                var planPrice = typeof record.get === 'function' ? record.get('monthlyPrice') : record.monthlyPrice;
                var planCurrency = typeof record.get === 'function' ? record.get('monthlyPriceCurrency') : record.monthlyPriceCurrency;
                var planPeriod = typeof record.get === 'function' ? record.get('billingPeriod') : record.billingPeriod;

                var values = {
                    cWonPlanId: planId,
                    cWonPlanName: planName
                };
                if (planPrice != null) {
                    values.cWonPlanPrice = planPrice;
                    values.cWonPlanPriceCurrency = planCurrency;
                }
                if (planPeriod) {
                    values.cWonPeriod = planPeriod;
                }
                this.model.set(values, { ui: true, fromField: 'opportunityProductService' });

                var parentView = typeof this.getParentView === 'function' ? this.getParentView() : null;
                if (parentView && typeof parentView.syncWonPlanFieldUI === 'function') {
                    parentView.syncWonPlanFieldUI(planId, planName);
                } else {
                    var planFieldView = parentView && typeof parentView.getFieldView === 'function' ? parentView.getFieldView('cWonPlan') : null;
                    if (planFieldView) {
                        if (planFieldView.$elementName) planFieldView.$elementName.val(planName);
                        if (planFieldView.$elementId) planFieldView.$elementId.val(planId);
                        if (typeof planFieldView.loadPlan === 'function') {
                            planFieldView.loadPlan();
                        } else if (typeof planFieldView.reRender === 'function') {
                            planFieldView.reRender();
                        }
                    }
                }
            };

            try {
                var modal = await this.createView('wonPlanPicker', 'views/modals/select-records', {
                    scope: 'CSubscriptionPlan',
                    multiple: false,
                    createButton: false,
                    filters: {
                        product: { type: 'equals', attribute: 'productId', value: productId },
                        active: { type: 'equals', attribute: 'status', value: 'Active' }
                    },
                    onSelect: onPlanSelected
                });
                this.listenToOnce(modal, 'select', onPlanSelected);
                this.listenToOnce(modal, 'close remove', () => {
                    this.isOpeningPlanPicker = false;
                });
                await modal.render();
            } catch (e) {
                this.isOpeningPlanPicker = false;
                Espo.Ui.error('Could not open plans for this product. Select the Subscription Plan field to try again.');
            }
        }
    });
});
