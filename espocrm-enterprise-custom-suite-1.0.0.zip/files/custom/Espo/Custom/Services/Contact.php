<?php
namespace Espo\Custom\Services;

use Espo\Core\Record\Collection as RecordCollection;
use Espo\Core\Select\SearchParams;
use Espo\Core\Acl\Table as AclTable;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\Exceptions\NotFound;

class Contact extends \Espo\Services\Record
{
    public function findLinked(string $id, string $link, SearchParams $searchParams): RecordCollection
    {
        if ($link === 'cSubscriptions') {
            return $this->findLinkedSubscriptions($id, $searchParams);
        }

        return parent::findLinked($id, $link, $searchParams);
    }

    private function findLinkedSubscriptions(string $contactId, SearchParams $searchParams): RecordCollection
    {
        $contact = $this->getRepository()->getById($contactId);
        if (!$contact) {
            throw new NotFound();
        }

        if (!$this->acl->check($contact, AclTable::ACTION_READ)) {
            throw new Forbidden();
        }

        $whereOr = [
            [
                'clientType' => 'Contact',
                'clientId' => $contactId
            ]
        ];

        $accountId = $contact->get('accountId');
        if ($accountId) {
            $whereOr[] = [
                'clientType' => 'Account',
                'clientId' => $accountId
            ];
        }

        // Also find by opportunities associated with this contact
        $opps = $this->entityManager->getRDBRepository('Opportunity')
            ->select(['id'])
            ->where([
                'contactId' => $contactId,
                'deleted' => 0
            ])
            ->find();
        $oppIds = [];
        foreach ($opps as $o) {
            $oppIds[] = $o->getId();
        }
        if (!empty($oppIds)) {
            $whereOr[] = [
                'cWonOpportunityId' => $oppIds
            ];
        }

        $subRepo = $this->entityManager->getRDBRepository('CClientSubscription');
        $queryBuilder = $subRepo->where([
            'deleted' => 0,
            'OR' => $whereOr
        ]);

        $total = $queryBuilder->count();

        $maxSize = $searchParams->getMaxSize() ?: 20;
        $offset = $searchParams->getOffset() ?: 0;
        $orderBy = $searchParams->getOrderBy() ?: 'createdAt';
        $order = $searchParams->getOrder() ?: 'desc';

        $queryBuilder->limit($offset, $maxSize);
        $queryBuilder->order($orderBy, $order);

        $collection = $queryBuilder->find();

        $recordService = $this->recordServiceContainer->get('CClientSubscription');
        foreach ($collection as $itemEntity) {
            $recordService->prepareEntityForOutput($itemEntity);
        }

        return RecordCollection::create($collection, $total);
    }
}
