<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);


            // Configure CRM-wide Bangladeshi Time (Asia/Dhaka) and 12-hour AM/PM format (Reports, Imports, Call Start/End, Date Start)
            $configWriter->set('timeZone', 'Asia/Dhaka');
            $configWriter->set('timeFormat', 'hh:mm A');
            $configWriter->save();

            // Safely merge calendar-week.css into app/client.json without clobbering other extensions' CSS
            $clientJsonFile = 'custom/Espo/Custom/Resources/metadata/app/client.json';
            $clientData = [];
            if (file_exists($clientJsonFile)) {
                $decoded = @json_decode(file_get_contents($clientJsonFile), true);
                if (is_array($decoded)) $clientData = $decoded;
            }
            $cssList = $clientData['cssList'] ?? [];
            if (!in_array('client/custom/css/calendar-week.css', $cssList)) {
                $cssList[] = 'client/custom/css/calendar-week.css';
                $clientData['cssList'] = array_values($cssList);
                if (!is_dir(dirname($clientJsonFile))) @mkdir(dirname($clientJsonFile), 0777, true);
                @file_put_contents($clientJsonFile, json_encode($clientData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            }

            // Safely merge lead-source custom view into entityDefs/Lead.json without clobbering Product/Subscription fields
            $leadEntityFile = 'custom/Espo/Custom/Resources/metadata/entityDefs/Lead.json';
            $leadEntityDef = [];
            if (file_exists($leadEntityFile)) {
                $decoded = @json_decode(file_get_contents($leadEntityFile), true);
                if (is_array($decoded)) $leadEntityDef = $decoded;
            }
            if (!isset($leadEntityDef['fields']) || !is_array($leadEntityDef['fields'])) {
                $leadEntityDef['fields'] = [];
            }
            if (!isset($leadEntityDef['fields']['source']) || !is_array($leadEntityDef['fields']['source'])) {
                $leadEntityDef['fields']['source'] = [];
            }
            $leadEntityDef['fields']['source']['view'] = 'custom:views/fields/lead-source';
            if (!is_dir(dirname($leadEntityFile))) @mkdir(dirname($leadEntityFile), 0777, true);
            @file_put_contents($leadEntityFile, json_encode($leadEntityDef, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

            // Safely merge tasks prefill into clientDefs/Lead.json without clobbering Product/Subscription panels
            $leadDefFile = 'custom/Espo/Custom/Resources/metadata/clientDefs/Lead.json';
            $leadDef = [];
            if (file_exists($leadDefFile)) {
                $decoded = @json_decode(file_get_contents($leadDefFile), true);
                if (is_array($decoded)) $leadDef = $decoded;
            }
            if (!isset($leadDef['relationshipPanels']) || !is_array($leadDef['relationshipPanels'])) {
                $leadDef['relationshipPanels'] = [];
            }
            $leadDef['relationshipPanels']['tasks'] = [
                'createAttributeMap' => ['name' => 'name'],
                'createHandler' => 'custom:handlers/create-task-prefill'
            ];
            if (!is_dir(dirname($leadDefFile))) @mkdir(dirname($leadDefFile), 0777, true);
            @file_put_contents($leadDefFile, json_encode($leadDef, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

            // Wire Assigned User auto-fill preparator on Account, Contact, Lead, Opportunity create routes
            foreach (['Account', 'Contact', 'Lead', 'Opportunity'] as $scopeName) {
                $cdFile = "custom/Espo/Custom/Resources/metadata/clientDefs/{$scopeName}.json";
                $cdData = [];
                if (file_exists($cdFile)) {
                    $decoded = @json_decode(file_get_contents($cdFile), true);
                    if (is_array($decoded)) $cdData = $decoded;
                }
                $cdData['modelDefaultsPreparator'] = 'custom:handlers/sales-defaults-preparator';
                if (!is_dir(dirname($cdFile))) @mkdir(dirname($cdFile), 0777, true);
                @file_put_contents($cdFile, json_encode($cdData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            }
        
        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
