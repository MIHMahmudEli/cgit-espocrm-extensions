<?php
namespace Espo\Custom\Hooks\Opportunity;

use Espo\Core\Acl;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\Record\ServiceContainer;
use Espo\Entities\User;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\SaveOptions;

class FulfillSubscription implements \Espo\Core\Hook\Hook\BeforeSave, \Espo\Core\Hook\Hook\AfterSave
{
    public static int $order = 10;

    public function __construct(
        private EntityManager $em,
        private Acl $acl,
        private ServiceContainer $services,
        private User $user
    ) {}

    private function client(Entity $e): array
    {
        $type = null;
        $id = null;
        if ($e->get('accountId')) {
            $type = 'Account';
            $id = $e->get('accountId');
        } elseif ($e->get('contactId')) {
            $type = 'Contact';
            $id = $e->get('contactId');
        } else {
            $contactsIds = $e->getLinkMultipleIdList('contacts');
            if (!empty($contactsIds)) {
                $type = 'Contact';
                $id = $contactsIds[0];
            }
        }
        $client = ($type && $id) ? $this->em->getEntityById($type, $id) : null;
        if (!$client) {
            throw new BadRequest('Closed Won requires an Account or a Contact for the subscription.');
        }
        if (!$this->acl->checkEntityRead($client)) {
            throw new Forbidden('No access to the subscription client.');
        }
        return [$type, $id];
    }

    public function beforeSave(Entity $e, SaveOptions $options): void
    {
        if ($e->get('stage') !== 'Closed Won') return;
        $productId = $e->get('cProductServiceId') ?: $e->get('cWonProductId');
        if ($productId) {
            $e->set('cProductServiceId', $productId);
            $e->set('cWonProductId', $productId);
        }
        $product = $productId ? $this->em->getEntityById('CProductService', $productId) : null;
        if ($product && $product->get('type') !== 'Subscription') {
            return;
        }
        if ($e->get('contactId') && empty($e->getLinkMultipleIdList('contacts'))) {
            $e->set('contactsIds', [$e->get('contactId')]);
        }
        if (!$e->get('contactId')) {
            $contactsIds = $e->getLinkMultipleIdList('contacts');
            if (!empty($contactsIds)) {
                $e->set('contactId', $contactsIds[0]);
            }
        }
        $this->client($e);
        if (!$e->get('cWonStartDate')) {
            $e->set('cWonStartDate', $e->get('closeDate') ?: date('Y-m-d'));
        }
        if (!$e->get('cWonStartDate')) {
            throw new BadRequest('A subscription effective date is required.');
        }
    }

    public function afterSave(Entity $e, SaveOptions $options): void
    {
        if ($e->get('stage') !== 'Closed Won') return;
        $productId = $e->get('cProductServiceId') ?: $e->get('cWonProductId');
        $product = $productId ? $this->em->getEntityById('CProductService', $productId) : null;
        if ($product && $product->get('type') !== 'Subscription') {
            return;
        }
        [$type, $clientId] = $this->client($e);
        $relation = $this->em->getRDBRepository('Opportunity')->getRelation($e, 'cWonSubscriptions');
        $linked = $relation->findOne();
        if ($linked) {
            if ($linked->get('clientType') !== $type || $linked->get('clientId') !== $clientId || $linked->get('productId') !== $productId) {
                throw new BadRequest('This sale already has a subscription. Use a new opportunity for another client or product.');
            }
            if (!$e->isAttributeChanged('cWonPlanId') && !$e->isAttributeChanged('cWonDiscountTotal') && !$e->isAttributeChanged('cSubdomain')) return;
        }

        $key = hash('sha256', $type . ':' . $clientId . ':' . $productId);
        try {
            $this->em->getPDO()->prepare("UPDATE c_client_subscription SET client_product_key = NULL WHERE deleted = 1 AND client_product_key = ?")->execute([$key]);
        } catch (\Throwable) {}
        $existing = $this->em->getRDBRepository('CClientSubscription')->where(['clientProductKey' => $key])->findOne();
        $service = $this->services->get('CClientSubscription');
        $agreedPrice = round((float)$e->get('cWonPlanPrice') - (float)($e->get('cWonDiscountTotal') ?? 0), 2);

        if ($existing) {
            if (!$this->acl->checkEntityRead($existing)) {
                throw new Forbidden('An existing subscription requires access before this sale can be linked.');
            }
            if ($existing->get('status') === 'Cancelled') {
                throw new BadRequest('The client has a cancelled subscription. Review it before closing this sale.');
            }
            if ($existing->get('planId') === $e->get('cWonPlanId')) {
                $updatePayload = [];
                if (
                    (float)$existing->get('monthlyPrice') !== $agreedPrice ||
                    $existing->get('monthlyPriceCurrency') !== $e->get('cWonPlanPriceCurrency') ||
                    $existing->get('billingPeriod') !== $e->get('cWonPeriod') ||
                    $existing->get('cWonOpportunityId') !== $e->getId()
                ) {
                    $updatePayload['cWonOpportunityId'] = $e->getId();
                    if ($e->get('cWonStartDate')) {
                        $updatePayload['effectiveDate'] = $e->get('cWonStartDate');
                    }
                }
                if ($e->get('cSubdomain') && $existing->get('cSubdomain') !== $e->get('cSubdomain')) {
                    $updatePayload['cSubdomain'] = $e->get('cSubdomain');
                }
                if (!empty($updatePayload)) {
                    $existing = $service->update($existing->getId(), (object)$updatePayload)->getEntity();
                }
                $subscription = $existing;
            } else {
                if (!in_array($e->get('cWonTransition'), ['Upgrade', 'Downgrade'], true)) {
                    throw new BadRequest('The client already has another plan. Choose Upgrade or Downgrade in Existing Subscription Change.');
                }
                $updatePayload = [
                    'planId' => $e->get('cWonPlanId'),
                    'effectiveDate' => $e->get('cWonStartDate'),
                    'changeReason' => $e->get('cWonTransition'),
                    'cWonOpportunityId' => $e->getId()
                ];
                if ($e->get('cSubdomain')) {
                    $updatePayload['cSubdomain'] = $e->get('cSubdomain');
                }
                $subscription = $service->update($existing->getId(), (object)$updatePayload)->getEntity();
            }
        } else {
            $plan = $this->em->getEntityById('CSubscriptionPlan', $e->get('cWonPlanId'));
            $assignedUserId = $e->get('assignedUserId');
            if (!$assignedUserId && $this->user->getId() && $this->user->getId() !== 'system') {
                $assignedUserId = $this->user->getId();
            }
            if ($assignedUserId === 'system') {
                $assignedUserId = null;
            }
            $clientEntity = $this->em->getEntityById($type, $clientId);
            $subName = ($clientEntity && $clientEntity->get('name')) ? $clientEntity->get('name') : $plan->get('name');
            $data = (object)[
                'name' => $subName,
                'clientType' => $type,
                'clientId' => $clientId,
                'planId' => $plan->getId(),
                'status' => 'Unverified',
                'effectiveDate' => $e->get('cWonStartDate'),
                'changeReason' => 'Initial',
                'cWonOpportunityId' => $e->getId(),
                'cSubdomain' => $e->get('cSubdomain'),
                'assignedUserId' => $assignedUserId,
                'teamsIds' => $e->get('teamsIds') ?? []
            ];
            $subscription = $service->create($data)->getEntity();
        }
        $relation->relateById($subscription->getId());

        // Automatically associate product with Contact's cProductServices
        $contactId = $e->get('contactId');
        if (!$contactId) {
            $contactsIds = $e->getLinkMultipleIdList('contacts');
            if (!empty($contactsIds)) {
                $contactId = $contactsIds[0];
            }
        }
        if ($contactId && $productId) {
            $contact = $this->em->getEntityById('Contact', $contactId);
            if ($contact) {
                $productIds = $contact->getLinkMultipleIdList('cProductServices') ?? [];
                if (!in_array($productId, $productIds, true)) {
                    $productIds[] = $productId;
                    $contact->set('cProductServicesIds', $productIds);
                    $this->em->saveEntity($contact, ['silent' => true]);
                }
            }
        }

        // Also associate product with Account's cProductServices if account exists
        if ($e->get('accountId') && $productId) {
            $account = $this->em->getEntityById('Account', $e->get('accountId'));
            if ($account) {
                $accProductIds = $account->getLinkMultipleIdList('cProductServices') ?? [];
                if (!in_array($productId, $accProductIds, true)) {
                    $accProductIds[] = $productId;
                    $account->set('cProductServicesIds', $accProductIds);
                    $this->em->saveEntity($account, ['silent' => true]);
                }
            }
        }
    }
}
