define('custom:views/fields/subscription-plan-product', ['views/fields/link'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({

        getSelectFilters: function () {
            var filters = Object.assign({}, Dep.prototype.getSelectFilters.call(this) || {});

            filters.subscription = {
                type: 'equals',
                attribute: 'type',
                value: 'Subscription'
            };
            filters.active = {
                type: 'equals',
                attribute: 'status',
                value: 'Active'
            };

            return filters;
        }

    });

});
