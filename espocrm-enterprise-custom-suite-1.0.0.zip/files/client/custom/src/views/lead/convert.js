define('custom:views/lead/convert', ['modules/crm/views/lead/convert'], function (Dep) {

    return Dep.extend({

        template: 'custom:lead/convert',

        templateContent: `<div class="header page-header">{{{header}}}</div>

<div class="convert-lead-container">
    <div class="panel panel-default opportunity-convert-panel">
        <div class="panel-heading" style="background: #f8f9fa; border-bottom: 1px solid #e9ecef; padding: 12px 15px;">
            <h4 class="panel-title" style="font-weight: 600; font-size: 16px; margin: 0; display: flex; align-items: center;">
                <span class="fas fa-bullseye text-primary" style="margin-right: 8px;"></span>
                <span>{{translate 'Opportunity' category='scopeNames'}}</span>
            </h4>
        </div>
        <div class="panel-body" style="padding: 15px;">
            <!-- Opportunity Edit Form -->
            <div class="edit-container-opportunity">
                {{{var 'Opportunity' this}}}
            </div>

            <!-- Client Information: Account & Contact (inside Opportunity section, shown only on Closed Won) -->
            <div class="opportunity-client-convert-container margin-top {{#unless isClosedWon}}hide{{/unless}}" style="margin-top: 25px; border-top: 2px dashed #cbd5e1; padding-top: 20px;">
                <div class="alert alert-info" style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 20px;">
                    <span class="fas fa-info-circle fa-lg" style="margin-top: 2px;"></span>
                    <div>
                        <strong>Client Information (Account & Contact)</strong>: 
                        {{clientHelpText}}
                    </div>
                </div>

                <!-- Account Subsection -->
                <div class="client-scope-box panel panel-default" style="border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <div class="panel-heading" style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 10px 15px;">
                        <label style="user-select: none; cursor: default; margin-bottom: 0; display: flex; align-items: center; gap: 8px;" class="text-large text-bold">
                            <input
                                type="checkbox"
                                class="check-client-scope form-checkbox"
                                data-scope="Account"
                                checked
                                disabled
                            >
                            <span class="fas fa-building text-primary"></span>
                            <span>{{translate 'Account' category='scopeNames'}} (Company / Organization)</span>
                            <span class="label label-danger text-bold" style="font-size: 11px; margin-left: 5px;">Required</span>
                        </label>
                    </div>
                    <div class="panel-body edit-container-account" style="padding: 15px;">
                        {{{var 'Account' this}}}
                    </div>
                </div>

                <!-- Contact Subsection -->
                <div class="client-scope-box panel panel-default" style="border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <div class="panel-heading" style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 10px 15px;">
                        <label style="user-select: none; cursor: default; margin-bottom: 0; display: flex; align-items: center; gap: 8px;" class="text-large text-bold">
                            <input
                                type="checkbox"
                                class="check-client-scope form-checkbox"
                                data-scope="Contact"
                                checked
                                disabled
                            >
                            <span class="fas fa-user text-primary"></span>
                            <span>{{translate 'Contact' category='scopeNames'}} (Primary Contact Person)</span>
                            <span class="label label-danger text-bold" style="font-size: 11px; margin-left: 5px;">Required</span>
                        </label>
                    </div>
                    <div class="panel-body edit-container-contact" style="padding: 15px;">
                        {{{var 'Contact' this}}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="button-container margin-top">
    <div class="btn-group">
        <button class="btn btn-primary" data-action="convert" style="min-width: 120px;">{{translate 'Convert' scope='Lead'}}</button>
        <button class="btn btn-default" data-action="cancel">{{translate 'Cancel'}}</button>
    </div>
</div>`,

        data: function () {
            const oppView = this.getView('Opportunity');
            const oppModel = oppView ? oppView.model : null;
            const isClosedWon = oppModel ? oppModel.get('stage') === 'Closed Won' : false;
            const hasSubScope = Boolean(
                this.getMetadata() &&
                typeof this.getMetadata().hasScope === 'function' &&
                this.getMetadata().hasScope('CSubscriptionPlan')
            );
            const hasSalesProd = Boolean(
                this.getMetadata() &&
                this.getMetadata().get(['app', 'salesProductivity', 'installed'])
            );
            const isClientEnforced = Boolean(hasSalesProd || hasSubScope);
            const clientHelpText = hasSubScope
                ? 'Closed Won opportunities create an automated client subscription, which requires an Account and primary Contact. Confirm or customize the automatically prefilled client details below.'
                : 'Closed Won opportunities require linking directly to a client Account and primary Contact. Confirm or customize the automatically prefilled details below.';

            return {
                scopeList: ['Opportunity', 'Account', 'Contact'],
                scope: this.scope,
                isClosedWon: isClosedWon && isClientEnforced,
                isClientEnforced: isClientEnforced,
                clientHelpText: clientHelpText,
                isAccountChecked: true,
                isContactChecked: true
            };
        },

        setup: function () {
            Dep.prototype.setup.call(this);

            this.clientScopes = {
                Account: true,
                Contact: true
            };
        },

        build: function () {
            const scopeList = this.scopeList = ['Opportunity', 'Account', 'Contact'];
            this.wait(true);

            Espo.Ajax.postRequest('Lead/action/getConvertAttributes', {
                id: this.model.id
            }).then(data => {
                let count = 0;
                scopeList.forEach(scope => {
                    this.getModelFactory().create(scope, model => {
                        model.populateDefaults();
                        if (data[scope]) {
                            model.set(data[scope], { silent: true });
                        }
                        if (this.getUser() && this.getUser().id) {
                            model.set({
                                assignedUserId: this.getUser().id,
                                assignedUserName: this.getUser().get('name')
                            }, { silent: true });
                        }
                        if (scope === 'Opportunity') {
                            model.isConvertMode = true;
                            if (!model.get('accountName')) {
                                if (data.Account && data.Account.name) {
                                    model.set('accountName', data.Account.name, { silent: true });
                                } else if (this.model && this.model.get('accountName')) {
                                    model.set('accountName', this.model.get('accountName'), { silent: true });
                                } else if (this.model && this.model.get('name')) {
                                    model.set('accountName', this.model.get('name'), { silent: true });
                                }
                            }
                            if (model.get('name') && (model.get('name').endsWith(' - Opportunity') || model.get('name') === 'Opportunity')) {
                                model.set('name', '', { silent: true });
                            }
                            this.listenTo(model, 'change:stage', (m, stage) => {
                                this.updateClientVisibility(stage);
                            });
                        }
                        const convertEntityViewName = this.getMetadata().get(['clientDefs', scope, 'recordViews', 'edit']) || 'views/record/edit';
                        this.createView(scope, convertEntityViewName, {
                            model: model,
                            fullSelector: '#main .edit-container-' + Espo.Utils.toDom(scope),
                            buttonsPosition: false,
                            buttonsDisabled: true,
                            layoutName: 'detailConvert',
                            exit: () => {}
                        }, () => {
                            count++;
                            if (count === scopeList.length) {
                                this.wait(false);
                                Espo.Ui.notify(false);
                                const opp = this.getView('Opportunity');
                                const acc = this.getView('Account');
                                if (opp && opp.model) {
                                    this.updateClientVisibility(opp.model.get('stage'));
                                    if (acc && acc.model) {
                                        this.listenTo(acc.model, 'change:name', (m, name) => {
                                            if (name) {
                                                opp.model.set('accountName', name);
                                            }
                                        });
                                    }
                                    if (typeof opp.updateNamePlaceholder === 'function') {
                                        opp.updateNamePlaceholder();
                                    }
                                }
                            }
                        });
                    });
                });
            }).catch(e => {
                this.wait(false);
                Espo.Ui.error(e.message || 'Could not load convert attributes');
            });
        },

        updateClientVisibility: function (stage) {
            const isWon = stage === 'Closed Won';
            const hasSubScope = Boolean(
                this.getMetadata() &&
                typeof this.getMetadata().hasScope === 'function' &&
                this.getMetadata().hasScope('CSubscriptionPlan')
            );
            const hasSalesProd = Boolean(
                this.getMetadata() &&
                this.getMetadata().get(['app', 'salesProductivity', 'installed'])
            );
            const shouldShowClients = (hasSalesProd || hasSubScope) && isWon;
            const $container = this.$el.find('.opportunity-client-convert-container');

            if (shouldShowClients) {
                $container.removeClass('hide');
                const $accCheck = this.$el.find('.check-client-scope[data-scope="Account"]');
                const $contCheck = this.$el.find('.check-client-scope[data-scope="Contact"]');
                $accCheck.prop('checked', true).prop('disabled', true);
                $contCheck.prop('checked', true).prop('disabled', true);
                this.$el.find('.edit-container-account').removeClass('hide');
                this.$el.find('.edit-container-contact').removeClass('hide');
                this.clientScopes = this.clientScopes || {};
                this.clientScopes.Account = true;
                this.clientScopes.Contact = true;
            } else {
                $container.addClass('hide');
                this.clientScopes = this.clientScopes || {};
                this.clientScopes.Account = false;
                this.clientScopes.Contact = false;
            }
        },

        afterRender: function () {
            if (Dep.prototype.afterRender) {
                Dep.prototype.afterRender.call(this);
            }
            const opp = this.getView('Opportunity');
            if (opp && opp.model) {
                this.updateClientVisibility(opp.model.get('stage'));
                if (typeof opp.updateNamePlaceholder === 'function') {
                    opp.updateNamePlaceholder();
                }
            }
        },

        convert: function () {
            const oppView = this.getView('Opportunity');
            if (!oppView) return;

            const oppModel = oppView.model;
            oppModel.set(oppView.fetch());

            // Auto-populate Opportunity name if empty
            if (!oppModel.get('name') || !oppModel.get('name').trim()) {
                const autoName = (typeof oppView.getNamePlaceholder === 'function')
                    ? oppView.getNamePlaceholder().replace(/^e\.g\.\s*/i, '').replace(/\.\.\.$/, '').trim()
                    : (this.model.get('name') + ' Deal');
                oppModel.set('name', autoName || (this.model.get('name') || 'Opportunity Deal'));
            }

            // Ensure amount is not null
            if (oppModel.get('amount') === null || oppModel.get('amount') === undefined || oppModel.get('amount') === '') {
                oppModel.set('amount', 0.0);
            }

            const stage = oppModel.get('stage');
            const isWon = stage === 'Closed Won';
            const hasSubScope = Boolean(
                this.getMetadata() &&
                typeof this.getMetadata().hasScope === 'function' &&
                this.getMetadata().hasScope('CSubscriptionPlan')
            );
            const hasSalesProd = Boolean(
                this.getMetadata() &&
                this.getMetadata().get(['app', 'salesProductivity', 'installed'])
            );
            const shouldRequireClients = (hasSalesProd || hasSubScope) && isWon;

            const activeScopes = ['Opportunity'];
            let notValid = false;

            if (shouldRequireClients) {
                activeScopes.push('Account');
                const accView = this.getView('Account');
                if (accView) {
                    accView.model.set(accView.fetch());
                    notValid = accView.validate() || notValid;
                }

                activeScopes.push('Contact');
                const contView = this.getView('Contact');
                if (contView) {
                    contView.model.set(contView.fetch());
                    notValid = contView.validate() || notValid;
                }
            }

            // Validate Opportunity
            notValid = oppView.validate() || notValid;

            if (notValid) {
                Espo.Ui.error(this.translate('Not valid'));
                return;
            }

            this.getRouter().confirmLeaveOut = false;
            ['Opportunity', 'Account', 'Contact'].forEach(scope => {
                const view = this.getView(scope);
                if (view && typeof view.setConfirmLeaveOut === 'function') {
                    view.setConfirmLeaveOut(false);
                }
            });

            const data = {
                id: this.model.id,
                records: {}
            };

            activeScopes.forEach(scope => {
                const view = this.getView(scope);
                if (view) {
                    data.records[scope] = view.model.attributes;
                }
            });

            const $btn = this.$el.find('[data-action="convert"]');
            $btn.addClass('disabled');
            Espo.Ui.notifyWait();

            const process = (postData) => {
                Espo.Ajax.postRequest('Lead/action/convert', postData).then(() => {
                    this.getRouter().confirmLeaveOut = false;
                    this.getRouter().navigate('#Lead/view/' + this.model.id, { trigger: true });
                    Espo.Ui.notify(this.translate('Converted', 'labels', 'Lead'));
                }).catch(xhr => {
                    Espo.Ui.notify(false);
                    $btn.removeClass('disabled');
                    if (xhr.status === 409 && xhr.getResponseHeader('X-Status-Reason') === 'duplicate') {
                        let response = null;
                        try { response = JSON.parse(xhr.responseText); } catch (e) { return; }
                        xhr.errorIsHandled = true;
                        this.createView('duplicate', 'views/modals/duplicate', {
                            duplicates: response
                        }, view => {
                            view.render();
                            this.listenToOnce(view, 'save', () => {
                                postData.skipDuplicateCheck = true;
                                process(postData);
                            });
                        });
                    }
                });
            };

            process(data);
        }

    });

});
