<?php

class BeforeUninstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["CProductService"];
            $tabList = $config->get('tabList') ?? [];
            $newTabList = array_values(array_filter($tabList, fn($t) => !in_array($t, $tabs)));
            if (count($newTabList) !== count($tabList)) {
                $configWriter->set('tabList', $newTabList);
                $configWriter->save();
            }


        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
