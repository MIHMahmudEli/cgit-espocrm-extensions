define('custom:views/opportunity/record/edit-small', ['custom:views/opportunity/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({});

});
