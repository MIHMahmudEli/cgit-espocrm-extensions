define('custom:views/c-client-subscription/record/edit-small', ['custom:views/c-client-subscription/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({});

});
