define('custom:views/activity-monitor/index', ['view'], function (Dep) {

    return Dep.extend({

        template: 'custom:activity-monitor/index',

        quickRange: '24h',
        from: null,
        to: null,
        fromDateValue: '',
        toDateValue: '',
        fromTimeValue: '00:00',
        toTimeValue: '23:59',
        customPreset: null,
        isFromTimePickerOpen: false,
        isToTimePickerOpen: false,
        fromTimeState: null,
        toTimeState: null,
        fromTimeFlashed: false,
        toTimeFlashed: false,
        timezone: 'Asia/Dhaka',
        userIds: null,
        entityTypes: null,
        activityTypes: null,
        search: '',
        page: 1,
        maxSize: 25,
        isLoading: false,
        autoRefresh: false,
        autoRefreshInterval: null,

        activities: null,
        totalActivities: 0,
        summary: null,
        filterData: null,

        events: {
            'click [data-action="quickFilter"]': function (e) {
                var range = $(e.currentTarget).data('range');
                this.setQuickRange(range);
            },
            'click [data-action="presetRange"]': function (e) {
                var preset = $(e.currentTarget).data('preset');
                this.setPresetRange(preset);
            },
            'click [data-action="applyCustomRange"]': function () {
                this.applyCustomRange();
            },
            'click [data-action="closeCustomRange"]': function () {
                this.setQuickRange('24h');
            },
            'click [data-action="toggleTimePicker"]': function (e) {
                e.stopPropagation();
                var target = $(e.currentTarget).data('target');
                this.toggleTimePicker(target);
            },
            'click [data-action="closeTimePicker"]': function (e) {
                e.stopPropagation();
                var target = $(e.currentTarget).data('target');
                this.closeTimePicker(target);
            },
            'click [data-action="selectTimePart"]': function (e) {
                e.stopPropagation();
                var $btn = $(e.currentTarget);
                var target = $btn.data('target');
                var part = $btn.data('part');
                var val = $btn.data('val');
                this.selectTimePart(target, part, String(val));
            },
            'click .activity-time-popover': function (e) {
                e.stopPropagation();
            },
            'change input[name="fromDate"]': function (e) {
                this.fromDateValue = $(e.currentTarget).val();
                this.customPreset = null;
                if (!this.toDateValue) {
                    this.toDateValue = this.fromDateValue;
                }
            },
            'change input[name="toDate"]': function (e) {
                this.toDateValue = $(e.currentTarget).val();
                this.customPreset = null;
            },
            'keypress input[name="fromDate"], input[name="toDate"]': function (e) {
                if (e.which === 13) {
                    this.applyCustomRange();
                }
            },
            'click [data-action="applyFilters"]': function () {
                this.readFilterInputs();
                this.page = 1;
                this.loadAll();
            },
            'click [data-action="clearSearch"]': function () {
                this.search = '';
                this.page = 1;
                this.loadAll();
            },
            'keypress input[name="search"]': function (e) {
                if (e.which === 13) {
                    this.readFilterInputs();
                    this.page = 1;
                    this.loadAll();
                }
            },
            'change select[name="userId"]': function () {
                this.readFilterInputs();
                this.page = 1;
                this.loadAll();
            },
            'change select[name="entityType"]': function () {
                this.readFilterInputs();
                this.page = 1;
                this.loadAll();
            },
            'change select[name="activityType"]': function () {
                this.readFilterInputs();
                this.page = 1;
                this.loadAll();
            },
            'click [data-action="resetFilters"]': function () {
                this.resetFilters();
            },
            'click [data-action="refresh"]': function () {
                this.loadAll();
            },
            'click [data-action="toggleAutoRefresh"]': function () {
                this.toggleAutoRefresh();
            },
            'click [data-action="prevPage"]': function () {
                if (this.page > 1) {
                    this.page--;
                    this.loadActivitiesOnly();
                }
            },
            'click [data-action="nextPage"]': function () {
                var totalPages = Math.ceil(this.totalActivities / this.maxSize) || 1;
                if (this.page < totalPages) {
                    this.page++;
                    this.loadActivitiesOnly();
                }
            },
            'click [data-action="filterUser"]': function (e) {
                var uid = $(e.currentTarget).data('id');
                if (uid) {
                    this.userIds = [uid];
                    this.page = 1;
                    this.loadAll();
                }
            },
            'click [data-action="filterEntity"]': function (e) {
                var ent = $(e.currentTarget).data('entity');
                if (ent) {
                    this.entityTypes = [ent];
                    this.page = 1;
                    this.loadAll();
                }
            }
        },

        setup: function () {
            Dep.prototype.setup.call(this);

            if (!this.getUser().isAdmin()) {
                Espo.Ui.error(this.translate('Access Denied', 'messages'));
                return;
            }

            this.userIds = [];
            this.entityTypes = [];
            this.activityTypes = [];
            this.activities = [];
            this.fromTimeState = { hour: '12', minute: '00', ampm: 'AM', hourSelected: false, minuteSelected: false, ampmSelected: false, openedWithAmpm: 'AM' };
            this.toTimeState = { hour: '11', minute: '59', ampm: 'PM', hourSelected: false, minuteSelected: false, ampmSelected: false, openedWithAmpm: 'PM' };
            this.fromTimeValue = '00:00';
            this.toTimeValue = '23:59';
            this.isFromTimePickerOpen = false;
            this.isToTimePickerOpen = false;
            this.fromTimeFlashed = false;
            this.toTimeFlashed = false;
            this.summary = {
                totalActivities: 0,
                typeCounts: {
                    'Created': 0,
                    'Updated': 0,
                    'Status Changed': 0,
                    'statusChanged': 0,
                    'Converted': 0,
                    'Deleted': 0
                },
                userStats: [],
                entityStats: []
            };
            this.filterData = {
                users: [],
                entities: [],
                activityTypes: []
            };

            this.timezone = (this.getPreferences() && this.getPreferences().get('timeZone')) || 'Asia/Dhaka';

            this.calcDefaultDates('24h');
            this.wait(true);

            Espo.Ajax.getRequest('ActivityMonitor/filterData').then(function (data) {
                this.filterData = data || {};
                return this.fetchData();
            }.bind(this)).catch(function () {
                Espo.Ui.error(this.translate('Error', 'messages'));
            }.bind(this)).finally(function () {
                this.wait(false);
            }.bind(this));
        },

        getEntityIconMap: function () {
            return {
                'Lead': 'fas fa-user text-primary',
                'Contact': 'fas fa-id-card text-info',
                'Account': 'fas fa-building text-warning',
                'Opportunity': 'fas fa-dollar-sign text-success',
                'Call': 'fas fa-phone text-secondary',
                'Meeting': 'fas fa-calendar-alt text-secondary',
                'CClientSubscription': 'fas fa-receipt text-success',
                'CSubscriptionPlan': 'fas fa-tags text-primary',
                'CProductService': 'fas fa-box text-info',
                'Task': 'fas fa-tasks text-muted',
                'Case': 'fas fa-briefcase text-danger',
                'Email': 'fas fa-envelope text-info',
                'Calendar': 'fas fa-calendar-alt text-primary',
                'KnowledgeBaseArticle': 'fas fa-book-open text-warning',
                'KnowledgeBaseCategory': 'fas fa-folder text-warning'
            };
        },

        formatDateYMD: function (d) {
            var pad = function (n) { return (n < 10 ? '0' : '') + n; };
            return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
        },

        formatPrettyDate: function (ymd) {
            if (!ymd) return '';
            var parts = ymd.split('-');
            if (parts.length !== 3) return ymd;
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var m = parseInt(parts[1], 10) - 1;
            return (months[m] || parts[1]) + ' ' + parseInt(parts[2], 10) + ', ' + parts[0];
        },

        data: function () {
            var totalPages = Math.ceil(this.totalActivities / this.maxSize) || 1;
            var offset = (this.page - 1) * this.maxSize;
            var paginationStart = this.totalActivities > 0 ? (offset + 1) : 0;
            var paginationEnd = Math.min(offset + this.maxSize, this.totalActivities);

            var hours = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
            var minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '59'];

            var fromHourOptions = hours.map(function (h) {
                return { val: h, selected: h === this.fromTimeState.hour };
            }.bind(this));

            var fromMinuteOptions = minutes.map(function (m) {
                return { val: m, selected: m === this.fromTimeState.minute };
            }.bind(this));

            var toHourOptions = hours.map(function (h) {
                return { val: h, selected: h === this.toTimeState.hour };
            }.bind(this));

            var toMinuteOptions = minutes.map(function (m) {
                return { val: m, selected: m === this.toTimeState.minute };
            }.bind(this));

            var fromTimeDisplay = this.fromTimeState.hour + ':' + this.fromTimeState.minute + ' ' + this.fromTimeState.ampm;
            var toTimeDisplay = this.toTimeState.hour + ':' + this.toTimeState.minute + ' ' + this.toTimeState.ampm;

            var customHumanSummary = '';
            if (this.quickRange === 'custom' && this.fromDateValue && this.toDateValue) {
                var pFrom = this.formatPrettyDate(this.fromDateValue);
                var pTo = this.formatPrettyDate(this.toDateValue);
                if (this.customPreset === 'today') {
                    customHumanSummary = 'Today (' + pFrom + ')';
                } else if (this.customPreset === 'yesterday') {
                    customHumanSummary = 'Yesterday (' + pFrom + ')';
                } else if (this.fromDateValue === this.toDateValue) {
                    customHumanSummary = pFrom;
                } else {
                    customHumanSummary = pFrom + ' – ' + pTo;
                }
                customHumanSummary += ' (' + fromTimeDisplay + ' to ' + toTimeDisplay + ')';
            }

            var rangeLabels = {
                '3h': 'Last 3 Hours',
                '24h': 'Last 24 Hours',
                '7d': 'Last 7 Days',
                'custom': customHumanSummary ? ('Custom: ' + customHumanSummary) : 'Custom Date Range'
            };

            var selectedUserId = (this.userIds && this.userIds[0]) || '';
            var selectedEntityType = (this.entityTypes && this.entityTypes[0]) || '';
            var selectedActivityType = (this.activityTypes && this.activityTypes[0]) || '';

            var users = (this.filterData && this.filterData.users || []).map(function (u) {
                return {
                    id: u.id,
                    name: u.name,
                    userName: u.userName,
                    selected: u.id === selectedUserId
                };
            });

            var entities = (this.filterData && this.filterData.entities || []).map(function (ent) {
                return {
                    name: ent.name,
                    label: ent.label,
                    selected: ent.name === selectedEntityType
                };
            });

            var activityTypes = (this.filterData && this.filterData.activityTypes || []).map(function (t) {
                return {
                    name: t.name,
                    label: t.label,
                    selected: t.name === selectedActivityType
                };
            });

            return {
                timezone: this.timezone,
                quickRange: this.quickRange,
                currentRangeLabel: rangeLabels[this.quickRange] || rangeLabels['24h'],
                is3hActive: this.quickRange === '3h',
                is24hActive: this.quickRange === '24h',
                is7dActive: this.quickRange === '7d',
                isCustomActive: this.quickRange === 'custom',
                fromDateValue: this.fromDateValue,
                toDateValue: this.toDateValue,
                fromTimeValue: this.fromTimeValue,
                toTimeValue: this.toTimeValue,

                fromHourOptions: fromHourOptions,
                fromMinuteOptions: fromMinuteOptions,
                fromIsAmSelected: this.fromTimeState.ampm === 'AM',
                fromIsPmSelected: this.fromTimeState.ampm === 'PM',
                fromTimeDisplay: fromTimeDisplay,
                isFromTimePickerOpen: this.isFromTimePickerOpen,
                fromTimeFlashed: this.fromTimeFlashed,

                toHourOptions: toHourOptions,
                toMinuteOptions: toMinuteOptions,
                toIsAmSelected: this.toTimeState.ampm === 'AM',
                toIsPmSelected: this.toTimeState.ampm === 'PM',
                toTimeDisplay: toTimeDisplay,
                isToTimePickerOpen: this.isToTimePickerOpen,
                toTimeFlashed: this.toTimeFlashed,

                customRangeHumanSummary: customHumanSummary,
                isPresetToday: this.customPreset === 'today',
                isPresetYesterday: this.customPreset === 'yesterday',
                isPresetThisWeek: this.customPreset === 'thisWeek',
                isPresetLastWeek: this.customPreset === 'lastWeek',
                isPresetThisMonth: this.customPreset === 'thisMonth',
                isPresetLast30d: this.customPreset === 'last30d',
                search: this.search,
                autoRefresh: this.autoRefresh,
                isLoading: this.isLoading,
                summary: this.summary,
                userStatsCount: (this.summary && this.summary.userStats ? this.summary.userStats.length : 0),
                entityStatsCount: (this.summary && this.summary.entityStats ? this.summary.entityStats.length : 0),
                hasUserStats: !!(this.summary && this.summary.userStats && this.summary.userStats.length),
                hasEntityStats: !!(this.summary && this.summary.entityStats && this.summary.entityStats.length),
                hasActivities: !!(this.activities && this.activities.length),
                filterData: {
                    users: users,
                    entities: entities,
                    activityTypes: activityTypes
                },
                activities: this.activities,
                totalActivities: this.totalActivities,
                page: this.page,
                totalPages: totalPages,
                paginationStart: paginationStart,
                paginationEnd: paginationEnd,
                hasPrev: this.page > 1,
                hasNext: this.page < totalPages
            };
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            if (this.userIds && this.userIds.length) {
                this.$el.find('select[name="userId"]').val(this.userIds[0]);
            }
            if (this.entityTypes && this.entityTypes.length) {
                this.$el.find('select[name="entityType"]').val(this.entityTypes[0]);
            }
            if (this.activityTypes && this.activityTypes.length) {
                this.$el.find('select[name="activityType"]').val(this.activityTypes[0]);
            }
            if (this.fromDateValue) {
                this.$el.find('input[name="fromDate"]').val(this.fromDateValue);
            }
            if (this.toDateValue) {
                this.$el.find('input[name="toDate"]').val(this.toDateValue);
            }

            $(document).off('click.activityTimePicker').on('click.activityTimePicker', function (e) {
                if (!this.isFromTimePickerOpen && !this.isToTimePickerOpen) {
                    return;
                }
                if ($(e.target).closest('.custom-time-picker-wrap').length === 0) {
                    this.isFromTimePickerOpen = false;
                    this.isToTimePickerOpen = false;
                    this.reRender();
                }
            }.bind(this));
        },

        onRemove: function () {
            $(document).off('click.activityTimePicker');
            if (this.autoRefreshInterval) {
                clearInterval(this.autoRefreshInterval);
                this.autoRefreshInterval = null;
            }
            Dep.prototype.onRemove.call(this);
        },

        toggleTimePicker: function (target) {
            if (target === 'from') {
                this.isFromTimePickerOpen = !this.isFromTimePickerOpen;
                this.isToTimePickerOpen = false;
                if (this.isFromTimePickerOpen) {
                    this.fromTimeState.openedWithAmpm = this.fromTimeState.ampm;
                    this.fromTimeState.hourSelected = false;
                    this.fromTimeState.minuteSelected = false;
                    this.fromTimeState.ampmSelected = false;
                }
            } else {
                this.isToTimePickerOpen = !this.isToTimePickerOpen;
                this.isFromTimePickerOpen = false;
                if (this.isToTimePickerOpen) {
                    this.toTimeState.openedWithAmpm = this.toTimeState.ampm;
                    this.toTimeState.hourSelected = false;
                    this.toTimeState.minuteSelected = false;
                    this.toTimeState.ampmSelected = false;
                }
            }
            this.reRender();
        },

        closeTimePicker: function (target, flashSuccess) {
            if (target === 'from') {
                this.isFromTimePickerOpen = false;
                if (flashSuccess) {
                    this.fromTimeFlashed = true;
                }
            } else {
                this.isToTimePickerOpen = false;
                if (flashSuccess) {
                    this.toTimeFlashed = true;
                }
            }
            this.reRender();

            if (flashSuccess) {
                setTimeout(function () {
                    if (target === 'from') {
                        this.fromTimeFlashed = false;
                    } else {
                        this.toTimeFlashed = false;
                    }
                    if (this.$el) {
                        this.$el.find('.custom-time-btn[data-target="' + target + '"]').removeClass('time-btn-success');
                    }
                }.bind(this), 1200);
            }
        },

        selectTimePart: function (target, part, val) {
            var state = target === 'from' ? this.fromTimeState : this.toTimeState;
            state[part] = val;
            state[part + 'Selected'] = true;
            this.sync24FromState(target);

            // Auto-close check:
            // 1. All three parts explicitly clicked during this picker session
            // 2. User clicked AM or PM after picking hour or minute
            // 3. User explicitly switched AM <-> PM
            var allThreeSelected = !!(state.hourSelected && state.minuteSelected && state.ampmSelected);
            var ampmSelectedAfterField = (part === 'ampm' && (state.hourSelected || state.minuteSelected));
            var ampmSwitched = (part === 'ampm' && val !== state.openedWithAmpm);

            if (allThreeSelected || ampmSelectedAfterField || ampmSwitched) {
                this.closeTimePicker(target, true);
            } else {
                this.reRender();
            }
        },

        sync24FromState: function (target) {
            var state = target === 'from' ? this.fromTimeState : this.toTimeState;
            var h = parseInt(state.hour, 10);
            if (isNaN(h)) h = 12;
            var m = state.minute || '00';
            var ampm = state.ampm || 'AM';

            var h24 = h;
            if (ampm === 'AM') {
                if (h === 12) h24 = 0;
            } else {
                if (h < 12) h24 = h + 12;
            }
            var hStr = (h24 < 10 ? '0' : '') + h24;
            var time24 = hStr + ':' + m;

            if (target === 'from') {
                this.fromTimeValue = time24;
                if (this.fromDateValue) {
                    this.from = this.fromDateValue + ' ' + time24 + ':00';
                }
            } else {
                this.toTimeValue = time24;
                if (this.toDateValue) {
                    this.to = this.toDateValue + ' ' + time24 + ':59';
                }
            }
        },

        parse24ToState: function (time24, target) {
            if (!time24) return;
            var parts = time24.split(':');
            var h24 = parseInt(parts[0], 10);
            var m = parts[1] || '00';
            if (isNaN(h24)) h24 = 0;

            var ampm = h24 >= 12 ? 'PM' : 'AM';
            var h12 = h24 % 12;
            if (h12 === 0) h12 = 12;
            var hStr = (h12 < 10 ? '0' : '') + h12;

            var state = target === 'from' ? this.fromTimeState : this.toTimeState;
            state.hour = hStr;
            state.minute = m;
            state.ampm = ampm;
        },

        calcDefaultDates: function (range) {
            this.quickRange = range;
            this.customPreset = null;
            var now = new Date();
            var from = new Date(now.getTime());

            if (range === '3h') {
                from.setHours(from.getHours() - 3);
            } else if (range === '24h') {
                from.setHours(from.getHours() - 24);
            } else if (range === '7d') {
                from.setDate(from.getDate() - 7);
            }

            this.fromDateValue = this.formatDateYMD(from);
            this.toDateValue = this.formatDateYMD(now);
            this.from = from.toISOString();
            this.to = now.toISOString();
        },

        setPresetRange: function (preset) {
            var now = new Date();
            var from = new Date(now.getTime());
            var to = new Date(now.getTime());

            if (preset === 'today') {
                // from = today, to = today
            } else if (preset === 'yesterday') {
                from.setDate(from.getDate() - 1);
                to.setDate(to.getDate() - 1);
            } else if (preset === 'thisWeek') {
                var day = from.getDay();
                var diff = from.getDate() - day + (day === 0 ? -6 : 1);
                from.setDate(diff);
            } else if (preset === 'lastWeek') {
                var day = from.getDay();
                var diff = from.getDate() - day + (day === 0 ? -6 : 1) - 7;
                from.setDate(diff);
                to = new Date(from.getTime());
                to.setDate(to.getDate() + 6);
            } else if (preset === 'thisMonth') {
                from.setDate(1);
            } else if (preset === 'last30d') {
                from.setDate(from.getDate() - 30);
            }

            this.fromDateValue = this.formatDateYMD(from);
            this.toDateValue = this.formatDateYMD(to);
            this.fromTimeValue = '00:00';
            this.toTimeValue = '23:59';
            this.parse24ToState('00:00', 'from');
            this.parse24ToState('23:59', 'to');
            this.customPreset = preset;
            this.quickRange = 'custom';
            this.isFromTimePickerOpen = false;
            this.isToTimePickerOpen = false;

            this.from = this.fromDateValue + ' 00:00:00';
            this.to = this.toDateValue + ' 23:59:59';

            this.page = 1;
            this.loadAll();
        },

        applyCustomRange: function () {
            var $from = this.$el.find('input[name="fromDate"]');
            var $to = this.$el.find('input[name="toDate"]');

            if ($from.length && $from.val()) {
                this.fromDateValue = $from.val();
            }
            if ($to.length && $to.val()) {
                this.toDateValue = $to.val();
            }

            if (!this.fromDateValue && !this.toDateValue) {
                var now = new Date();
                this.fromDateValue = this.formatDateYMD(now);
                this.toDateValue = this.formatDateYMD(now);
            } else if (!this.fromDateValue) {
                this.fromDateValue = this.toDateValue;
            } else if (!this.toDateValue) {
                this.toDateValue = this.fromDateValue;
            }

            if (this.fromDateValue > this.toDateValue) {
                var temp = this.fromDateValue;
                this.fromDateValue = this.toDateValue;
                this.toDateValue = temp;
            }

            this.sync24FromState('from');
            this.sync24FromState('to');

            this.customPreset = null;
            this.quickRange = 'custom';

            this.from = this.fromDateValue + ' ' + (this.fromTimeValue || '00:00') + ':00';
            this.to = this.toDateValue + ' ' + (this.toTimeValue || '23:59') + ':59';

            this.isFromTimePickerOpen = false;
            this.isToTimePickerOpen = false;

            this.page = 1;
            this.loadAll();
        },

        setQuickRange: function (range) {
            if (range === 'custom') {
                this.quickRange = 'custom';
                if (!this.fromDateValue || !this.toDateValue) {
                    var now = new Date();
                    var from = new Date(now.getTime());
                    from.setDate(from.getDate() - 1);
                    this.fromDateValue = this.formatDateYMD(from);
                    this.toDateValue = this.formatDateYMD(now);
                    this.fromTimeValue = '00:00';
                    this.toTimeValue = '23:59';
                    this.parse24ToState('00:00', 'from');
                    this.parse24ToState('23:59', 'to');
                    this.from = this.fromDateValue + ' 00:00:00';
                    this.to = this.toDateValue + ' 23:59:59';
                }
                this.reRender();
                return;
            }

            this.calcDefaultDates(range);
            this.page = 1;
            this.loadAll();
        },

        readFilterInputs: function () {
            var $user = this.$el.find('select[name="userId"]');
            var $entity = this.$el.find('select[name="entityType"]');
            var $type = this.$el.find('select[name="activityType"]');
            var $search = this.$el.find('input[name="search"]');

            var uid = $user.val();
            this.userIds = uid ? [uid] : [];
            var ent = $entity.val();
            this.entityTypes = ent ? [ent] : [];
            var atype = $type.val();
            this.activityTypes = atype ? [atype] : [];
            this.search = ($search.val() || '').trim();
        },

        resetFilters: function () {
            this.userIds = [];
            this.entityTypes = [];
            this.activityTypes = [];
            this.search = '';
            this.page = 1;
            this.customPreset = null;
            this.isFromTimePickerOpen = false;
            this.isToTimePickerOpen = false;
            this.fromTimeFlashed = false;
            this.toTimeFlashed = false;
            this.calcDefaultDates('24h');
            this.loadAll();
        },

        buildQueryParams: function (forSummary) {
            var params = {
                timezone: this.timezone
            };

            if (this.quickRange && this.quickRange !== 'custom') {
                params.quickRange = this.quickRange;
            } else {
                if (this.from) params.from = this.from;
                if (this.to) params.to = this.to;
            }

            if (this.userIds && this.userIds.length) {
                params.userIds = this.userIds.join(',');
            }
            if (this.entityTypes && this.entityTypes.length) {
                params.entityTypes = this.entityTypes.join(',');
            }
            if (this.activityTypes && this.activityTypes.length) {
                params.activityTypes = this.activityTypes.join(',');
            }
            if (this.search) {
                params.search = this.search;
            }

            if (!forSummary) {
                params.offset = (this.page - 1) * this.maxSize;
                params.maxSize = this.maxSize;
            }

            return params;
        },

        fetchData: function () {
            var p1 = this.loadSummary();
            var p2 = this.loadActivities();
            return Promise.all([p1, p2]);
        },

        loadAll: function () {
            this.isLoading = true;
            this.reRender();

            this.fetchData().finally(function () {
                this.isLoading = false;
                this.reRender();
            }.bind(this));
        },

        loadActivitiesOnly: function () {
            this.isLoading = true;
            this.reRender();

            this.loadActivities().finally(function () {
                this.isLoading = false;
                this.reRender();
            }.bind(this));
        },

        loadSummary: function () {
            var params = this.buildQueryParams(true);
            return Espo.Ajax.getRequest('ActivityMonitor/summary', params).then(function (res) {
                var summary = res || {
                    totalActivities: 0,
                    typeCounts: {},
                    userStats: [],
                    entityStats: []
                };
                if (summary.typeCounts) {
                    summary.typeCounts.statusChanged = summary.typeCounts.statusChanged || summary.typeCounts['Status Changed'] || 0;
                }
                var iconMap = this.getEntityIconMap();
                (summary.entityStats || []).forEach(function (e) {
                    e.entityIconClass = iconMap[e.entityType] || 'fas fa-cube text-muted';
                });
                this.summary = summary;
            }.bind(this));
        },

        loadActivities: function () {
            var params = this.buildQueryParams(false);
            return Espo.Ajax.getRequest('ActivityMonitor', params).then(function (res) {
                this.totalActivities = res.total || 0;
                this.activities = this.enrichClientItems(res.list || []);
            }.bind(this));
        },

        enrichClientItems: function (list) {
            var iconMap = this.getEntityIconMap();

            return (list || []).filter(function (item) {
                var isSys = item.isSystemUser || item.userId === 'system' || !item.userId || (item.userName || '').toLowerCase() === 'system';
                return !isSys;
            }).map(function (item) {
                var type = item.activityType || 'Updated';
                item.isCreated = type === 'Created';
                item.isStatusChanged = type === 'Status Changed';
                item.isConverted = type === 'Converted';
                item.isDeleted = type === 'Deleted';
                item.isAssigned = type === 'Assigned';
                item.isPost = type === 'Post';
                item.isUpdated = type === 'Updated';

                item.entityIconClass = iconMap[item.entityType] || 'fas fa-cube text-muted';
                item.hasFieldChanges = !!(item.fieldChanges && item.fieldChanges.length);
                item.isSystemUser = (item.userId === 'system' || !item.userId || item.userName === 'System');

                var nameParts = (item.userName || '').trim().split(/\s+/);
                var initials = '';
                if (nameParts.length >= 2) {
                    initials = nameParts[0][0] + nameParts[1][0];
                } else if (nameParts.length === 1 && nameParts[0].length) {
                    initials = nameParts[0].substring(0, 2);
                } else {
                    initials = 'U';
                }
                item.userInitials = initials.toUpperCase();

                return item;
            });
        },

        toggleAutoRefresh: function () {
            this.autoRefresh = !this.autoRefresh;
            if (this.autoRefresh) {
                this.autoRefreshInterval = setInterval(function () {
                    this.loadAll();
                }.bind(this), 30000);
                Espo.Ui.success(this.translate('AutoRefresh', 'labels', 'ActivityMonitor') + ' enabled (30s)');
            } else {
                if (this.autoRefreshInterval) {
                    clearInterval(this.autoRefreshInterval);
                    this.autoRefreshInterval = null;
                }
                Espo.Ui.info(this.translate('AutoRefresh', 'labels', 'ActivityMonitor') + ' disabled');
            }
            this.reRender();
        }
    });
});
