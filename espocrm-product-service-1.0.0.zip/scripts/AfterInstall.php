<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["CProductService"];
            $tabList = $config->get('tabList') ?? [];
            $modified = false;
            foreach ($tabs as $tab) {
                if ($tab === 'CProductService') {
                    // Position 'CProductService' immediately below 'Call' in the left sidepanel / navigation bar
                    $existingIndex = null;
                    foreach ($tabList as $k => $item) {
                        if (is_string($item) && $item === 'CProductService') {
                            $existingIndex = $k;
                            break;
                        }
                    }
                    if ($existingIndex !== null) {
                        array_splice($tabList, $existingIndex, 1);
                        $modified = true;
                    }

                    $callIndex = null;
                    foreach ($tabList as $k => $item) {
                        if (is_string($item) && $item === 'Call') {
                            $callIndex = $k;
                            break;
                        }
                    }

                    if ($callIndex !== null) {
                        array_splice($tabList, $callIndex + 1, 0, ['CProductService']);
                        $modified = true;
                    } else {
                        $delimIndex = null;
                        foreach ($tabList as $k => $item) {
                            if (is_string($item) && $item === '_delimiter_') {
                                $delimIndex = $k;
                                break;
                            }
                        }
                        if ($delimIndex !== null) {
                            array_splice($tabList, $delimIndex, 0, ['CProductService']);
                        } else {
                            $tabList[] = 'CProductService';
                        }
                        $modified = true;
                    }
                } else {
                    $exists = false;
                    foreach ($tabList as $item) {
                        if (is_string($item) && $item === $tab) {
                            $exists = true;
                            break;
                        }
                    }
                    if (!$exists) {
                        $tabList[] = $tab;
                        $modified = true;
                    }
                }
            }
            if ($modified) {
                $configWriter->set('tabList', array_values($tabList));
                $configWriter->save();
            }

            // Also place CProductService in quickCreateList right after Call if Call exists
            if (in_array('CProductService', $tabs)) {
                $qcList = $config->get('quickCreateList') ?? [];
                if (!in_array('CProductService', $qcList)) {
                    $callQcIdx = array_search('Call', $qcList);
                    if ($callQcIdx !== false) {
                        array_splice($qcList, $callQcIdx + 1, 0, ['CProductService']);
                    } else {
                        $qcList[] = 'CProductService';
                    }
                    $configWriter->set('quickCreateList', array_values($qcList));
                    $configWriter->save();
                }
            }

            // Update preferences for any user who customized tabList
            try {
                $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
                if ($em && $em->hasRepository('Preferences')) {
                    $prefsList = $em->getRDBRepository('Preferences')->where(['tabList!=' => null])->find();
                    foreach ($prefsList as $pref) {
                        $pTabList = $pref->get('tabList');
                        if (is_array($pTabList)) {
                            $pExisting = null;
                            foreach ($pTabList as $k => $item) {
                                if (is_string($item) && $item === 'CProductService') {
                                    $pExisting = $k;
                                    break;
                                }
                            }
                            if ($pExisting !== null) {
                                array_splice($pTabList, $pExisting, 1);
                            }
                            $pCallIdx = null;
                            foreach ($pTabList as $k => $item) {
                                if (is_string($item) && $item === 'Call') {
                                    $pCallIdx = $k;
                                    break;
                                }
                            }
                            if ($pCallIdx !== null) {
                                array_splice($pTabList, $pCallIdx + 1, 0, ['CProductService']);
                            } else {
                                $pTabList[] = 'CProductService';
                            }
                            $pref->set('tabList', array_values($pTabList));
                            $em->saveEntity($pref);
                        }
                    }
                }
            } catch (\Throwable $e) {}


        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
