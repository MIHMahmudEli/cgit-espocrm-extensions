define('custom:controllers/activity-monitor', ['controller'], function (Dep) {

    return Dep.extend({

        actionIndex: function () {
            if (!this.getUser().isAdmin()) {
                Espo.Ui.error(this.translate('Access Denied', 'messages'));
                this.getRouter().navigate('#', {trigger: true});
                return;
            }

            this.main('custom:views/activity-monitor/index', null, null, {
                key: 'activity-monitor-index'
            });
        }
    });
});
