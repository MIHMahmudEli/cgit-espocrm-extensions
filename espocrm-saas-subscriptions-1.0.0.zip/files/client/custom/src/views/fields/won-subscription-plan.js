define('custom:views/fields/won-subscription-plan', ['views/fields/link'], function (Dep) {
    return Dep.extend({
        setup: function () {
            Dep.prototype.setup.call(this);
            this.sequence = 0;
            this.pending = false;
            this.priceError = null;
            this.validations = this.validations.concat(['wonPlan']);
            this.captureSaved();
            this.listenTo(this.model, 'sync', this.captureSaved);
            this.listenTo(this.model, 'change:cWonPlanId change:cWonPlanName', function (model, val, options) {
                var name = this.model.get('cWonPlanName') || '';
                var id = this.model.get('cWonPlanId') || '';
                if (this.$elementName && typeof this.$elementName.val === 'function') {
                    this.$elementName.val(name);
                }
                if (this.$elementId && typeof this.$elementId.val === 'function') {
                    this.$elementId.val(id);
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('input[data-name="cWonPlanName"]').val(name);
                    this.$el.find('input[data-name="cWonPlanId"]').val(id);
                    this.$el.find('.main-element').val(name);
                }
                if (options && options.ui) this.loadPlan();
            });
            this.listenTo(this.model, 'change:cWonHasSetupFee change:cWonSetupFee change:cWonSetupFeeCurrency change:stage', this.preview);
            this.listenTo(this.model, 'change:cWonHasDiscount change:cWonDiscountType change:cWonDiscountPercent change:cWonDiscountAmount change:cWonDiscountAmountCurrency', function () {
                this.preview();
                this.ensureDiscountDropdownZIndex();
            });
            if (this.model.isNew() && this.model.get('cWonPlanId')) this.loadPlan();
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
            var name = this.model.get('cWonPlanName') || '';
            var id = this.model.get('cWonPlanId') || '';
            if (name && this.$elementName && typeof this.$elementName.val === 'function') {
                this.$elementName.val(name);
            }
            if (id && this.$elementId && typeof this.$elementId.val === 'function') {
                this.$elementId.val(id);
            }
            if (this.$el && typeof this.$el.find === 'function') {
                if (name) {
                    this.$el.find('input[data-name="cWonPlanName"]').val(name);
                    this.$el.find('.main-element').val(name);
                }
                if (id) {
                    this.$el.find('input[data-name="cWonPlanId"]').val(id);
                }
            }
            if (typeof this.controlCreateButtonVisibility === 'function') {
                this.controlCreateButtonVisibility();
            }
        },

        select: function (record) {
            var res = Dep.prototype.select.call(this, record);
            if (record) {
                var planId = record.id || (typeof record.get === 'function' ? record.get('id') : null);
                var planName = (typeof record.get === 'function' ? record.get('name') : record.name) || '';
                var planPrice = typeof record.get === 'function' ? record.get('monthlyPrice') : record.monthlyPrice;
                var planCurrency = typeof record.get === 'function' ? record.get('monthlyPriceCurrency') : record.monthlyPriceCurrency;
                var planPeriod = typeof record.get === 'function' ? record.get('billingPeriod') : record.billingPeriod;
                var values = {
                    cWonPlanId: planId,
                    cWonPlanName: planName
                };
                if (planPrice != null) {
                    values.cWonPlanPrice = planPrice;
                    values.cWonPlanPriceCurrency = planCurrency;
                }
                if (planPeriod) {
                    values.cWonPeriod = planPeriod;
                }
                this.model.set(values, { ui: true });
                if (this.$elementName && typeof this.$elementName.val === 'function') {
                    this.$elementName.val(planName);
                }
                if (this.$elementId && typeof this.$elementId.val === 'function') {
                    this.$elementId.val(planId);
                }
                this.preview();
            }
            return res;
        },

        captureSaved: function () {
            this.savedPlanId = this.model.get('cWonPlanId');
            this.savedProductId = this.model.get('cWonProductId');
            this.saved = {};
            ['cWonPlanPrice', 'cWonPlanPriceCurrency', 'cWonPeriod', 'cWonDiscountTotal', 'cWonDiscountTotalCurrency'].forEach(k => this.saved[k] = this.model.get(k));
            this.savedAmount = this.model.get('amount');
            this.savedCurrency = this.model.get('amountCurrency');
        },

        getSelectFilters: function () {
            return Object.assign({}, Dep.prototype.getSelectFilters.call(this) || {}, {
                product: {
                    type: 'equals',
                    attribute: 'productId',
                    value: this.model.get('cWonProductId') || this.model.get('cProductServiceId') || '__no_product__'
                },
                active: {
                    type: 'equals',
                    attribute: 'status',
                    value: 'Active'
                }
            });
        },

        loadPlan: async function () {
            const seq = ++this.sequence,
                id = this.model.get('cWonPlanId'),
                productId = this.model.get('cWonProductId') || this.model.get('cProductServiceId');
            this.priceError = null;
            this.pending = false;
            if (!id || !/^[a-z0-9]{17}$/i.test(id)) {
                this.model.set({ cWonPlanPrice: null, cWonPeriod: null, cWonInitialTotal: null, cWonDiscountTotal: null });
                return;
            }
            if (this.model.get('stage') !== 'Closed Won') return;
            if (!this.model.isNew() && id === this.savedPlanId && productId === this.savedProductId && this.saved.cWonPlanPrice != null) {
                this.model.set(Object.assign({}, this.saved));
                this.preview();
                return;
            }
            this.pending = true;
            try {
                const plan = await Espo.Ajax.getRequest('CSubscriptionPlan/' + encodeURIComponent(id), {}, { returnError: true });
                if (seq !== this.sequence) return;
                var currentProdId = this.model.get('cWonProductId') || this.model.get('cProductServiceId');
                if (currentProdId && plan.productId !== currentProdId) throw new Error('Plan mismatch');
                if (plan.status !== 'Active') throw new Error('Plan inactive');
                const values = {
                    cWonPlanPrice: plan.monthlyPrice,
                    cWonPlanPriceCurrency: plan.monthlyPriceCurrency,
                    cWonPeriod: plan.billingPeriod
                };
                if (!this.model.get('cWonStartDate')) values.cWonStartDate = this.model.get('closeDate');
                if (!this.model.get('cWonHasSetupFee') || this.model.get('cWonSetupFee') == null) {
                    values.cWonSetupFeeCurrency = plan.monthlyPriceCurrency;
                }
                if (!this.model.get('cWonDiscountAmountCurrency')) {
                    values.cWonDiscountAmountCurrency = plan.monthlyPriceCurrency;
                }
                this.model.set(values);
                this.preview();
            } catch (e) {
                if (seq === this.sequence) {
                    this.priceError = 'Could not verify this plan. Select an active plan belonging to the chosen product.';
                    Espo.Ui.warning(this.priceError);
                }
            } finally {
                if (seq === this.sequence) this.pending = false;
            }
        },

        preview: function () {
            if (this.model.get('stage') !== 'Closed Won' || !this.model.get('cWonPlanId') || this.model.get('cWonPlanPrice') == null) return;
            const currency = this.model.get('cWonPlanPriceCurrency');
            const basePrice = Number(this.model.get('cWonPlanPrice')) || 0;

            // Setup fee
            const withFee = this.model.get('cWonHasSetupFee');
            let fee = withFee ? this.model.get('cWonSetupFee') : 0;
            if (withFee && (fee == null || this.model.get('cWonSetupFeeCurrency') !== currency)) {
                this.model.set('cWonInitialTotal', null);
                return;
            }
            if (!Number.isFinite(Number(fee)) || Number(fee) < 0) {
                this.model.set('cWonInitialTotal', null);
                return;
            }
            fee = Number(fee);

            // Discount
            let discount = 0;
            const withDiscount = this.model.get('cWonHasDiscount');
            if (withDiscount) {
                const discountType = this.model.get('cWonDiscountType') || 'Percentage';
                if (discountType === 'Percentage') {
                    const pct = this.model.get('cWonDiscountPercent');
                    if (pct == null || !Number.isFinite(Number(pct)) || Number(pct) < 0 || Number(pct) > 100) {
                        this.model.set('cWonInitialTotal', null);
                        return;
                    }
                    discount = Math.round((basePrice * (Number(pct) / 100) + Number.EPSILON) * 100) / 100;
                } else if (discountType === 'Amount') {
                    const amt = this.model.get('cWonDiscountAmount');
                    const amtCurrency = this.model.get('cWonDiscountAmountCurrency') || currency;
                    if (amt == null || !Number.isFinite(Number(amt)) || Number(amt) < 0 || amtCurrency !== currency) {
                        this.model.set('cWonInitialTotal', null);
                        return;
                    }
                    discount = Math.min(basePrice, Math.round((Number(amt) + Number.EPSILON) * 100) / 100);
                }
            }
            discount = Math.min(basePrice, Math.max(0, discount));
            this.model.set({
                cWonDiscountTotal: discount,
                cWonDiscountTotalCurrency: currency
            });

            const netPrice = Math.max(0, Math.round((basePrice - discount + Number.EPSILON) * 100) / 100);
            const total = Math.round((netPrice + fee + Number.EPSILON) * 100) / 100;
            this.model.set({
                cWonInitialTotal: total,
                cWonInitialTotalCurrency: currency,
                amount: total,
                amountCurrency: currency
            });
            this.ensureDiscountDropdownZIndex();
        },

        validateWonPlan: function () {
            if (this.model.get('stage') !== 'Closed Won') return false;
            let message = this.priceError;
            if (this.pending) message = 'Wait for the selected plan price to load.';
            const prod = this.model.get('cWonProductId') || this.model.get('cProductServiceId');
            if (!prod) {
                this.redirectScreenToField('cProductService', 'Select a product before saving a Closed Won opportunity.');
                return true;
            }
            var contactsIds = this.model.get('contactsIds') || [];
            var hasContact = (this.model.get('contactId') || (Array.isArray(contactsIds) && contactsIds.length > 0));
            if (!this.model.get('accountId') && !hasContact && !this.model.isConvertMode) {
                this.redirectScreenToField('account', 'Select an Account or primary Contact for the subscription.');
                return true;
            }
            if (prod && !this.model.get('cWonPlanId')) message = 'Choose a subscription plan for the selected product.';
            if (this.model.get('cWonHasDiscount')) {
                const dt = this.model.get('cWonDiscountType') || 'Percentage';
                if (dt === 'Percentage') {
                    const p = this.model.get('cWonDiscountPercent');
                    if (p == null || !Number.isFinite(Number(p)) || Number(p) < 0 || Number(p) > 100) {
                        message = message || 'Enter a valid discount percentage between 0 and 100.';
                    }
                } else if (dt === 'Amount') {
                    const a = this.model.get('cWonDiscountAmount');
                    if (a == null || !Number.isFinite(Number(a)) || Number(a) < 0) {
                        message = message || 'Enter a valid discount amount.';
                    }
                }
            }
            if (this.model.get('cWonPlanId') && this.model.get('cWonInitialTotal') == null) {
                message = message || 'Enter valid pricing, discount, or setup fee values in the plan currency.';
            }
            if (message) {
                this.showValidationMessage(message);
                return true;
            }
            return false;
        },

        redirectScreenToField: function (fieldName, message) {
            let targetView = null;
            const parent = typeof this.getParentView === 'function' ? this.getParentView() : null;
            const recordView = (parent && typeof parent.getFieldView === 'function')
                ? parent
                : (this.recordView || (parent && parent.recordView) || null);

            if (recordView && typeof recordView.getFieldView === 'function') {
                targetView = recordView.getFieldView(fieldName);
                if (!targetView && fieldName === 'account') {
                    targetView = recordView.getFieldView('contacts') || recordView.getFieldView('contact');
                } else if (!targetView && fieldName === 'contacts') {
                    targetView = recordView.getFieldView('account');
                }
            }

            if (targetView && typeof targetView.showValidationMessage === 'function') {
                targetView.showValidationMessage(message);
            } else if (typeof window !== 'undefined' && window.Espo && Espo.Ui && Espo.Ui.warning) {
                Espo.Ui.warning(message);
            }

            let $target = (targetView && targetView.$el && targetView.$el.length) ? targetView.$el : null;
            if (!$target && typeof $ !== 'undefined') {
                $target = $('[data-name="' + fieldName + '"]').first();
                if ((!$target || !$target.length) && fieldName === 'account') {
                    $target = $('[data-name="contacts"]').first();
                }
            }

            if ($target && $target.length) {
                const el = $target[0];
                if (el && typeof el.scrollIntoView === 'function') {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                if (typeof $target.addClass === 'function') {
                    $target.addClass('has-error highlight-target');
                    setTimeout(function () {
                        $target.removeClass('highlight-target');
                    }, 2000);
                }
                if (typeof $target.find === 'function') {
                    const $input = $target.find('input, button, select').filter(':visible').first();
                    if ($input && typeof $input.focus === 'function') {
                        $input.focus();
                    }
                }
            }
        },

        ensureDiscountDropdownZIndex: function () {
            if (typeof $ === 'undefined') return;
            try {
                const $discountTypeCell = $('[data-name="cWonDiscountType"]').closest('.cell');
                if ($discountTypeCell.length) {
                    $discountTypeCell.closest('.row').addClass('row-discount-type');
                }
                const $percentCell = $('[data-name="cWonDiscountPercent"]').closest('.cell');
                if ($percentCell.length) {
                    $percentCell.closest('.row').addClass('row-discount-value');
                }
                const $amountCell = $('[data-name="cWonDiscountAmount"]').closest('.cell');
                if ($amountCell.length) {
                    $amountCell.closest('.row').addClass('row-discount-value');
                }
            } catch (e) {}
        },

        afterRender: function () {
            if (Dep.prototype.afterRender) {
                Dep.prototype.afterRender.call(this);
            }
            this.ensureDiscountDropdownZIndex();
        }
    });
});
