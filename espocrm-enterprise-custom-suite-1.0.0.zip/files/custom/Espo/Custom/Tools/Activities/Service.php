<?php

namespace Espo\Custom\Tools\Activities;

use Espo\Core\Acl;
use Espo\Core\Select\Helpers\RelationQueryHelper;
use Espo\Core\ServiceFactory;
use Espo\Core\Utils\Config;
use Espo\Core\Utils\Metadata;
use Espo\Core\FieldProcessing\ListLoadProcessor;
use Espo\Core\Record\ServiceContainer as RecordServiceContainer;
use Espo\Core\Select\SelectBuilderFactory;
use Espo\Entities\User;
use Espo\Modules\Crm\Entities\Call;
use Espo\Modules\Crm\Entities\Meeting;
use Espo\Core\Record\Collection as RecordCollection;
use Espo\Core\Select\SearchParams;
use Espo\Modules\Crm\Tools\Activities\FetchParams;
use Espo\Modules\Crm\Tools\Activities\Service as BaseService;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Query\Select;

/**
 * Activities/history service with an optional product-service filter.
 *
 * When productServiceIds is present, activities tied to one of those product services
 * or directly parented to the record are returned.
 */
class Service extends BaseService
{
    public const PRODUCT_SERVICE_ENTITY_TYPE = 'CProductService';
    public const PRODUCT_SERVICE_CALL_LINK = 'calls';
    public const PRODUCT_SERVICE_MEETING_LINK = 'meetings';

    private EntityManager $em;

    /** @var string[]|null */
    private ?array $productServiceIdList = null;

    /** @var string[]|null */
    private ?array $callIdList = null;

    /** @var string[]|null */
    private ?array $meetingIdList = null;

    public function __construct(
        ListLoadProcessor $listLoadProcessor,
        RecordServiceContainer $recordServiceContainer,
        SelectBuilderFactory $selectBuilderFactory,
        Config $config,
        Metadata $metadata,
        Acl $acl,
        ServiceFactory $serviceFactory,
        EntityManager $entityManager,
        User $user,
        RelationQueryHelper $relationQueryHelper,
    ) {
        parent::__construct(
            $listLoadProcessor,
            $recordServiceContainer,
            $selectBuilderFactory,
            $config,
            $metadata,
            $acl,
            $serviceFactory,
            $entityManager,
            $user,
            $relationQueryHelper,
        );

        $this->em = $entityManager;
    }

    /**
     * Set the filter. Pass `null` for "no filter".
     *
     * @param ?string[] $idList
     */
    public function setProductServiceIdList(?array $idList): void
    {
        $this->productServiceIdList = $idList === null ?
            null :
            array_values(array_unique($idList));

        $this->callIdList = null;
        $this->meetingIdList = null;
    }

    /**
     * Set the filter from a raw query-param value (CSV string, array or absent).
     */
    public function setProductServiceIdListFromRaw(mixed $raw): void
    {
        if ($raw === null) {
            $this->setProductServiceIdList(null);

            return;
        }

        $itemList = is_array($raw) ? $raw : explode(',', (string) $raw);

        $idList = [];

        foreach ($itemList as $item) {
            $item = trim((string) $item);

            if ($item === '' || !preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $item)) {
                continue;
            }

            $idList[] = $item;
        }

        $this->setProductServiceIdList($idList);
    }

    public function clearProductServiceIdList(): void
    {
        $this->setProductServiceIdList(null);
    }

    private function createEmptyRecordCollection(): RecordCollection
    {
        return new RecordCollection(new \Espo\ORM\EntityCollection(), 0);
    }

    public function getHistory(string $scope, string $id, FetchParams $params): RecordCollection
    {
        if ($scope === 'EmptyParent' || !$this->em->getMetadata()->has($scope)) {
            return $this->createEmptyRecordCollection();
        }

        $result = parent::getHistory($scope, $id, $params);
        if ($scope === 'Opportunity') {
            $result = $this->mergeInheritedLeadHistory($id, $result, $params);
        }
        $this->enrichActivitiesWithLatestDescriptions($result);

        return $result;
    }

    public function getActivities(string $scope, string $id, FetchParams $params): RecordCollection
    {
        if ($scope === 'EmptyParent' || !$this->em->getMetadata()->has($scope)) {
            return $this->createEmptyRecordCollection();
        }

        $result = parent::getActivities($scope, $id, $params);
        $this->enrichActivitiesWithLatestDescriptions($result);

        return $result;
    }

    public function findActivitiesEntityType(
        string $scope,
        string $id,
        string $entityType,
        bool $isHistory,
        SearchParams $searchParams
    ): RecordCollection {
        if ($scope === 'EmptyParent' || !$this->em->getMetadata()->has($scope)) {
            return $this->createEmptyRecordCollection();
        }

        $result = parent::findActivitiesEntityType($scope, $id, $entityType, $isHistory, $searchParams);
        if ($scope === 'Opportunity' && $isHistory) {
            $result = $this->mergeInheritedLeadHistory($id, $result, $searchParams, $entityType);
        }
        $this->enrichActivitiesWithLatestDescriptions($result);

        return $result;
    }

    private function mergeInheritedLeadHistory(
        string $opportunityId,
        RecordCollection $result,
        FetchParams|SearchParams $params,
        ?string $filterEntityType = null
    ): RecordCollection {
        try {
            $leadId = null;
            $leadName = 'Lead';
            if ($this->em->hasRepository('Opportunity')) {
                $opp = $this->em->getEntityById('Opportunity', $opportunityId);
                if ($opp && $opp->hasAttribute('originalLeadId') && $opp->get('originalLeadId')) {
                    $leadId = $opp->get('originalLeadId');
                }
            }
            if (!$leadId && $this->em->hasRepository('Lead')) {
                $lead = $this->em->getRDBRepository('Lead')->where(['createdOpportunityId' => $opportunityId])->findOne();
                if ($lead) {
                    $leadId = $lead->getId();
                    $leadName = $lead->get('name') ?: 'Lead';
                }
            } else if ($leadId && $this->em->hasRepository('Lead')) {
                $lead = $this->em->getEntityById('Lead', $leadId);
                if ($lead) {
                    $leadName = $lead->get('name') ?: 'Lead';
                }
            }

            if (!$leadId) {
                return $result;
            }

            $offset = $params->getOffset() ?? 0;
            $maxSize = $params->getMaxSize();
            $topK = ($maxSize && $maxSize > 0) ? ($offset + $maxSize) : null;

            if ($filterEntityType !== null && $params instanceof SearchParams) {
                $topParams = $params->withOffset(0)->withMaxSize($topK);
                $oppResult = ($offset > 0)
                    ? parent::findActivitiesEntityType('Opportunity', $opportunityId, $filterEntityType, true, $topParams)
                    : $result;
                $leadHistory = parent::findActivitiesEntityType('Lead', $leadId, $filterEntityType, true, $topParams);
            } else if ($params instanceof FetchParams) {
                $topParams = new FetchParams($topK, 0, $params->getEntityType());
                $oppResult = ($offset > 0)
                    ? parent::getHistory('Opportunity', $opportunityId, $topParams)
                    : $result;
                $leadHistory = parent::getHistory('Lead', $leadId, $topParams);
            } else {
                return $result;
            }

            $merged = [];
            $existingIds = [];
            foreach ($oppResult->getCollection() as $entity) {
                $merged[] = $entity;
                $existingIds[$entity->getId()] = true;
            }

            $duplicateCount = 0;
            foreach ($leadHistory->getCollection() as $item) {
                if (isset($existingIds[$item->getId()])) {
                    $duplicateCount++;
                    continue;
                }
                $item->set('isInheritedFromLead', true);
                $item->set('inheritedLeadId', $leadId);
                $item->set('inheritedLeadName', $leadName);
                $merged[] = $item;
                $existingIds[$item->getId()] = true;
            }

            usort($merged, function (Entity $a, Entity $b): int {
                $dateA = $a->get('dateStart') ?: $a->get('createdAt') ?: '';
                $dateB = $b->get('dateStart') ?: $b->get('createdAt') ?: '';
                $cmp = strcmp($dateB, $dateA);
                if ($cmp !== 0) {
                    return $cmp;
                }
                $createdA = $a->get('createdAt') ?: '';
                $createdB = $b->get('createdAt') ?: '';
                return strcmp($createdB, $createdA);
            });

            $paged = ($maxSize && $maxSize > 0)
                ? array_slice($merged, $offset, $maxSize)
                : array_slice($merged, $offset);

            $oppTotal = (int) ($oppResult->getTotal() ?? 0);
            $leadTotal = (int) ($leadHistory->getTotal() ?? 0);
            $combinedTotal = max(count($merged), $oppTotal + $leadTotal - $duplicateCount);

            return new RecordCollection(
                new \Espo\ORM\EntityCollection($paged),
                $combinedTotal
            );
        } catch (\Throwable $e) {
            // Fail safely without disrupting history output
            return $result;
        }
    }

    private function enrichActivitiesWithLatestDescriptions(RecordCollection $result): void
    {
        try {
            $collection = $result->getCollection();
            if (count($collection) === 0) {
                return;
            }

            $callIds = [];
            $meetingIds = [];

            foreach ($collection as $item) {
                if ($item->getEntityType() === Call::ENTITY_TYPE) {
                    $callIds[] = $item->getId();
                } else if ($item->getEntityType() === Meeting::ENTITY_TYPE) {
                    $meetingIds[] = $item->getId();
                }
            }

            $callMap = [];
            if (!empty($callIds) && $this->em->hasRepository(Call::ENTITY_TYPE)) {
                $selectFields = ['id', 'description'];
                $seedCall = $this->em->getNewEntity(Call::ENTITY_TYPE);
                if ($seedCall->hasAttribute('cDescriptionDiff')) {
                    $selectFields[] = 'cDescriptionDiff';
                }
                $calls = $this->em->getRDBRepository(Call::ENTITY_TYPE)
                    ->where(['id' => $callIds])
                    ->select($selectFields)
                    ->find();
                foreach ($calls as $call) {
                    $callMap[$call->getId()] = [
                        'description' => $call->get('description'),
                        'cDescriptionDiff' => $call->hasAttribute('cDescriptionDiff') ? $call->get('cDescriptionDiff') : null,
                    ];
                }
            }

            $meetingMap = [];
            if (!empty($meetingIds) && $this->em->hasRepository(Meeting::ENTITY_TYPE)) {
                $selectFields = ['id', 'description'];
                $seedMeeting = $this->em->getNewEntity(Meeting::ENTITY_TYPE);
                if ($seedMeeting->hasAttribute('cDescriptionDiff')) {
                    $selectFields[] = 'cDescriptionDiff';
                }
                $meetings = $this->em->getRDBRepository(Meeting::ENTITY_TYPE)
                    ->where(['id' => $meetingIds])
                    ->select($selectFields)
                    ->find();
                foreach ($meetings as $meeting) {
                    $meetingMap[$meeting->getId()] = [
                        'description' => $meeting->get('description'),
                        'cDescriptionDiff' => $meeting->hasAttribute('cDescriptionDiff') ? $meeting->get('cDescriptionDiff') : null,
                    ];
                }
            }

            foreach ($collection as $item) {
                $id = $item->getId();
                if ($item->getEntityType() === Call::ENTITY_TYPE && isset($callMap[$id])) {
                    $item->set('description', $callMap[$id]['description']);
                    if ($callMap[$id]['cDescriptionDiff'] !== null) {
                        $item->set('cDescriptionDiff', $callMap[$id]['cDescriptionDiff']);
                    }
                } else if ($item->getEntityType() === Meeting::ENTITY_TYPE && isset($meetingMap[$id])) {
                    $item->set('description', $meetingMap[$id]['description']);
                    if ($meetingMap[$id]['cDescriptionDiff'] !== null) {
                        $item->set('cDescriptionDiff', $meetingMap[$id]['cDescriptionDiff']);
                    }
                }
            }
        } catch (\Throwable $e) {
            // Fail safely without breaking activities or history output
        }
    }

    protected function getActivitiesQuery(Entity $entity, string $scope, array $statusList = [])
    {
        $query = parent::getActivitiesQuery($entity, $scope, $statusList);

        if ($this->productServiceIdList === null || !$this->em->hasRepository(self::PRODUCT_SERVICE_ENTITY_TYPE)) {
            return $query;
        }

        if ($scope === Call::ENTITY_TYPE) {
            $callIdList = $this->getCallIdList();

            return $this->applyActivityFilter($query, $entity, $callIdList);
        }

        if ($scope === Meeting::ENTITY_TYPE) {
            $meetingIdList = $this->getMeetingIdList();

            return $this->applyActivityFilter($query, $entity, $meetingIdList);
        }

        return $query;
    }

    /**
     * @param Select|Select[] $query
     * @param string[] $activityIdList
     * @return Select|Select[]
     */
    private function applyActivityFilter($query, Entity $entity, array $activityIdList)
    {
        $queryList = is_array($query) ? $query : [$query];
        $resultList = [];

        $parentId = $entity->getId();
        $parentType = $entity->getEntityType();

        foreach ($queryList as $itemQuery) {
            $builder = $this->em
                ->getQueryBuilder()
                ->select()
                ->clone($itemQuery);

            if (!empty($activityIdList)) {
                $builder->where([
                    'OR' => [
                        'id' => $activityIdList,
                        [
                            'parentId' => $parentId,
                            'parentType' => $parentType,
                        ],
                    ],
                ]);
            } else {
                $builder->where([
                    'parentId' => $parentId,
                    'parentType' => $parentType,
                ]);
            }

            $resultList[] = $builder->build();
        }

        return is_array($query) ? $resultList : $resultList[0];
    }

    /**
     * @return string[]
     */
    private function getCallIdList(): array
    {
        if ($this->callIdList !== null) {
            return $this->callIdList;
        }

        $this->callIdList = $this->getLinkedActivityIds(self::PRODUCT_SERVICE_CALL_LINK);

        return $this->callIdList;
    }

    /**
     * @return string[]
     */
    private function getMeetingIdList(): array
    {
        if ($this->meetingIdList !== null) {
            return $this->meetingIdList;
        }

        $this->meetingIdList = $this->getLinkedActivityIds(self::PRODUCT_SERVICE_MEETING_LINK);

        return $this->meetingIdList;
    }

    /**
     * @return string[]
     */
    private function getLinkedActivityIds(string $relationName): array
    {
        if (!$this->em->hasRepository(self::PRODUCT_SERVICE_ENTITY_TYPE)) {
            return [];
        }

        $idList = [];

        foreach ($this->productServiceIdList ?? [] as $productServiceId) {
            $productService = $this->em->getEntityById(
                self::PRODUCT_SERVICE_ENTITY_TYPE,
                $productServiceId
            );

            if (!$productService || !$productService->hasRelation($relationName)) {
                continue;
            }

            $collection = $this->em
                ->getRelation($productService, $relationName)
                ->select(['id'])
                ->find();

            foreach ($collection as $item) {
                $idList[] = $item->getId();
            }
        }

        return array_values(array_unique($idList));
    }
}
