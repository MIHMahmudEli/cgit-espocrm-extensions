define('custom:views/c-product-service/record/edit', ['views/record/edit'], function (Dep) {

    return Dep.extend({

        hasSubscriptionScope: function () {
            var meta = this.getMetadata();
            if (!meta) return false;
            if (typeof meta.has === 'function' && meta.has(['scopes', 'CSubscriptionPlan'])) {
                return true;
            }
            if (typeof meta.get === 'function') {
                return Boolean(meta.get(['scopes', 'CSubscriptionPlan']));
            }
            return false;
        },

        setup: function () {
            Dep.prototype.setup.call(this);

            var self = this;

            this.model.getTypeOptions = function () {
                var allOptions = (self.getMetadata().get(['entityDefs', 'CProductService', 'fields', 'type', 'options']) || [
                    'Product', 'Service', 'Package', 'Custom Development'
                ]).slice();

                if (!self.hasSubscriptionScope()) {
                    return allOptions.filter(function (opt) {
                        return opt !== 'Subscription';
                    });
                }
                if (allOptions.indexOf('Subscription') === -1) {
                    allOptions.splice(3, 0, 'Subscription');
                }
                return allOptions;
            };

            this.listenTo(this.model, 'change:type', this.handleTypeChange.bind(this));
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            var hasSubScope = this.hasSubscriptionScope();
            var typeView = this.getFieldView('type');

            if (!hasSubScope) {
                if (typeView) {
                    var cleanOpts = (typeView.params.options || []).filter(function (opt) {
                        return opt !== 'Subscription';
                    });
                    if (typeof typeView.setOptionList === 'function') {
                        typeView.setOptionList(cleanOpts);
                    } else {
                        typeView.params.options = cleanOpts;
                    }
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('select[data-name="type"] option[value="Subscription"]').remove();
                    this.$el.find('.cell[data-name="type"] option[value="Subscription"]').remove();
                    this.$el.find('.selectize-control [data-value="Subscription"]').remove();
                    this.$el.find('.selectize-dropdown [data-value="Subscription"]').remove();
                }
            } else {
                if (typeView && Array.isArray(typeView.params.options) && typeView.params.options.indexOf('Subscription') === -1) {
                    var fullOpts = typeView.params.options.slice();
                    fullOpts.splice(3, 0, 'Subscription');
                    if (typeof typeView.setOptionList === 'function') {
                        typeView.setOptionList(fullOpts);
                    } else {
                        typeView.params.options = fullOpts;
                    }
                }
            }

            this.handleTypeChange();
        },

        handleTypeChange: function () {
            var hasSubScope = this.hasSubscriptionScope();
            var isSubscription = hasSubScope && (this.model.get('type') === 'Subscription');

            if (isSubscription) {
                if (typeof this.showField === 'function') {
                    this.showField('cRootDomain');
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('.cell[data-name="cRootDomain"]').show();
                    this.$el.find('.field[data-name="cRootDomain"]').show();
                    this.$el.find('[data-name="cRootDomain"]').closest('.cell').show();
                }
            } else {
                if (typeof this.hideField === 'function') {
                    this.hideField('cRootDomain');
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('.cell[data-name="cRootDomain"]').hide();
                    this.$el.find('.field[data-name="cRootDomain"]').hide();
                    this.$el.find('[data-name="cRootDomain"]').closest('.cell').hide();
                }
            }
        }

    });

});
