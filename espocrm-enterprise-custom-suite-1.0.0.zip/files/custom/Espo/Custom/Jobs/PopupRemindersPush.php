<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM — Open Source CRM application.
 * Copyright (C) 2014-2026 EspoCRM, Inc.
 * Website: https://www.espocrm.com
 ************************************************************************/

namespace Espo\Custom\Jobs;

use DateInterval;
use DateTimeImmutable;
use DateTimeZone;
use Espo\Core\Job\JobDataLess;
use Espo\Core\Name\Field;
use Espo\Core\ORM\Entity as CoreEntity;
use Espo\Core\ORM\EntityManager;
use Espo\Core\Utils\Config;
use Espo\Core\Utils\DateTime as DateTimeUtil;
use Espo\Core\Utils\Language;
use Espo\Core\Utils\Log;
use Espo\Core\Utils\Metadata;
use Espo\Custom\Notification\NotificationService;
use Espo\Entities\Notification;
use Espo\Modules\Crm\Entities\Call;
use Espo\Modules\Crm\Entities\Meeting;
use Espo\Modules\Crm\Entities\Reminder;
use Espo\Modules\Crm\Entities\Task;
use Throwable;

/**
 * Mirrors EspoCRM's standard Popup Reminders (Tasks, Meetings, Calls) to
 * both in-app notifications and Web Push even when WebSocket is disabled
 * or the browser tab is closed.
 *
 * Call/Meeting start-time (seconds === 0) reminders are already handled by
 * CallRouteReminders and MeetingReminders; this job covers Task reminders and
 * all advance popup reminders (e.g., 10m / 15m / 1h before) without duplicates.
 */
class PopupRemindersPush implements JobDataLess
{
    private const DEFAULT_PAST_HOURS = 24;

    public function __construct(
        private EntityManager $entityManager,
        private Metadata $metadata,
        private Config $config,
        private Language $language,
        private Log $log,
        private NotificationService $notificationService,
    ) {}

    public function run(): void
    {
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));

        $pastHours = (int) $this->config->get('reminderPastHours', self::DEFAULT_PAST_HOURS);
        if ($pastHours < 1) {
            $pastHours = self::DEFAULT_PAST_HOURS;
        }

        $nowString = $now->format(DateTimeUtil::SYSTEM_DATE_TIME_FORMAT);
        $windowString = $now
            ->sub(new DateInterval('PT' . $pastHours . 'H'))
            ->format(DateTimeUtil::SYSTEM_DATE_TIME_FORMAT);

        /** @var iterable<Reminder> $reminderList */
        $reminderList = $this->entityManager
            ->getRDBRepositoryByClass(Reminder::class)
            ->where([
                'type' => Reminder::TYPE_POPUP,
                'remindAt<=' => $nowString,
                'startAt>' => $windowString,
            ])
            ->find();

        foreach ($reminderList as $reminder) {
            try {
                $this->processReminder($reminder);
            } catch (Throwable $e) {
                $this->log->error(sprintf(
                    'Job PopupRemindersPush: %s [%s] %s (Reminder %s)',
                    get_class($e),
                    (string) $e->getCode(),
                    $e->getMessage(),
                    (string) $reminder->getId()
                ));
            }
        }
    }

    private function processReminder(Reminder $reminder): void
    {
        $userId = (string) ($reminder->getUserId() ?? '');
        $entityType = (string) ($reminder->getTargetEntityType() ?? '');
        $entityId = (string) ($reminder->getTargetEntityId() ?? '');

        if ($userId === '' || $entityType === '' || $entityId === '' || !$this->entityManager->hasRepository($entityType)) {
            return;
        }

        $seconds = (int) ($reminder->get('seconds') ?? 0);

        // CallRouteReminders and MeetingReminders own the t=0 start-time push for Calls & Meetings.
        if (in_array($entityType, [Call::ENTITY_TYPE, Meeting::ENTITY_TYPE], true) && $seconds === 0) {
            return;
        }

        $entity = $this->entityManager->getEntityById($entityType, $entityId);
        if (!$entity) {
            return;
        }

        if ($this->isCompletedOrCanceled($entityType, $entity)) {
            return;
        }

        if (
            $entity instanceof CoreEntity &&
            $entity->hasLinkMultipleField('users') &&
            $entity->hasAttribute('usersColumns')
        ) {
            $status = $entity->getLinkMultipleColumn('users', 'status', $userId);
            if ($status === Meeting::ATTENDEE_STATUS_DECLINED) {
                return;
            }
        }

        $startAt = (string) ($reminder->get('startAt') ?? '');
        $actionId = md5('PopupReminder|' . $reminder->getId() . '|' . $startAt);

        $existing = $this->entityManager
            ->getRDBRepository(Notification::ENTITY_TYPE)
            ->where([
                Notification::ATTR_USER_ID => $userId,
                Notification::ATTR_ACTION_ID => $actionId,
            ])
            ->findOne();

        if ($existing !== null) {
            return;
        }

        $entityName = trim((string) ($entity->get(Field::NAME) ?? ''));
        $entityLabel = (string) $this->language->translateLabel($entityType, 'scopeNames');
        $displayName = $entityName !== '' ? $entityName : $entityLabel;

        $category = match ($entityType) {
            Task::ENTITY_TYPE => 'task',
            Meeting::ENTITY_TYPE => 'meeting',
            Call::ENTITY_TYPE => 'callRoute',
            default => 'calendar',
        };

        $timingText = $this->formatTiming($seconds);
        $pushTitle = "{$entityLabel} Reminder";
        $pushBody = $seconds === 0
            ? "{$displayName} is due now."
            : "{$displayName} starts {$timingText}.";

        $message = "**{$pushTitle}**: {$entityType} {$displayName} " . ($seconds === 0 ? 'is due now.' : "starts {$timingText}.");

        $this->notificationService->notifyUser(
            $userId,
            [
                'message' => $message,
                'entityType' => $entityType,
                'entityId' => $entityId,
                'entityName' => $entityName,
                'url' => "#{$entityType}/view/{$entityId}",
                'note' => ['userId' => $userId],
            ],
            [
                'actionId' => $actionId,
                'related' => $entity,
                'popup' => false, // Reminder row already exists for in-app popup polling
                'category' => $category,
                'payloadType' => 'popup-reminder',
                'pushTitle' => $pushTitle,
                'pushBody' => $pushBody,
                'tag' => 'popup-' . $entityType . '-' . $entityId . '-' . $seconds,
                'urgency' => 'high',
            ]
        );
    }

    private function isCompletedOrCanceled(string $entityType, \Espo\ORM\Entity $entity): bool
    {
        $status = $entity->get('status');
        if (!is_string($status) || $status === '') {
            return false;
        }

        $ignoreList = array_merge(
            (array) $this->metadata->get(['scopes', $entityType, 'completedStatusList']),
            (array) $this->metadata->get(['scopes', $entityType, 'canceledStatusList'])
        );

        return in_array($status, $ignoreList, true);
    }

    private function formatTiming(int $seconds): string
    {
        if ($seconds < 60) {
            return "in {$seconds} seconds";
        }
        if ($seconds < 3600) {
            $m = (int) round($seconds / 60);
            return "in {$m} minute" . ($m === 1 ? '' : 's');
        }
        if ($seconds < 86400) {
            $h = (int) round($seconds / 3600);
            return "in {$h} hour" . ($h === 1 ? '' : 's');
        }
        $d = (int) round($seconds / 86400);
        return "in {$d} day" . ($d === 1 ? '' : 's');
    }
}
