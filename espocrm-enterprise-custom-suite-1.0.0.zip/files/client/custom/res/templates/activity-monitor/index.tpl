<div class="activity-monitor-container">
    <!-- Page Header (EspoCRM Standard) -->
    <div class="page-header">
        <div class="row">
            <div class="col-sm-7 col-xs-12">
                <h3>
                    <span class="fas fa-chart-line text-muted"></span>
                    <span>{{translate 'OrganizationActivityMonitor' scope='ActivityMonitor'}}</span>
                </h3>
                <div class="text-muted small" style="margin-top: 4px;">
                    <span class="fas fa-clock"></span> <strong>{{currentRangeLabel}}</strong>
                    &nbsp;&bull;&nbsp;
                    <span class="fas fa-globe"></span> {{timezone}}
                </div>
            </div>
            <div class="col-sm-5 col-xs-12">
                <div class="pull-right btn-group" style="margin-top: 10px;">
                    <button type="button" class="btn btn-default btn-sm {{#if autoRefresh}}btn-success active{{/if}}" data-action="toggleAutoRefresh" title="{{translate 'AutoRefresh' scope='ActivityMonitor'}}">
                        <span class="fas fa-sync-alt {{#if autoRefresh}}fa-spin{{/if}}"></span>
                        <span>{{#if autoRefresh}}Auto-Refresh On{{else}}Auto-Refresh (30s){{/if}}</span>
                    </button>
                    <button type="button" class="btn btn-default btn-sm" data-action="refresh" title="{{translate 'Refresh' scope='ActivityMonitor'}}">
                        <span class="fas fa-redo"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Management KPI Summary Ribbon -->
    <div class="panel panel-default activity-summary-bar">
        <div class="panel-body">
            <div class="row text-center">
                <div class="col-xs-6 col-sm-2 col-sm-offset-1 activity-stat-col">
                    <div class="activity-stat-value text-primary">{{summary.totalActivities}}</div>
                    <div class="activity-stat-label">{{translate 'TotalActivities' scope='ActivityMonitor'}}</div>
                </div>
                <div class="col-xs-6 col-sm-2 activity-stat-col">
                    <div class="activity-stat-value text-success">{{summary.typeCounts.Created}}</div>
                    <div class="activity-stat-label">
                        <span class="fas fa-plus-circle text-success"></span> {{translate 'Creations' scope='ActivityMonitor'}}
                    </div>
                </div>
                <div class="col-xs-4 col-sm-2 activity-stat-col">
                    <div class="activity-stat-value text-info">{{summary.typeCounts.Updated}}</div>
                    <div class="activity-stat-label">
                        <span class="fas fa-edit text-info"></span> {{translate 'Updates' scope='ActivityMonitor'}}
                    </div>
                </div>
                <div class="col-xs-4 col-sm-2 activity-stat-col">
                    <div class="activity-stat-value text-warning">{{summary.typeCounts.statusChanged}}</div>
                    <div class="activity-stat-label">
                        <span class="fas fa-exchange-alt text-warning"></span> {{translate 'StatusChanges' scope='ActivityMonitor'}}
                    </div>
                </div>
                <div class="col-xs-4 col-sm-2 activity-stat-col">
                    <div class="activity-stat-value text-danger">{{summary.typeCounts.Deleted}}</div>
                    <div class="activity-stat-label">
                        <span class="fas fa-trash-alt text-danger"></span> {{translate 'Deletions' scope='ActivityMonitor'}}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter & Search Toolbar (EspoCRM Standard) -->
    <div class="panel panel-default activity-filter-panel">
        <div class="panel-body">
            <!-- Row 1: Quick Ranges + Search Input -->
            <div class="row" style="margin-bottom: 10px;">
                <div class="col-md-7 col-sm-12" style="margin-bottom: 8px;">
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-default {{#if is3hActive}}btn-primary active{{/if}}" data-action="quickFilter" data-range="3h">
                            {{translate 'Last3Hours' scope='ActivityMonitor'}}
                        </button>
                        <button type="button" class="btn btn-default {{#if is24hActive}}btn-primary active{{/if}}" data-action="quickFilter" data-range="24h">
                            {{translate 'Last24Hours' scope='ActivityMonitor'}}
                        </button>
                        <button type="button" class="btn btn-default {{#if is7dActive}}btn-primary active{{/if}}" data-action="quickFilter" data-range="7d">
                            {{translate 'Last7Days' scope='ActivityMonitor'}}
                        </button>
                        <button type="button" class="btn btn-default {{#if isCustomActive}}btn-primary active{{/if}}" data-action="quickFilter" data-range="custom">
                            <span class="far fa-calendar-alt"></span> {{translate 'CustomRange' scope='ActivityMonitor'}}...
                        </button>
                    </div>
                </div>
                <div class="col-md-5 col-sm-12">
                    <div class="input-group input-group-sm">
                        <input type="text" class="form-control" name="search" placeholder="Search record name, user, or change..." value="{{search}}">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button" data-action="applyFilters" title="Search">
                                <span class="fas fa-search"></span>
                            </button>
                            {{#if search}}
                            <button class="btn btn-default" type="button" data-action="clearSearch" title="Clear search">
                                <span class="fas fa-times"></span>
                            </button>
                            {{/if}}
                        </span>
                    </div>
                </div>
            </div>

            {{#if isCustomActive}}
            <!-- Custom Date & Time Range Box (Clean, Proportional, Auto-closing) -->
            <div class="activity-custom-range-box">
                <!-- Presets Bar -->
                <div class="custom-presets-bar">
                    <span class="custom-presets-title">
                        <i class="fas fa-bolt text-warning"></i> Quick Presets:
                    </span>
                    <div class="btn-group btn-group-xs custom-preset-btn-group">
                        <button type="button" class="btn btn-default {{#if isPresetToday}}btn-info active{{/if}}" data-action="presetRange" data-preset="today">Today</button>
                        <button type="button" class="btn btn-default {{#if isPresetYesterday}}btn-info active{{/if}}" data-action="presetRange" data-preset="yesterday">Yesterday</button>
                        <button type="button" class="btn btn-default {{#if isPresetThisWeek}}btn-info active{{/if}}" data-action="presetRange" data-preset="thisWeek">This Week</button>
                        <button type="button" class="btn btn-default {{#if isPresetLastWeek}}btn-info active{{/if}}" data-action="presetRange" data-preset="lastWeek">Last Week</button>
                        <button type="button" class="btn btn-default {{#if isPresetThisMonth}}btn-info active{{/if}}" data-action="presetRange" data-preset="thisMonth">This Month</button>
                        <button type="button" class="btn btn-default {{#if isPresetLast30d}}btn-info active{{/if}}" data-action="presetRange" data-preset="last30d">Last 30 Days</button>
                    </div>

                    <button type="button" class="btn btn-link btn-xs text-muted custom-close-btn pull-right" data-action="closeCustomRange" title="Close custom range">
                        <i class="fas fa-times"></i> Close
                    </button>
                </div>

                <!-- Inputs Row: From Date, From Time, Arrow, To Date, To Time, Apply -->
                <div class="custom-inputs-flex-row">
                    <!-- From Fieldset -->
                    <div class="custom-datetime-group">
                        <label class="custom-field-label">
                            <i class="far fa-calendar-alt text-muted"></i> From:
                        </label>
                        <div class="custom-datetime-inputs">
                            <input type="date" class="form-control custom-date-input" name="fromDate" value="{{fromDateValue}}">
                            
                            <!-- From Time Popover Trigger -->
                            <div class="custom-time-picker-wrap">
                                <button type="button" class="btn btn-default custom-time-btn {{#if fromTimeFlashed}}time-btn-success{{/if}}" data-action="toggleTimePicker" data-target="from" title="Click to change time">
                                    <i class="far fa-clock"></i>
                                    <span class="time-btn-text">{{fromTimeDisplay}}</span>
                                    <i class="fas fa-caret-down"></i>
                                </button>

                                <!-- From Time Popover Window -->
                                {{#if isFromTimePickerOpen}}
                                <div class="activity-time-popover" data-popover="from">
                                    <div class="time-popover-header">
                                        <span class="time-popover-title"><i class="far fa-clock"></i> Select Start Time</span>
                                        <button type="button" class="time-popover-close" data-action="closeTimePicker" data-target="from">&times;</button>
                                    </div>
                                    <div class="time-popover-columns">
                                        <!-- Hour -->
                                        <div class="time-col time-col-hour">
                                            <div class="time-col-header">Hour</div>
                                            <div class="time-chips-grid">
                                                {{#each fromHourOptions}}
                                                <button type="button" class="time-chip {{#if selected}}active{{/if}}" data-action="selectTimePart" data-target="from" data-part="hour" data-val="{{val}}">{{val}}</button>
                                                {{/each}}
                                            </div>
                                        </div>
                                        <!-- Minute -->
                                        <div class="time-col time-col-min">
                                            <div class="time-col-header">Min</div>
                                            <div class="time-chips-grid">
                                                {{#each fromMinuteOptions}}
                                                <button type="button" class="time-chip {{#if selected}}active{{/if}}" data-action="selectTimePart" data-target="from" data-part="minute" data-val="{{val}}">{{val}}</button>
                                                {{/each}}
                                            </div>
                                        </div>
                                        <!-- AM / PM -->
                                        <div class="time-col time-col-ampm">
                                            <div class="time-col-header">AM/PM</div>
                                            <div class="time-ampm-stack">
                                                <button type="button" class="time-chip time-ampm-chip {{#if fromIsAmSelected}}active{{/if}}" data-action="selectTimePart" data-target="from" data-part="ampm" data-val="AM">AM</button>
                                                <button type="button" class="time-chip time-ampm-chip {{#if fromIsPmSelected}}active{{/if}}" data-action="selectTimePart" data-target="from" data-part="ampm" data-val="PM">PM</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="time-popover-footer">
                                        <span class="time-selected-preview">Set: <strong>{{fromTimeDisplay}}</strong></span>
                                        <span class="time-auto-hint text-muted"><i class="fas fa-magic"></i> Auto-closes on pick</span>
                                    </div>
                                </div>
                                {{/if}}
                            </div>
                        </div>
                    </div>

                    <!-- Range Separator Arrow -->
                    <div class="custom-arrow-wrap">
                        <i class="fas fa-arrow-right text-muted"></i>
                    </div>

                    <!-- To Fieldset -->
                    <div class="custom-datetime-group">
                        <label class="custom-field-label">
                            <i class="far fa-calendar-alt text-muted"></i> To:
                        </label>
                        <div class="custom-datetime-inputs">
                            <input type="date" class="form-control custom-date-input" name="toDate" value="{{toDateValue}}">

                            <!-- To Time Popover Trigger -->
                            <div class="custom-time-picker-wrap">
                                <button type="button" class="btn btn-default custom-time-btn {{#if toTimeFlashed}}time-btn-success{{/if}}" data-action="toggleTimePicker" data-target="to" title="Click to change time">
                                    <i class="far fa-clock"></i>
                                    <span class="time-btn-text">{{toTimeDisplay}}</span>
                                    <i class="fas fa-caret-down"></i>
                                </button>

                                <!-- To Time Popover Window -->
                                {{#if isToTimePickerOpen}}
                                <div class="activity-time-popover" data-popover="to">
                                    <div class="time-popover-header">
                                        <span class="time-popover-title"><i class="far fa-clock"></i> Select End Time</span>
                                        <button type="button" class="time-popover-close" data-action="closeTimePicker" data-target="to">&times;</button>
                                    </div>
                                    <div class="time-popover-columns">
                                        <!-- Hour -->
                                        <div class="time-col time-col-hour">
                                            <div class="time-col-header">Hour</div>
                                            <div class="time-chips-grid">
                                                {{#each toHourOptions}}
                                                <button type="button" class="time-chip {{#if selected}}active{{/if}}" data-action="selectTimePart" data-target="to" data-part="hour" data-val="{{val}}">{{val}}</button>
                                                {{/each}}
                                            </div>
                                        </div>
                                        <!-- Minute -->
                                        <div class="time-col time-col-min">
                                            <div class="time-col-header">Min</div>
                                            <div class="time-chips-grid">
                                                {{#each toMinuteOptions}}
                                                <button type="button" class="time-chip {{#if selected}}active{{/if}}" data-action="selectTimePart" data-target="to" data-part="minute" data-val="{{val}}">{{val}}</button>
                                                {{/each}}
                                            </div>
                                        </div>
                                        <!-- AM / PM -->
                                        <div class="time-col time-col-ampm">
                                            <div class="time-col-header">AM/PM</div>
                                            <div class="time-ampm-stack">
                                                <button type="button" class="time-chip time-ampm-chip {{#if toIsAmSelected}}active{{/if}}" data-action="selectTimePart" data-target="to" data-part="ampm" data-val="AM">AM</button>
                                                <button type="button" class="time-chip time-ampm-chip {{#if toIsPmSelected}}active{{/if}}" data-action="selectTimePart" data-target="to" data-part="ampm" data-val="PM">PM</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="time-popover-footer">
                                        <span class="time-selected-preview">Set: <strong>{{toTimeDisplay}}</strong></span>
                                        <span class="time-auto-hint text-muted"><i class="fas fa-magic"></i> Auto-closes on pick</span>
                                    </div>
                                </div>
                                {{/if}}
                            </div>
                        </div>
                    </div>

                    <!-- Apply Button -->
                    <div class="custom-apply-group">
                        <button type="button" class="btn btn-primary custom-apply-btn" data-action="applyCustomRange">
                            <i class="fas fa-check"></i> Apply Range
                        </button>
                    </div>

                    <!-- Feedback Pill -->
                    {{#if customRangeHumanSummary}}
                    <div class="custom-summary-pill text-muted">
                        <i class="fas fa-calendar-check text-primary"></i> {{customRangeHumanSummary}}
                    </div>
                    {{/if}}
                </div>
            </div>
            {{/if}}

            <!-- Row 2: Select Filters + Actions -->
            <div class="row" style="margin-top: 8px;">
                <div class="col-xs-12">
                    <div class="activity-filter-inline-wrap">
                        <div class="form-group form-group-sm">
                            <label class="control-label small text-muted">User:</label>
                            <select class="form-control input-sm" name="userId">
                                <option value="">{{translate 'AllUsers' scope='ActivityMonitor'}}</option>
                                {{#each filterData.users}}
                                    <option value="{{id}}" {{#if selected}}selected{{/if}}>{{name}}</option>
                                {{/each}}
                            </select>
                        </div>

                        <div class="form-group form-group-sm">
                            <label class="control-label small text-muted">Entity:</label>
                            <select class="form-control input-sm" name="entityType">
                                <option value="">{{translate 'AllEntities' scope='ActivityMonitor'}}</option>
                                {{#each filterData.entities}}
                                    <option value="{{name}}" {{#if selected}}selected{{/if}}>{{label}}</option>
                                {{/each}}
                            </select>
                        </div>

                        <div class="form-group form-group-sm">
                            <label class="control-label small text-muted">Action:</label>
                            <select class="form-control input-sm" name="activityType">
                                <option value="">{{translate 'AllActivityTypes' scope='ActivityMonitor'}}</option>
                                {{#each filterData.activityTypes}}
                                    <option value="{{name}}" {{#if selected}}selected{{/if}}>{{label}}</option>
                                {{/each}}
                            </select>
                        </div>

                        <div class="activity-filter-btn-group pull-right">
                            <button type="button" class="btn btn-default btn-sm" data-action="resetFilters" title="{{translate 'ResetFilters' scope='ActivityMonitor'}}">
                                <span class="fas fa-undo"></span> {{translate 'ResetFilters' scope='ActivityMonitor'}}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Workspace (2-Column EspoCRM Layout) -->
    <div class="row">
        <!-- Main Activity Stream Table (Left 9 cols) -->
        <div class="col-md-9 col-sm-8">
            <div class="panel panel-default activity-main-panel">
                <div class="panel-heading clearfix">
                    <div class="pull-left">
                        <h4 class="panel-title">
                            <span class="fas fa-stream text-muted"></span>
                            <span>Activity Timeline</span>
                            <span class="activity-header-count text-muted">({{totalActivities}})</span>
                        </h4>
                    </div>
                    <div class="pull-right">
                        <div class="activity-header-pagination">
                            <span class="text-muted small" style="margin-right: 6px;">{{page}} / {{totalPages}}</span>
                            <div class="btn-group btn-group-xs">
                                <button type="button" class="btn btn-default" data-action="prevPage" {{#unless hasPrev}}disabled{{/unless}} title="Previous Page">
                                    <span class="fas fa-chevron-left"></span>
                                </button>
                                <button type="button" class="btn btn-default" data-action="nextPage" {{#unless hasNext}}disabled{{/unless}} title="Next Page">
                                    <span class="fas fa-chevron-right"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="panel-body no-padding" style="padding: 0;">
                    {{#if isLoading}}
                        <div class="text-center text-muted" style="padding: 40px;">
                            <span class="fas fa-spinner fa-spin fa-2x"></span>
                            <div style="margin-top: 10px;">Loading activities...</div>
                        </div>
                    {{else}}
                        {{#if hasActivities}}
                            <div class="table-responsive" style="margin: 0;">
                                <table class="table table-hover table-striped" style="margin-bottom: 0;">
                                    <thead>
                                        <tr>
                                            <th style="width: 16%;">{{translate 'Timestamp' scope='ActivityMonitor'}}</th>
                                            <th style="width: 17%;">{{translate 'User' scope='ActivityMonitor'}}</th>
                                            <th style="width: 13%;">{{translate 'Action' scope='ActivityMonitor'}}</th>
                                            <th style="width: 22%;">{{translate 'Record' scope='ActivityMonitor'}}</th>
                                            <th style="width: 32%;">{{translate 'Details' scope='ActivityMonitor'}}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {{#each activities}}
                                        <tr>
                                            <!-- Timestamp -->
                                            <td>
                                                <div style="font-weight: 600;">{{timeFormatted}}</div>
                                                <div class="text-muted small" title="{{timestampFormatted}}">
                                                    {{dateFormatted}} &bull; {{relativeTime}}
                                                </div>
                                            </td>

                                            <!-- User -->
                                            <td>
                                                <div class="activity-user-flex">
                                                    {{#if isSystemUser}}
                                                        <div class="activity-avatar-circle" style="background-color: #6c757d;" title="Automated System Task">
                                                            <span class="fas fa-robot"></span>
                                                        </div>
                                                        <div class="activity-user-name">
                                                            <span class="text-muted" title="Automated System Task">System</span>
                                                        </div>
                                                    {{else}}
                                                        <div class="activity-avatar-circle" style="background-color: {{userAvatarColor}};">
                                                            {{userInitials}}
                                                        </div>
                                                        <div class="activity-user-name">
                                                            <a href="#User/view/{{userId}}">{{userName}}</a>
                                                        </div>
                                                    {{/if}}
                                                </div>
                                            </td>

                                            <!-- Action Badge -->
                                            <td>
                                                {{#if isCreated}}
                                                    <span class="label label-success"><span class="fas fa-plus"></span> Created</span>
                                                {{/if}}
                                                {{#if isStatusChanged}}
                                                    <span class="label label-warning"><span class="fas fa-exchange-alt"></span> Status</span>
                                                {{/if}}
                                                {{#if isConverted}}
                                                    <span class="label label-primary"><span class="fas fa-check"></span> Converted</span>
                                                {{/if}}
                                                {{#if isDeleted}}
                                                    <span class="label label-danger"><span class="fas fa-trash"></span> Deleted</span>
                                                {{/if}}
                                                {{#if isAssigned}}
                                                    <span class="label label-info"><span class="fas fa-user-check"></span> Assigned</span>
                                                {{/if}}
                                                {{#if isPost}}
                                                    <span class="label label-default"><span class="fas fa-comment"></span> Post</span>
                                                {{/if}}
                                                {{#if isUpdated}}
                                                    <span class="label label-info"><span class="fas fa-edit"></span> Updated</span>
                                                {{/if}}
                                            </td>

                                            <!-- Record Name / Link -->
                                            <td>
                                                <div class="activity-record-title-wrap">
                                                    <span class="text-muted small" style="margin-right: 4px;" title="{{entityLabel}}">
                                                        <span class="{{entityIconClass}}"></span>
                                                    </span>
                                                    {{#if isDeleted}}
                                                        <span class="activity-deleted-record text-muted" title="Record ID: {{recordId}} (Deleted from CRM)">
                                                            <span style="text-decoration: line-through;">{{recordName}}</span>
                                                            <span class="label label-default text-danger small" style="margin-left: 4px; font-weight: normal; font-size: 10px;">
                                                                <span class="fas fa-trash-alt"></span> Deleted
                                                            </span>
                                                        </span>
                                                    {{else}}
                                                        <a href="{{recordUrl}}" class="record-title-link"><strong>{{recordName}}</strong></a>
                                                    {{/if}}
                                                </div>
                                                <div class="text-muted small">
                                                    <span>{{entityLabel}}</span>
                                                    {{#if isDeleted}}
                                                        &nbsp;&bull;&nbsp;<span class="text-muted" style="font-family: monospace; font-size: 10px;" title="Internal ID: {{recordId}}">#{{shortRecordId}}</span>
                                                    {{/if}}
                                                    {{#if relatedEntityLabel}}
                                                        &nbsp;&bull;&nbsp;
                                                        <span>{{relatedEntityLabel}}: 
                                                            {{#if isRelatedDeleted}}
                                                                <span class="text-muted" style="text-decoration: line-through;">{{relatedRecordName}}</span>
                                                                <span class="label label-default text-danger small" style="font-size: 9px;"><span class="fas fa-trash-alt"></span></span>
                                                            {{else}}
                                                                <a href="#{{relatedEntityType}}/view/{{relatedRecordId}}" class="text-muted">{{relatedRecordName}}</a>
                                                            {{/if}}
                                                        </span>
                                                    {{/if}}
                                                </div>
                                            </td>

                                            <!-- Details / Field Changes -->
                                            <td>
                                                {{#if hasFieldChanges}}
                                                    <div class="activity-changes-box">
                                                        {{#each fieldChanges}}
                                                            <div class="activity-change-row">
                                                                <span class="change-field-label text-muted">{{fieldLabel}}:</span>
                                                                <span class="change-was text-muted">{{was}}</span>
                                                                <span class="fas fa-arrow-right text-muted small" style="margin: 0 4px;"></span>
                                                                <strong class="change-became text-success">{{became}}</strong>
                                                            </div>
                                                        {{/each}}
                                                    </div>
                                                {{else if postContent}}
                                                    <div class="activity-post-snippet text-muted">
                                                        <span class="fas fa-quote-left small text-muted"></span> {{postContent}}
                                                    </div>
                                                {{else if isConverted}}
                                                    <span class="text-success small"><span class="fas fa-check-circle"></span> Lead successfully converted</span>
                                                {{else if isDeleted}}
                                                    <span class="text-danger small"><span class="fas fa-times-circle"></span> Record removed from CRM</span>
                                                {{else if isCreated}}
                                                    <span class="text-muted small"><span class="fas fa-info-circle"></span> Initial record created</span>
                                                {{else}}
                                                    <span class="text-muted">-</span>
                                                {{/if}}
                                            </td>
                                        </tr>
                                        {{/each}}
                                    </tbody>
                                </table>
                            </div>
                        {{else}}
                            <div class="text-center text-muted" style="padding: 40px 20px;">
                                <span class="fas fa-inbox fa-3x" style="opacity: 0.4;"></span>
                                <h4 style="margin-top: 15px;">No activities found</h4>
                                <p class="small">No activities matched the selected filters and timeframe.</p>
                                <button type="button" class="btn btn-default btn-sm" data-action="resetFilters">
                                    <span class="fas fa-undo"></span> Reset Filters
                                </button>
                            </div>
                        {{/if}}
                    {{/if}}
                </div>

                <!-- Panel Footer Pagination -->
                {{#if hasActivities}}
                <div class="panel-footer clearfix">
                    <div class="pull-left text-muted small" style="line-height: 28px;">
                        Showing <strong>{{paginationStart}}</strong>&ndash;<strong>{{paginationEnd}}</strong> of <strong>{{totalActivities}}</strong> activities
                    </div>
                    <div class="pull-right">
                        <div class="btn-group btn-group-sm">
                            <button type="button" class="btn btn-default" data-action="prevPage" {{#unless hasPrev}}disabled{{/unless}}>
                                <span class="fas fa-chevron-left"></span> Previous
                            </button>
                            <span class="btn btn-default disabled" style="cursor: default;">Page {{page}} of {{totalPages}}</span>
                            <button type="button" class="btn btn-default" data-action="nextPage" {{#unless hasNext}}disabled{{/unless}}>
                                Next <span class="fas fa-chevron-right"></span>
                            </button>
                        </div>
                    </div>
                </div>
                {{/if}}
            </div>
        </div>

        <!-- Sidebar: User Leaderboard & Entity Distribution (Right 3 cols) -->
        <div class="col-md-3 col-sm-4">
            <!-- Top Users Panel -->
            <div class="panel panel-default activity-sidebar-panel">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <span class="fas fa-user-friends text-muted"></span>
                        <span>{{translate 'UserLeaderboard' scope='ActivityMonitor'}}</span>
                        <span class="activity-header-count text-muted">({{userStatsCount}})</span>
                    </h4>
                </div>
                <div class="panel-body activity-sidebar-body">
                    {{#if hasUserStats}}
                        <div class="activity-sidebar-list">
                            {{#each summary.userStats}}
                            <div class="activity-sidebar-item" data-action="filterUser" data-id="{{userId}}" title="Click to filter by {{userName}}">
                                <div class="activity-sidebar-item-header">
                                    <span class="activity-sidebar-name">
                                        <span class="fas fa-user-circle text-muted" style="margin-right: 4px; opacity: 0.7;"></span>
                                        {{userName}}
                                    </span>
                                    <span class="activity-sidebar-count">
                                        <strong>{{count}}</strong>
                                        <span class="text-muted small">({{percentage}}%)</span>
                                    </span>
                                </div>
                                <div class="progress activity-mini-progress">
                                    <div class="progress-bar progress-bar-primary" style="width: {{percentage}}%;"></div>
                                </div>
                            </div>
                            {{/each}}
                        </div>
                    {{else}}
                        <div class="text-muted small text-center" style="padding: 15px 0;">No user activity recorded.</div>
                    {{/if}}
                </div>
            </div>

            <!-- Entity Breakdown Panel -->
            <div class="panel panel-default activity-sidebar-panel">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <span class="fas fa-cubes text-muted"></span>
                        <span>{{translate 'EntityBreakdown' scope='ActivityMonitor'}}</span>
                        <span class="activity-header-count text-muted">({{entityStatsCount}})</span>
                    </h4>
                </div>
                <div class="panel-body activity-sidebar-body">
                    {{#if hasEntityStats}}
                        <div class="activity-sidebar-list">
                            {{#each summary.entityStats}}
                            <div class="activity-sidebar-item" data-action="filterEntity" data-entity="{{entityType}}" title="Click to filter by {{entityLabel}}">
                                <div class="activity-sidebar-item-header">
                                    <span class="activity-sidebar-name">
                                        <span class="text-muted small" style="margin-right: 4px; opacity: 0.8;"><span class="{{entityIconClass}}"></span></span>
                                        {{entityLabel}}
                                    </span>
                                    <span class="activity-sidebar-count">
                                        <strong>{{count}}</strong>
                                        <span class="text-muted small">({{percentage}}%)</span>
                                    </span>
                                </div>
                                <div class="progress activity-mini-progress">
                                    <div class="progress-bar progress-bar-info" style="width: {{percentage}}%;"></div>
                                </div>
                            </div>
                            {{/each}}
                        </div>
                    {{else}}
                        <div class="text-muted small text-center" style="padding: 15px 0;">No entity activity recorded.</div>
                    {{/if}}
                </div>
            </div>
        </div>
    </div>
</div>
