define('custom:views/account/record/edit-small', ['custom:views/account/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({});

});
