define('custom:views/call/record/edit', ['views/record/edit'], function (Dep) {

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            if (this.model.isNew()) {
                var initialParentName = this.model.get('parentName');
                if (initialParentName && this.model.get('name') === initialParentName) {
                    this.model.set('name', '');
                }
            }

            this.listenTo(this.model, 'change:parentId', function (m, id, o) {
                this.updateNamePlaceholder();

                if (!o || !o.ui) return;
                var parentType = this.model.get('parentType');
                if (parentType === 'Lead' && id) {
                    this.fetchLeadData(id);
                } else if (parentType === 'Account' && id) {
                    this.fetchAccountData(id);
                }
            });

            this.listenTo(this.model, 'change:parentType', function (m, type, o) {
                this.updateNamePlaceholder();

                if (!o || !o.ui) return;
                var parentId = this.model.get('parentId');
                if (type === 'Lead' && parentId) {
                    this.fetchLeadData(parentId);
                } else if (type === 'Account' && parentId) {
                    this.fetchAccountData(parentId);
                }
            });

            this.listenTo(this.model, 'change:parentName change:cProductServicesNames change:cProductServicesIds change:status', function () {
                this.updateNamePlaceholder();
                this.updateDescriptionPlaceholder();
            });

            var initialParentType = this.model.get('parentType');
            var initialParentId = this.model.get('parentId');

            if (initialParentType === 'Lead' && initialParentId) {
                this.fetchLeadData(initialParentId, {initial: true});
            } else if (initialParentType === 'Account' && initialParentId) {
                this.fetchAccountData(initialParentId, {initial: true});
            }
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            this.updateNamePlaceholder();
            this.updateDescriptionPlaceholder();

            var nameView = this.getFieldView('name');
            if (nameView) {
                this.listenTo(nameView, 'after:render', this.updateNamePlaceholder.bind(this));
            }

            var descView = this.getFieldView('description');
            if (descView) {
                this.listenTo(descView, 'after:render', this.updateDescriptionPlaceholder.bind(this));
            }
        },

        getDescriptionPlaceholder: function () {
            var status = this.model.get('status') || 'Planned';

            if (status === 'Held') {
                return 'e.g. Call summary, customer responses, pain points identified, agreed action items, and next steps...';
            }

            if (status === 'Not Held') {
                return 'e.g. Reason call did not occur, voicemail message left, gatekeeper notes, or reschedule follow-up...';
            }

            if (status === 'Not Received') {
                return 'e.g. Missed call details, caller voicemail summary, urgency level, and callback plan...';
            }

            return 'e.g. Call purpose, agenda topics, key questions to ask, qualification criteria, and expected outcome...';
        },

        updateDescriptionPlaceholder: function () {
            var placeholder = this.getDescriptionPlaceholder();

            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="description"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('textarea, input');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $textElem = this.$el.find('textarea[data-name="description"]');
                if ($textElem && $textElem.length) {
                    if (typeof $textElem.attr === 'function') {
                        $textElem.attr('placeholder', placeholder);
                    } else if ($textElem[0] && typeof $textElem[0].setAttribute === 'function') {
                        $textElem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="description"], .field[data-name="description"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('textarea, input');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            var descView = this.getFieldView('description');
            if (descView) {
                descView.placeholder = placeholder;
                if (descView.params) {
                    descView.params.placeholder = placeholder;
                }
                if (descView.$element) {
                    if (typeof descView.$element.attr === 'function') {
                        descView.$element.attr('placeholder', placeholder);
                    } else if (descView.$element[0] && typeof descView.$element[0].setAttribute === 'function') {
                        descView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (descView.$el && typeof descView.$el.find === 'function') {
                    var $descInputs = descView.$el.find('textarea');
                    if ($descInputs && $descInputs.length) {
                        if (typeof $descInputs.attr === 'function') {
                            $descInputs.attr('placeholder', placeholder);
                        } else if ($descInputs[0] && typeof $descInputs[0].setAttribute === 'function') {
                            $descInputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        },

        getNamePlaceholder: function () {
            var targetName = (this.model.get('parentName') || this.fetchedParentName || '').trim();

            var prodName = '';
            var namesMap = this.model.get('cProductServicesNames');
            if (namesMap && typeof namesMap === 'object') {
                var vals = Object.values(namesMap).map(function (v) {
                    return v ? String(v).trim() : '';
                }).filter(Boolean);
                if (vals.length === 1) {
                    prodName = vals[0];
                } else if (vals.length > 1) {
                    prodName = vals.join(', ');
                }
            }
            if (!prodName && this.fetchedProductName) {
                prodName = String(this.fetchedProductName).trim();
            }

            var status = this.model.get('status') || 'Planned';

            if (status === 'Held') {
                if (targetName) {
                    if (prodName) {
                        return 'e.g. Call with ' + targetName + ' regarding ' + prodName + ' (summary / outcome)...';
                    }
                    return 'e.g. Call with ' + targetName + ' regarding discussion / outcome...';
                }
                return 'e.g. Call summary / discussion outcome...';
            }

            if (status === 'Not Held') {
                if (targetName) {
                    if (prodName) {
                        return 'e.g. Unanswered call / left voicemail for ' + targetName + ' regarding ' + prodName + '...';
                    }
                    return 'e.g. Unanswered call / left voicemail for ' + targetName + '...';
                }
                return 'e.g. Unanswered call / left voicemail...';
            }

            if (status === 'Not Received') {
                if (targetName) {
                    if (prodName) {
                        return 'e.g. Missed / unreceived call from ' + targetName + ' regarding ' + prodName + '...';
                    }
                    return 'e.g. Missed / unreceived call from ' + targetName + '...';
                }
                return 'e.g. Missed / unreceived call...';
            }

            // Planned (default)
            if (targetName) {
                if (prodName) {
                    return 'e.g. Call ' + targetName + ' regarding ' + prodName + '...';
                }
                return 'e.g. Call ' + targetName + ' regarding discussion topic / follow-up...';
            }

            return 'e.g. Call regarding discussion topic / follow-up...';
        },

        updateNamePlaceholder: function () {
            if (!this.model.isNew()) {
                return;
            }

            var parentName = (this.model.get('parentName') || this.fetchedParentName || '').trim();
            if (parentName && this.model.get('name') === parentName) {
                this.model.set('name', '');
            }

            var placeholder = this.getNamePlaceholder();

            var $input = this.$el && typeof this.$el.find === 'function' ? this.$el.find('input[data-name="name"]') : null;
            if ($input && $input.length) {
                if (typeof $input.attr === 'function') {
                    $input.attr('placeholder', placeholder);
                } else if ($input[0] && typeof $input[0].setAttribute === 'function') {
                    $input[0].setAttribute('placeholder', placeholder);
                }
            }

            var nameView = this.getFieldView('name');
            if (nameView) {
                if (nameView.$element) {
                    if (typeof nameView.$element.attr === 'function') {
                        nameView.$element.attr('placeholder', placeholder);
                    } else if (nameView.$element[0] && typeof nameView.$element[0].setAttribute === 'function') {
                        nameView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                var $nameInput = nameView.$el && typeof nameView.$el.find === 'function' ? nameView.$el.find('input') : null;
                if ($nameInput && $nameInput.length) {
                    if (typeof $nameInput.attr === 'function') {
                        $nameInput.attr('placeholder', placeholder);
                    } else if ($nameInput[0] && typeof $nameInput[0].setAttribute === 'function') {
                        $nameInput[0].setAttribute('placeholder', placeholder);
                    }
                }
            }
        },

        fetchLeadData: function (leadId, options) {
            options = options || {};

            this.clearView('productServicePicker');

            Espo.Ajax.getRequest('Lead/' + leadId, {
                select: 'id,name,cProductServicesIds,cProductServicesNames'
            }).then(function (response) {
                if (
                    this.model.get('parentType') !== 'Lead' ||
                    this.model.get('parentId') !== leadId
                ) {
                    return;
                }

                if (response.name) {
                    this.fetchedParentName = response.name;
                }

                if (this.model.isNew() && response.name && this.model.get('name') === response.name) {
                    this.model.set('name', '');
                }

                var idList = response.cProductServicesIds || [];
                var nameMap = response.cProductServicesNames || {};

                if (idList.length && idList[0] && nameMap[idList[0]]) {
                    this.fetchedProductName = nameMap[idList[0]];
                }

                this.updateNamePlaceholder();

                if (!idList.length) {
                    return;
                }

                if (options.initial && (this.model.get('cProductServicesIds') || []).length) {
                    return;
                }

                this.applyParentProductServices(
                    idList,
                    nameMap,
                    response.name || ''
                );
            }.bind(this));
        },

        fetchAccountData: function (accountId, options) {
            options = options || {};

            this.clearView('productServicePicker');

            Espo.Ajax.getRequest('Account/' + accountId, {
                select: 'id,name,cProductServicesIds,cProductServicesNames'
            }).then(function (response) {
                if (
                    this.model.get('parentType') !== 'Account' ||
                    this.model.get('parentId') !== accountId
                ) {
                    return;
                }

                if (response.name) {
                    this.fetchedParentName = response.name;
                }

                if (this.model.isNew() && response.name && this.model.get('name') === response.name) {
                    this.model.set('name', '');
                }

                var idList = response.cProductServicesIds || [];
                var nameMap = response.cProductServicesNames || {};

                if (idList.length && idList[0] && nameMap[idList[0]]) {
                    this.fetchedProductName = nameMap[idList[0]];
                }

                this.updateNamePlaceholder();

                if (!idList.length) {
                    return;
                }

                if (options.initial && (this.model.get('cProductServicesIds') || []).length) {
                    return;
                }

                this.applyParentProductServices(
                    idList,
                    nameMap,
                    response.name || ''
                );
            }.bind(this));
        },

        applyParentProductServices: function (idList, nameMap, parentName) {
            if (idList.length === 1) {
                this.setProductServices(idList, nameMap);

                return;
            }

            this.openProductServicePicker(idList, nameMap, parentName);
        },

        setProductServices: function (idList, nameMap) {
            var names = {};

            idList.forEach(function (id) {
                if (nameMap[id]) {
                    names[id] = nameMap[id];
                }
            });

            this.model.set({
                cProductServicesIds: idList.slice(0),
                cProductServicesNames: names
            });

            this.updateNamePlaceholder();
        },

        openProductServicePicker: function (idList, nameMap, parentName) {
            var optionList = idList.map(function (id) {
                return {
                    id: id,
                    name: nameMap[id] || id
                };
            });

            this.createView('productServicePicker', 'custom:views/modals/select-product-service', {
                optionList: optionList,
                leadName: parentName,
                backdrop: true
            }).then(function (view) {
                this.listenToOnce(view, 'select', function (selectedIdList) {
                    this.setProductServices(selectedIdList, nameMap);

                    view.close();
                }.bind(this));

                view.render();
            }.bind(this));
        },

    });

});
