<?php
namespace Espo\Custom\Services;

use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Record\Service;
use Espo\ORM\Entity;
use stdClass;

class Opportunity extends Service
{
    public function loadAdditionalFields(Entity $entity): void
    {
        parent::loadAdditionalFields($entity);

        $productId = $entity->get('cProductServiceId') ?: $entity->get('cWonProductId');
        if ($productId) {
            $product = $this->entityManager->getEntityById('CProductService', $productId);
            if ($product) {
                $entity->set('cProductServiceType', $product->get('type'));
                $entity->set('cProductServiceRootDomain', $product->get('cRootDomain'));
            }
        }
    }

    public function prepareEntityForOutput(Entity $entity): void
    {
        $productId = $entity->get('cProductServiceId') ?: $entity->get('cWonProductId');
        if ($productId) {
            $product = $this->entityManager->getEntityById('CProductService', $productId);
            if ($product) {
                $entity->set('cProductServiceType', $product->get('type'));
                $entity->set('cProductServiceRootDomain', $product->get('cRootDomain'));
            }
        }

        parent::prepareEntityForOutput($entity);
    }

    public function processValidation(Entity $entity, stdClass $data): void
    {
        $contactId = $data->contactId ?? $entity->get('contactId');
        if ($contactId && empty($entity->getLinkMultipleIdList('contacts'))) {
            $entity->set('contactsIds', [$contactId]);
            $data->contactsIds = [$contactId];
        }

        $contactsIds = $entity->getLinkMultipleIdList('contacts');
        if (!empty($contactsIds) && !$entity->get('contactId')) {
            $entity->set('contactId', $contactsIds[0]);
            $data->contactId = $contactsIds[0];
        }

        // When Opportunity is Closed Won:
        // 1. Account is required (auto-resolves from name if missing)
        // 2. Contact or Account is required for fulfillment
        if ($entity->get('stage') === 'Closed Won') {
            $hasSalesProductivity = !empty($this->metadata->get(['app', 'salesProductivity', 'installed']));
            $hasSubscriptions = !empty($this->metadata->get(['scopes', 'CClientSubscription']));
            if ($hasSalesProductivity || $hasSubscriptions) {
                if (!$entity->get('accountId')) {
                    $accName = $entity->get('accountName');
                    if (!$accName && $entity->get('name')) {
                        $parts = explode('-', $entity->get('name'));
                        $cand = trim($parts[0]);
                        if ($cand !== '' && $cand !== 'Opportunity') {
                            $accName = $cand;
                        }
                    }
                    if ($accName) {
                        $existingAcc = $this->entityManager->getRepository('Account')->where(['name' => $accName])->findOne();
                        if ($existingAcc) {
                            $entity->set('accountId', $existingAcc->getId());
                            $entity->set('accountName', $existingAcc->get('name'));
                            $data->accountId = $existingAcc->getId();
                            $data->accountName = $existingAcc->get('name');
                        } else {
                            $newAcc = $this->entityManager->getEntity('Account');
                            $newAcc->set('name', $accName);
                            $this->entityManager->saveEntity($newAcc);
                            $entity->set('accountId', $newAcc->getId());
                            $entity->set('accountName', $newAcc->get('name'));
                            $data->accountId = $newAcc->getId();
                            $data->accountName = $newAcc->get('name');
                        }
                    }
                }
                if (!$entity->get('accountId')) {
                    throw new BadRequest("Account is required when Opportunity is Closed Won.");
                }
            }
            if (!$entity->get('accountId')) {
                throw new BadRequest("Account is required when Opportunity is Closed Won.");
            }
            if (!$entity->get('contactId') && empty($contactsIds)) {
                throw new BadRequest("Contact is required when Opportunity is Closed Won.");
            }
            if ($hasSubscriptions) {
                $subdomain = trim((string)$entity->get('cSubdomain'));
                $prodId = $entity->get('cProductServiceId') ?: $entity->get('cWonProductId');
                $prod = $prodId ? $this->entityManager->getEntityById('CProductService', $prodId) : null;
                $rDomain = $prod ? trim((string)$prod->get('cRootDomain')) : '';
                $clean = '';
                if ($rDomain !== '') {
                    $clean = preg_replace('#^https?://#i', '', $rDomain);
                    $clean = explode('/', $clean)[0];
                    $clean = trim($clean, '.');
                }
                $pName = $prod ? strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '', $prod->get('name')))) : 'coachsys';
                $domainPart = '.' . ($clean !== '' ? $clean : (($pName ?: 'coachsys') . '.com'));

                if ($subdomain === '' || str_starts_with($subdomain, '.')) {
                    $accountName = $entity->get('accountName');
                    if (!$accountName && $entity->get('accountId')) {
                        $acc = $this->entityManager->getEntityById('Account', $entity->get('accountId'));
                        if ($acc) {
                            $accountName = $acc->get('name');
                        }
                    }
                    if (!$accountName && $entity->get('leadName')) {
                        $accountName = $entity->get('leadName');
                    }
                    if (!$accountName && $entity->get('name')) {
                        $oppName = trim((string)$entity->get('name'));
                        if (str_contains($oppName, '-')) {
                            $parts = explode('-', $oppName);
                            $cand = trim($parts[0]);
                            if ($cand !== '' && $cand !== 'Opportunity') {
                                $accountName = $cand;
                            }
                        }
                    }
                    $accSlug = $accountName ? strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $accountName), '-')) : 'client';
                    if ($accSlug === '') {
                        $accSlug = 'client';
                    }
                    $subdomain = $accSlug . $domainPart;
                    $entity->set('cSubdomain', $subdomain);
                    $data->cSubdomain = $subdomain;
                } else if (!str_contains($subdomain, '.')) {
                    $subdomain = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $subdomain), '-')) . $domainPart;
                    $entity->set('cSubdomain', $subdomain);
                    $data->cSubdomain = $subdomain;
                }

                if ($subdomain === '' || str_starts_with($subdomain, '.')) {
                    throw new BadRequest("Please enter the subdomain.");
                }
                $parts = explode('.', $subdomain);
                if (trim($parts[0]) === '') {
                    throw new BadRequest("Please enter the subdomain.");
                }

                $planId = $data->cWonPlanId ?? $entity->get('cWonPlanId');
                if (!$planId && $prodId) {
                    $plans = $this->entityManager->getRepository('CSubscriptionPlan')->where([
                        'productId' => $prodId,
                        'status' => 'Active'
                    ])->find();
                    if (count($plans) === 1) {
                        $singlePlan = $plans[0];
                        $planId = $singlePlan->getId();
                        $entity->set('cWonPlanId', $planId);
                        $entity->set('cWonPlanName', $singlePlan->get('name'));
                        $data->cWonPlanId = $planId;
                        $data->cWonPlanName = $singlePlan->get('name');
                        if ($singlePlan->get('monthlyPrice') !== null) {
                            $entity->set('cWonPlanPrice', $singlePlan->get('monthlyPrice'));
                            $entity->set('cWonPlanPriceCurrency', $singlePlan->get('monthlyPriceCurrency'));
                            $data->cWonPlanPrice = $singlePlan->get('monthlyPrice');
                            $data->cWonPlanPriceCurrency = $singlePlan->get('monthlyPriceCurrency');
                        }
                        if ($singlePlan->get('billingPeriod')) {
                            $entity->set('cWonPeriod', $singlePlan->get('billingPeriod'));
                            $data->cWonPeriod = $singlePlan->get('billingPeriod');
                        }
                    }
                }
            }
        }

        // Calculate and snapshot discount total
        // Discounts only apply when Opportunity is Closed Won and product type is not Custom Development
        $prodType = null;
        if ($entity->get('cProductServiceId')) {
            $prod = $this->entityManager->getEntityById('CProductService', $entity->get('cProductServiceId'));
            if ($prod) {
                $prodType = $prod->get('type');
            }
        }

        if ($entity->get('stage') !== 'Closed Won' || $prodType === 'Custom Development') {
            $entity->set('cWonHasDiscount', false);
            $entity->set('cWonDiscountTotal', 0.0);
        }

        if ($entity->get('cWonHasDiscount') && $entity->get('stage') === 'Closed Won' && $prodType !== 'Custom Development') {
            $originalAmount = $entity->get('cWonOriginalAmount');
            if (($originalAmount === null || (float)$originalAmount <= 0) && isset($prod) && $prod && $prod->get('price') !== null && (float)$prod->get('price') > 0) {
                $originalAmount = (float)$prod->get('price');
                $entity->set('cWonOriginalAmount', $originalAmount);
            }
            if ($originalAmount === null || (float)$originalAmount <= 0) {
                $originalAmount = (float)($entity->get('amount') ?? 0);
                $entity->set('cWonOriginalAmount', $originalAmount);
            }

            $price = (float)$originalAmount;
            $discount = 0.0;
            $type = $entity->get('cWonDiscountType') ?: 'Percentage';
            if ($type === 'Percentage') {
                $pct = (float)($entity->get('cWonDiscountPercent') ?? 0);
                if ($pct < 0 || $pct > 100) {
                    throw new BadRequest("Percentage discount must be between 0% and 100%.");
                }
                $discount = round($price * ($pct / 100), 2);
            } else if ($type === 'Amount') {
                $amt = (float)($entity->get('cWonDiscountAmount') ?? 0);
                if ($amt < 0) {
                    throw new BadRequest("Discount amount cannot be negative.");
                }
                if ($amt > $price) {
                    throw new BadRequest("Fixed discount cannot exceed the original amount.");
                }
                $discount = round($amt, 2);
            }
            $entity->set('cWonDiscountTotal', $discount);
            if ($price > 0) {
                $entity->set('amount', max(0.0, round($price - $discount, 2)));
            }
        }

        parent::processValidation($entity, $data);
    }

    protected function beforeUpdateEntity(Entity $entity, stdClass $data): void
    {
        // Lock actual price once Closed Won: prevent changing amount if deal was already Closed Won
        if ($entity->getFetched('stage') === 'Closed Won') {
            if ($entity->isAttributeChanged('amount')) {
                $entity->set('amount', $entity->getFetched('amount'));
                if ($entity->has('amountCurrency')) {
                    $entity->set('amountCurrency', $entity->getFetched('amountCurrency'));
                }
            }
        }

        parent::beforeUpdateEntity($entity, $data);
    }
}
