<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["ActivityMonitor","CProductService","CSubscriptionPlan","CClientSubscription"];
            $insertRelativeTab = function (array $list, string $tab, array $anchors, bool $before = false): array {
                $existingIdx = null;
                foreach ($list as $k => $item) {
                    if (is_string($item) && $item === $tab) {
                        $existingIdx = $k;
                        break;
                    }
                }
                if ($existingIdx !== null) {
                    array_splice($list, $existingIdx, 1);
                }
                foreach ($anchors as $anchor) {
                    foreach ($list as $k => $item) {
                        if (is_string($item) && $item === $anchor) {
                            array_splice($list, $before ? $k : ($k + 1), 0, [$tab]);
                            return array_values($list);
                        }
                    }
                }
                foreach ($list as $k => $item) {
                    if (is_string($item) && $item === '_delimiter_') {
                        array_splice($list, $k, 0, [$tab]);
                        return array_values($list);
                    }
                }
                $list[] = $tab;
                return array_values($list);
            };
            $anchorMap = [
                'CProductService' => ['Call'],
                'CSubscriptionPlan' => ['CProductService', 'Call'],
                'CClientSubscription' => ['CSubscriptionPlan', 'CProductService', 'Call'],
            ];
            $beforeAnchorMap = [
                'ActivityMonitor' => ['Email'],
            ];

            $tabList = $config->get('tabList') ?? [];
            foreach ($tabs as $tab) {
                if (isset($beforeAnchorMap[$tab])) {
                    $tabList = $insertRelativeTab($tabList, $tab, $beforeAnchorMap[$tab], true);
                } elseif (isset($anchorMap[$tab])) {
                    $tabList = $insertRelativeTab($tabList, $tab, $anchorMap[$tab], false);
                } else {
                    $exists = false;
                    foreach ($tabList as $item) {
                        if (is_string($item) && $item === $tab) {
                            $exists = true;
                            break;
                        }
                    }
                    if (!$exists) {
                        $tabList[] = $tab;
                    }
                }
            }
            $configWriter->set('tabList', array_values($tabList));
            $configWriter->save();

            // Also place CProductService in quickCreateList right after Call if Call exists
            if (in_array('CProductService', $tabs)) {
                $qcList = $config->get('quickCreateList') ?? [];
                if (!in_array('CProductService', $qcList)) {
                    $callQcIdx = array_search('Call', $qcList);
                    if ($callQcIdx !== false) {
                        array_splice($qcList, $callQcIdx + 1, 0, ['CProductService']);
                    } else {
                        $qcList[] = 'CProductService';
                    }
                    $configWriter->set('quickCreateList', array_values($qcList));
                    $configWriter->save();
                }
            }

            // Update preferences for any user who customized tabList
            try {
                $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
                if ($em && $em->hasRepository('Preferences')) {
                    $prefsList = $em->getRDBRepository('Preferences')->where(['tabList!=' => null])->find();
                    foreach ($prefsList as $pref) {
                        $pTabList = $pref->get('tabList');
                        if (is_array($pTabList)) {
                            $pChanged = false;
                            foreach ($tabs as $tab) {
                                if (isset($anchorMap[$tab])) {
                                    $pTabList = $insertAfterTab($pTabList, $tab, $anchorMap[$tab]);
                                    $pChanged = true;
                                }
                            }
                            if ($pChanged) {
                                $pref->set('tabList', array_values($pTabList));
                                $em->saveEntity($pref);
                            }
                        }
                    }
                }
            } catch (\Throwable $e) {}


            // Safely merge activity-monitor.css into app/client.json without clobbering other extensions' CSS
            $clientJsonFile = 'custom/Espo/Custom/Resources/metadata/app/client.json';
            $clientData = [];
            if (file_exists($clientJsonFile)) {
                $decoded = @json_decode(file_get_contents($clientJsonFile), true);
                if (is_array($decoded)) $clientData = $decoded;
            }
            $cssList = $clientData['cssList'] ?? [];
            if (!in_array('client/custom/css/activity-monitor.css', $cssList)) {
                $cssList[] = 'client/custom/css/activity-monitor.css';
                $clientData['cssList'] = array_values($cssList);
                if (!is_dir(dirname($clientJsonFile))) @mkdir(dirname($clientJsonFile), 0777, true);
                @file_put_contents($clientJsonFile, json_encode($clientData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            }
        

            $scopes = [
                'Account' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Contact' => ['panel' => 'cSubscriptions', 'index' => 10],
                'Lead' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Opportunity' => ['panel' => 'cWonSubscriptions', 'index' => 110]
            ];
            foreach ($scopes as $scope => $info) {
                $file = "custom/Espo/Custom/Resources/layouts/{$scope}/bottomPanelsDetail.json";
                $panelName = $info['panel'];
                $data = [];
                if (file_exists($file)) {
                    $json = @json_decode(file_get_contents($file), true);
                    if (is_array($json)) $data = $json;
                }
                if (!isset($data[$panelName]) || !empty($data[$panelName]['disabled'])) {
                    $data[$panelName] = ['disabled' => false, 'index' => $info['index']];
                    if (!is_dir(dirname($file))) @mkdir(dirname($file), 0777, true);
                    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                }
            }
            try {
                $dataManager = $container->getByClass(\Espo\Core\DataManager::class) ?? $container->get('dataManager');
                if ($dataManager && method_exists($dataManager, 'clearCache')) {
                    $dataManager->clearCache();
                }
            } catch (\Throwable $e) {}
        

            if (class_exists(\Espo\Custom\WebPush\VapidKeys::class)) {
                (new \Espo\Custom\WebPush\VapidKeys())->isConfigured();
            }
            $customClientJson = 'custom/Espo/Custom/Resources/metadata/app/client.json';
            if (is_file($customClientJson)) {
                $cd = json_decode((string) file_get_contents($customClientJson), true);
                if (is_array($cd) && isset($cd['scriptList']) && is_array($cd['scriptList'])) {
                    $filtered = array_values(array_filter($cd['scriptList'], fn ($s) => $s !== 'client/custom/src/web-push.js'));
                    if (count($filtered) !== count($cd['scriptList'])) {
                        if ($filtered === []) {
                            unset($cd['scriptList']);
                        } else {
                            $cd['scriptList'] = $filtered;
                        }
                        unset($cd['developerModeScriptList']);
                        file_put_contents($customClientJson, json_encode($cd, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                    }
                }
            }
            if (!$container->has('user')) {
                $appUser = $container->getByClass(\Espo\Core\ApplicationUser::class);
                if ($appUser) {
                    $appUser->setupSystemUser();
                }
            }
            $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
            foreach ([
                'CallRouteReminders' => 'Call Route Reminders',
                'MeetingReminders' => 'Meeting Reminders',
                'PopupRemindersPush' => 'Popup Reminders Web Push',
            ] as $jobKey => $jobName) {
                $existingJob = $em->getRDBRepository('ScheduledJob')->where(['job' => $jobKey, 'deleted' => false])->findOne();
                if (!$existingJob) {
                    $sj = $em->getNewEntity('ScheduledJob');
                    $sj->set([
                        'name' => $jobName,
                        'job' => $jobKey,
                        'status' => 'Active',
                        'scheduling' => '* * * * *',
                    ]);
                    $em->saveEntity($sj, ['silent' => true]);
                }
            }


            // Configure CRM-wide Bangladeshi Time (Asia/Dhaka) and 12-hour AM/PM format (Reports, Imports, Call Start/End, Date Start)
            $configWriter->set('timeZone', 'Asia/Dhaka');
            $configWriter->set('timeFormat', 'hh:mm A');
            $configWriter->save();

            // Safely merge calendar-week.css into app/client.json without clobbering other extensions' CSS
            $clientJsonFile = 'custom/Espo/Custom/Resources/metadata/app/client.json';
            $clientData = [];
            if (file_exists($clientJsonFile)) {
                $decoded = @json_decode(file_get_contents($clientJsonFile), true);
                if (is_array($decoded)) $clientData = $decoded;
            }
            $cssList = $clientData['cssList'] ?? [];
            if (!in_array('client/custom/css/calendar-week.css', $cssList)) {
                $cssList[] = 'client/custom/css/calendar-week.css';
                $clientData['cssList'] = array_values($cssList);
                if (!is_dir(dirname($clientJsonFile))) @mkdir(dirname($clientJsonFile), 0777, true);
                @file_put_contents($clientJsonFile, json_encode($clientData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            }

            // Safely merge lead-source custom view into entityDefs/Lead.json without clobbering Product/Subscription fields
            $leadEntityFile = 'custom/Espo/Custom/Resources/metadata/entityDefs/Lead.json';
            $leadEntityDef = [];
            if (file_exists($leadEntityFile)) {
                $decoded = @json_decode(file_get_contents($leadEntityFile), true);
                if (is_array($decoded)) $leadEntityDef = $decoded;
            }
            if (!isset($leadEntityDef['fields']) || !is_array($leadEntityDef['fields'])) {
                $leadEntityDef['fields'] = [];
            }
            if (!isset($leadEntityDef['fields']['source']) || !is_array($leadEntityDef['fields']['source'])) {
                $leadEntityDef['fields']['source'] = [];
            }
            $leadEntityDef['fields']['source']['view'] = 'custom:views/fields/lead-source';
            if (!is_dir(dirname($leadEntityFile))) @mkdir(dirname($leadEntityFile), 0777, true);
            @file_put_contents($leadEntityFile, json_encode($leadEntityDef, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

            // Point Account.cLeadSource & Contact.cLeadSource to Lead.source via optionsReference so custom Lead sources always validate
            foreach (['Account', 'Contact'] as $srcScope) {
                $srcFile = "custom/Espo/Custom/Resources/metadata/entityDefs/{$srcScope}.json";
                if (file_exists($srcFile)) {
                    $srcDef = @json_decode(file_get_contents($srcFile), true);
                    if (is_array($srcDef) && isset($srcDef['fields']['cLeadSource'])) {
                        $srcDef['fields']['cLeadSource']['optionsReference'] = 'Lead.source';
                        unset($srcDef['fields']['cLeadSource']['options']);
                        @file_put_contents($srcFile, json_encode($srcDef, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                    }
                }
            }

            // Safely merge tasks prefill into clientDefs/Lead.json without clobbering Product/Subscription panels
            $leadDefFile = 'custom/Espo/Custom/Resources/metadata/clientDefs/Lead.json';
            $leadDef = [];
            if (file_exists($leadDefFile)) {
                $decoded = @json_decode(file_get_contents($leadDefFile), true);
                if (is_array($decoded)) $leadDef = $decoded;
            }
            if (!isset($leadDef['relationshipPanels']) || !is_array($leadDef['relationshipPanels'])) {
                $leadDef['relationshipPanels'] = [];
            }
            $leadDef['relationshipPanels']['tasks'] = [
                'createAttributeMap' => ['name' => 'name'],
                'createHandler' => 'custom:handlers/create-task-prefill'
            ];
            if (!is_dir(dirname($leadDefFile))) @mkdir(dirname($leadDefFile), 0777, true);
            @file_put_contents($leadDefFile, json_encode($leadDef, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

            // Wire Assigned User auto-fill preparator on Account, Contact, Lead, Opportunity create routes
            foreach (['Account', 'Contact', 'Lead', 'Opportunity'] as $scopeName) {
                $cdFile = "custom/Espo/Custom/Resources/metadata/clientDefs/{$scopeName}.json";
                $cdData = [];
                if (file_exists($cdFile)) {
                    $decoded = @json_decode(file_get_contents($cdFile), true);
                    if (is_array($decoded)) $cdData = $decoded;
                }
                $cdData['modelDefaultsPreparator'] = 'custom:handlers/sales-defaults-preparator';
                if (!is_dir(dirname($cdFile))) @mkdir(dirname($cdFile), 0777, true);
                @file_put_contents($cdFile, json_encode($cdData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            }
        

            $brandChanged = false;
            $currentAppName = (string) ($config->get('applicationName') ?? '');
            if ($currentAppName === '' || $currentAppName === 'EspoCRM') {
                $configWriter->set('applicationName', 'CGIT CRM');
                $brandChanged = true;
            }
            $currentAppDesc = (string) ($config->get('applicationDescription') ?? '');
            if ($currentAppDesc === '' || str_starts_with($currentAppDesc, 'EspoCRM')) {
                $configWriter->set('applicationDescription', 'CGIT CRM — Business & Customer Management Platform.');
                $brandChanged = true;
            }
            $currentFromName = (string) ($config->get('outboundEmailFromName') ?? '');
            if ($currentFromName === '' || $currentFromName === 'EspoCRM') {
                $configWriter->set('outboundEmailFromName', 'CGIT CRM');
                $brandChanged = true;
            }
            if ($brandChanged) {
                $configWriter->save();
            }

        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
