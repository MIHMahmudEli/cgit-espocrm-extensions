define('custom:views/fields/subscription-plan', ['views/fields/link'], function (Dep) {
    return Dep.extend({
        setup: function () {
            Dep.prototype.setup.call(this);
            this.validations = this.validations.concat(['subscription']);
            this.subscriptionCheck = 0;
            this.captureSavedPlan();
            this.listenTo(this.model, 'sync', this.captureSavedPlan);
            this.listenTo(this.model, 'change:planId change:clientId change:clientType', this.checkSubscription);
            this.on('after:render', this.renderSubscriptionHint, this);
            this.checkSubscription();
        },
        captureSavedPlan: function () {
            this.savedPlanId = this.model.get('planId');
            this.savedPlanValues = {};
            ['productId', 'productName', 'monthlyPrice', 'monthlyPriceCurrency', 'billingPeriod'].forEach(function (field) {
                this.savedPlanValues[field] = this.model.get(field);
            }, this);
        },
        previewPlan: function (plan) {
            if (!this.model.isNew() && (!plan || this.model.get('planId') === this.savedPlanId)) {
                this.model.set(Object.assign({}, this.savedPlanValues));
                return;
            }
            this.model.set({
                productId: plan ? plan.productId : null,
                productName: plan ? plan.productName : null,
                monthlyPrice: plan ? plan.monthlyPrice : null,
                monthlyPriceCurrency: plan ? plan.monthlyPriceCurrency : null,
                billingPeriod: plan ? (plan.billingPeriod || 'Monthly') : null
            });
        },
        getSelectFilters: function () {
            var filters = Object.assign({}, Dep.prototype.getSelectFilters.call(this) || {});
            filters.active = {type: 'equals', attribute: 'status', value: 'Active'};
            if (this.model.get('productId')) {
                filters.product = {type: 'equals', attribute: 'productId', value: this.model.get('productId')};
            }
            return filters;
        },
        checkSubscription: async function () {
            var sequence = ++this.subscriptionCheck;
            this.subscriptionMessage = null;
            this.existingSubscriptionId = null;
            this.checkPending = false;
            var planId = this.model.get('planId');
            if (!planId || !/^[a-z0-9]{17}$/i.test(planId)) { this.previewPlan(null); this.renderSubscriptionHint(); return; }
            this.checkPending = true;
            try {
                var plan = await Espo.Ajax.getRequest('CSubscriptionPlan/' + encodeURIComponent(planId), {}, { returnError: true });
                if (sequence !== this.subscriptionCheck) { return; }
                if (this.model.isNew() || plan.productId === this.savedPlanValues.productId) {
                    this.previewPlan(plan);
                }
                if (!this.model.isNew()) {
                    if (plan.productId !== this.savedPlanValues.productId) {
                        this.subscriptionMessage = 'Choose a plan for this subscription’s product. To subscribe to another product, create a separate subscription.';
                    }
                } else if (this.model.get('clientId') && this.model.get('clientType')) {
                    var result = await Espo.Ajax.getRequest('CClientSubscription', {
                        maxSize: 1, select: 'id,name',
                        where: [
                            {type: 'equals', attribute: 'clientId', value: this.model.get('clientId')},
                            {type: 'equals', attribute: 'clientType', value: this.model.get('clientType')},
                            {type: 'equals', attribute: 'productId', value: plan.productId}
                        ]
                    });
                    if (sequence !== this.subscriptionCheck) { return; }
                    if (result.list && result.list.length) {
                        this.existingSubscriptionId = result.list[0].id;
                        this.subscriptionMessage = 'This client already has a subscription for this product. Open it below to change the plan; a second subscription is not needed.';
                    }
                }
            } catch (error) {
                if (sequence === this.subscriptionCheck) {
                    this.subscriptionMessage = 'Could not verify the selected plan. Select it again or refresh before saving.';
                }
            } finally {
                if (sequence === this.subscriptionCheck) {
                    this.checkPending = false;
                    this.renderSubscriptionHint();
                }
            }
        },
        renderSubscriptionHint: function () {
            if (!this.$el) { return; }
            this.$el.find('.subscription-guidance').remove();
            if (!this.isEditMode() || !this.subscriptionMessage) { return; }
            var box = $('<div>').addClass('subscription-guidance text-warning').css('margin-top', '8px');
            $('<div>').text(this.subscriptionMessage).appendTo(box);
            if (this.existingSubscriptionId) {
                $('<a>').attr('href', '#CClientSubscription/edit/' + encodeURIComponent(this.existingSubscriptionId))
                    .text('Open existing subscription').appendTo(box);
            }
            this.$el.append(box);
        },
        validateSubscription: function () {
            if (this.checkPending || this.subscriptionMessage) {
                this.showValidationMessage(this.checkPending ? 'Checking the selected plan. Please wait a moment.' : this.subscriptionMessage);
                return true;
            }
            return false;
        }
    });
});
