define('custom:views/record/panels/history', ['crm:views/record/panels/history'], function (Dep) {

    return Dep.extend({

        setup: function () {
            this.listLayout = {
                'Email': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true }
                    ], [
                        { name: 'dateSent', soft: true },
                        { name: 'from' },
                        { name: 'hasAttachment', view: 'views/email/fields/has-attachment' }
                    ]]
                },
                'Call': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'cDescriptionDiff', view: 'custom:views/fields/description-change' }
                    ]]
                },
                'Meeting': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'cDescriptionDiff', view: 'custom:views/fields/description-change' }
                    ]]
                }
            };

            this.resolveParentScope();

            Dep.prototype.setup.call(this);

            this.collection.maxSize = 4;

            this.applyParentScopeUrl();
            this.applyProductServiceFilter();
            this.setupTypedCollectionSupport();
            this.setupAutoRefresh();
            this.setupParentChangeListener();
        },

        /**
         * Support parent-specific scoping for Call and Meeting detail views.
         */
        resolveParentScope: function () {
            var entityType = this.model.entityType || this.model.name;
            this.isActivityRecord = (entityType === 'Call' || entityType === 'Meeting');

            if (this.isActivityRecord) {
                this.parentType = this.model.get('parentType');
                this.parentId = this.model.get('parentId');
            } else {
                this.parentType = null;
                this.parentId = null;
            }
        },

        applyParentScopeUrl: function () {
            if (!this.collection) {
                return;
            }

            if (this.isActivityRecord) {
                if (this.parentType && this.parentId) {
                    this.url = 'Activities/' + this.parentType + '/' + this.parentId + '/history';
                    this.collection.url = this.url;
                } else {
                    // No parent associated; empty url to prevent fetching unrelated activities
                    this.url = 'Activities/EmptyParent/' + (this.model.id || 'none') + '/history';
                    this.collection.url = this.url;
                }
            }
        },

        setupParentChangeListener: function () {
            if (!this.isActivityRecord) {
                return;
            }

            this.listenTo(this.model, 'change:parentType change:parentId', function () {
                this.resolveParentScope();
                this.applyParentScopeUrl();
                if (this.collection) {
                    this.collection.fetch();
                }
            }.bind(this));
        },

        /**
         * Narrow down history list to product service(s) when present.
         */
        applyProductServiceFilter: function () {
            if (!this.collection) {
                return;
            }

            var idList = this.model.get('cProductServicesIds');

            if (!idList && this.model.get('cProductServiceId')) {
                idList = [this.model.get('cProductServiceId')];
            }

            if (Array.isArray(idList) && idList.length) {
                this.collection.data.productServiceIds = idList.join(',');
            } else {
                delete this.collection.data.productServiceIds;
            }
        },

        setupAutoRefresh: function () {
            this.listenTo(this.model, 'after:save', function () {
                if (this.historyRefreshTimer) {
                    clearTimeout(this.historyRefreshTimer);
                }

                this.historyRefreshTimer = setTimeout(function () {
                    this.historyRefreshTimer = null;

                    if (!this.collection) {
                        return;
                    }

                    this.applyProductServiceFilter();
                    this.collection.fetch();
                }.bind(this), 150);
            }.bind(this));
        },

        onRemove: function () {
            if (this.historyRefreshTimer) {
                clearTimeout(this.historyRefreshTimer);
                this.historyRefreshTimer = null;
            }

            if (Dep.prototype.onRemove) {
                Dep.prototype.onRemove.call(this);
            }
        },

        /**
         * Ensure:
         * 1. No Planned records appear in History.
         * 2. No duplicate IDs exist in the collection.
         * 3. Inherited Lead records are marked and scope attribute populated.
         */
        setupTypedCollectionSupport: function () {
            var collection = this.collection;
            var prepareAttributes = collection.prepareAttributes;

            collection.prepareAttributes = function (response, options) {
                if (response && Array.isArray(response.list)) {
                    var seenIds = {};
                    response.list = response.list.filter(function (attributes) {
                        if (!attributes || !attributes.id) {
                            return false;
                        }
                        if (attributes.status === 'Planned') {
                            return false;
                        }
                        if (seenIds[attributes.id]) {
                            return false;
                        }
                        seenIds[attributes.id] = true;
                        return true;
                    });

                    response.list.forEach(function (attributes) {
                        if (!attributes._scope) {
                            attributes._scope = 'Call';
                        }
                    });
                }

                return prepareAttributes.call(this, response, options);
            };
        },

        isNotReceivedFilterAvailable: function () {
            if (!this.getAcl().checkScope('Call')) {
                return false;
            }

            if (this.getMetadata().get(['scopes', this.model.entityType, 'activity'])) {
                return false;
            }

            return true;
        },

        setupFilterActions: function () {
            var available = this.isNotReceivedFilterAvailable();

            this.filterList = ['all'];

            if (available) {
                this.filterList.push('notReceived');
            }

            var filter = this.getStoredFilter();

            if (filter === 'notReceived' && !available) {
                filter = null;
            }

            if (filter === 'planned') {
                filter = null;
            }

            this.filter = filter;

            Dep.prototype.setupFilterActions.call(this);
        },

        translateFilter: function (name) {
            if (name === 'notReceived') {
                return this.getLanguage().translateOption('Not Received', 'status', 'Call');
            }

            return Dep.prototype.translateFilter.call(this, name);
        },

        setFilter: function (filter) {
            this.filter = filter;

            this.collection.data.entityType = null;
            this.collection.where = [];
            this.collection.url = this.url;

            if (filter === 'notReceived') {
                this.collection.url = this.url + '/list/Call';
                this.collection.where = [{
                    attribute: 'status',
                    type: 'equals',
                    value: 'Not Received'
                }];
            }
        },

        createView: function (name, viewName, options, callback) {
            if (name === 'list') {
                var origCallback = callback;
                callback = function (view) {
                    var decorate = function () {
                        this.decorateInheritedRows();
                        setTimeout(this.decorateInheritedRows.bind(this), 50);
                    }.bind(this);
                    this.listenTo(view, 'after:render after:show-more after:build-rows', decorate);
                    if (this.collection) {
                        this.listenTo(this.collection, 'sync', decorate);
                    }
                    if (typeof origCallback === 'function') {
                        origCallback.call(this, view);
                    }
                }.bind(this);
            }

            return Dep.prototype.createView.call(this, name, viewName, options, callback);
        },

        afterRender: function () {
            if (Dep.prototype.afterRender) {
                Dep.prototype.afterRender.call(this);
            }

            this.decorateInheritedRows();
        },

        decorateInheritedRows: function () {
            // Visually distinguish inherited Lead history rows
            this.$el.find('.list-row').each(function (i, el) {
                var $row = $(el);
                var rowModelId = $row.data('id');
                if (!rowModelId || !this.collection) return;

                var model = this.collection.get(rowModelId);
                if (model && model.get('isInheritedFromLead')) {
                    if (!$row.find('.inherited-lead-badge').length) {
                        var leadName = model.get('inheritedLeadName') || 'Lead';
                        var $badge = $('<span class="label label-info text-small inherited-lead-badge" style="display: inline-flex; align-items: center; gap: 4px; margin-left: 6px; font-size: 10px; line-height: 1.2; padding: 2px 6px; border-radius: 3px; font-weight: normal; vertical-align: middle;" title="Inherited from Lead"><i class="fas fa-history" style="font-size: 9px; line-height: 1;"></i><span>Inherited: ' + leadName + '</span></span>');
                        $row.find('.cell[data-name="name"]').append($badge);
                    }
                    $row.find('.action[data-action="editRecord"], .action[data-action="removeRelated"]').remove();
                }
            }.bind(this));
        },

        getCreateActivityAttributes: function (scope, data, callback) {
            Dep.prototype.getCreateActivityAttributes.call(this, scope, data, function (attributes) {
                var modelType = this.model ? (this.model.entityType || this.model.name) : null;
                if (modelType === 'Contact' && (scope === 'Call' || scope === 'Meeting') && this.model.id) {
                    attributes.parentType = 'Contact';
                    attributes.parentId = this.model.id;
                    attributes.parentName = this.model.get('name');
                }
                if (typeof callback === 'function') {
                    callback.call(this, attributes);
                }
            }.bind(this));
        }
    });

});
