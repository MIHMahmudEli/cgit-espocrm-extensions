define('custom:views/fields/description-change', ['custom:views/fields/description-preview'], function (Dep) {

    return Dep.extend({

        /**
         * The History row displays ONLY the newly added or updated description
         * content associated with the outcome, not the original planning description.
         * If `cDescriptionDiff` is available, render that. Otherwise fall back
         * to a preview of the full description (e.g. for records created directly as Held).
         */
        getValueForDisplay: function () {
            if (!this.isReadMode()) {
                return Dep.prototype.getValueForDisplay.call(this);
            }

            var changed = this.model.get('cDescriptionDiff');

            if (changed && String(changed).trim() !== '') {
                return String(changed).trim();
            }

            var fullDesc = this.model.get('description');
            if (fullDesc && String(fullDesc).trim() !== '') {
                return this.buildPreview(fullDesc);
            }

            return '';
        },

        data: function () {
            var data = Dep.prototype.data.call(this);

            if (this.isReadMode() && data.value) {
                data.isNotEmpty = true;
            }

            if (this.isReadMode()) {
                data.displayRawText = true;
            }

            return data;
        }

    });

});
