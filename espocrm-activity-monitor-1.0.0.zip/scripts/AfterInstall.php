<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["ActivityMonitor"];
            $tabList = $config->get('tabList') ?? [];
            $modified = false;
            foreach ($tabs as $tab) {
                if (!in_array($tab, $tabList)) {
                    $tabList[] = $tab;
                    $modified = true;
                }
            }
            if ($modified) {
                $configWriter->set('tabList', $tabList);
                $configWriter->save();
            }


        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
