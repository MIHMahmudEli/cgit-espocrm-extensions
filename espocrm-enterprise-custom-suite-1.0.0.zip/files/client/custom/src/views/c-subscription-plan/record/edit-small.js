define('custom:views/c-subscription-plan/record/edit-small', ['custom:views/c-subscription-plan/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({});

});
