define('custom:views/account/record/edit', ['views/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    var TARGET_PLACEHOLDER_FIELDS = [
        'name',
        'website',
        'emailAddress',
        'phoneNumber',
        'billingAddress',
        'shippingAddress',
        'description',
        'sicCode'
    ];

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            this.listenTo(this.model, 'change:cProductServicesNames change:cProductServicesIds change:industry change:type change:website', function () {
                this.updateNamePlaceholder();
            });
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            this.updateNamePlaceholder();
            this.updateAllPlaceholders();
            this.hookFieldViewRenderListeners();

            var nameView = this.getFieldView('name');
            if (nameView) {
                this.listenTo(nameView, 'after:render', this.updateNamePlaceholder.bind(this));
            }
        },

        getNamePlaceholder: function () {
            var prodName = '';
            var namesMap = this.model.get('cProductServicesNames');
            if (namesMap && typeof namesMap === 'object') {
                var vals = Object.values(namesMap).map(function (v) {
                    return v ? String(v).trim() : '';
                }).filter(Boolean);
                if (vals.length === 1) {
                    prodName = vals[0];
                } else if (vals.length > 1) {
                    prodName = vals.join(', ');
                }
            }

            var industry = (this.model.get('industry') || '').trim();
            var type = (this.model.get('type') || '').trim();

            if (prodName) {
                return 'e.g. Acme Corporation (' + prodName + ' Client)...';
            }

            if (industry) {
                return 'e.g. Acme Corporation (' + industry + ')...';
            }

            if (type && type !== 'Customer') {
                return 'e.g. Acme Solutions (' + type + ')...';
            }

            return 'e.g. Acme Corporation, Wayne Enterprises Ltd...';
        },

        getFieldPlaceholder: function (fieldName) {
            switch (fieldName) {
                case 'name':
                    return this.getNamePlaceholder();
                case 'website':
                    return 'e.g. https://www.company.com';
                case 'emailAddress':
                    return 'e.g. info@company.com, billing@company.com';
                case 'phoneNumber':
                    return 'e.g. +1 555-0100';
                case 'description':
                    return 'e.g. Corporate overview, key decision makers, strategic relationship notes, or contract context...';
                case 'sicCode':
                    return 'e.g. 7371 (Computer Programming Services)';
                default:
                    return '';
            }
        },

        applyFieldPlaceholder: function (fieldName, placeholder) {
            if (!fieldName) return;

            // Handle composite address fields
            if (fieldName === 'billingAddress' || fieldName === 'shippingAddress') {
                var isShipping = fieldName === 'shippingAddress';
                var addressMap = isShipping ? {
                    'shippingAddressStreet': 'e.g. 200 Warehouse Blvd, Dock 4',
                    'shippingAddressCity': 'e.g. Chicago',
                    'shippingAddressState': 'e.g. IL',
                    'shippingAddressPostalCode': 'e.g. 60601',
                    'shippingAddressCountry': 'e.g. United States'
                } : {
                    'billingAddressStreet': 'e.g. 100 Main Street, Suite 400',
                    'billingAddressCity': 'e.g. New York',
                    'billingAddressState': 'e.g. NY',
                    'billingAddressPostalCode': 'e.g. 10001',
                    'billingAddressCountry': 'e.g. United States'
                };

                Object.keys(addressMap).forEach(function (subName) {
                    var subPlaceholder = addressMap[subName];
                    if (this.$el && typeof this.$el.find === 'function') {
                        var $subElem = this.$el.find('[data-name="' + subName + '"]');
                        if ($subElem && $subElem.length) {
                            if (typeof $subElem.attr === 'function') {
                                $subElem.attr('placeholder', subPlaceholder);
                            } else if ($subElem[0] && typeof $subElem[0].setAttribute === 'function') {
                                $subElem[0].setAttribute('placeholder', subPlaceholder);
                            }
                        }
                    }
                }, this);

                var addressView = this.getFieldView(fieldName);
                if (addressView && addressView.$el && typeof addressView.$el.find === 'function') {
                    Object.keys(addressMap).forEach(function (subName) {
                        var $sub = addressView.$el.find('[data-name="' + subName + '"]');
                        if ($sub && $sub.length && typeof $sub.attr === 'function') {
                            $sub.attr('placeholder', addressMap[subName]);
                        }
                    });
                }
                return;
            }

            placeholder = placeholder || this.getFieldPlaceholder(fieldName);
            if (!placeholder) return;

            // Direct DOM search
            if (this.$el && typeof this.$el.find === 'function') {
                var $inputElem = this.$el.find('input[data-name="' + fieldName + '"]');
                if ($inputElem && $inputElem.length) {
                    if (typeof $inputElem.attr === 'function') {
                        $inputElem.attr('placeholder', placeholder);
                    } else if ($inputElem[0] && typeof $inputElem[0].setAttribute === 'function') {
                        $inputElem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $textElem = this.$el.find('textarea[data-name="' + fieldName + '"]');
                if ($textElem && $textElem.length) {
                    if (typeof $textElem.attr === 'function') {
                        $textElem.attr('placeholder', placeholder);
                    } else if ($textElem[0] && typeof $textElem[0].setAttribute === 'function') {
                        $textElem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $elem = this.$el.find('[data-name="' + fieldName + '"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('input, textarea');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="' + fieldName + '"], .field[data-name="' + fieldName + '"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('input, textarea');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            // Field view update
            var fieldView = this.getFieldView(fieldName);
            if (fieldView) {
                fieldView.placeholder = placeholder;
                if (fieldView.params) {
                    fieldView.params.placeholder = placeholder;
                }
                if (fieldView.$element) {
                    if (typeof fieldView.$element.attr === 'function') {
                        fieldView.$element.attr('placeholder', placeholder);
                    } else if (fieldView.$element[0] && typeof fieldView.$element[0].setAttribute === 'function') {
                        fieldView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (fieldView.$el && typeof fieldView.$el.find === 'function') {
                    var $inputs = fieldView.$el.find('input, textarea');
                    if ($inputs.length) {
                        if (typeof $inputs.attr === 'function') {
                            $inputs.attr('placeholder', placeholder);
                        } else if ($inputs[0] && typeof $inputs[0].setAttribute === 'function') {
                            $inputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        },

        updateNamePlaceholder: function () {
            var placeholder = this.getNamePlaceholder();

            var $input = this.$el && typeof this.$el.find === 'function' ? this.$el.find('input[data-name="name"]') : null;
            if ($input && $input.length) {
                if (typeof $input.attr === 'function') {
                    $input.attr('placeholder', placeholder);
                } else if ($input[0] && typeof $input[0].setAttribute === 'function') {
                    $input[0].setAttribute('placeholder', placeholder);
                }
            }

            this.applyFieldPlaceholder('name', placeholder);
        },

        updateAllPlaceholders: function () {
            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                this.applyFieldPlaceholder(fieldName);
            }, this);
        },

        hookFieldViewRenderListeners: function () {
            this._hookedFieldViews = this._hookedFieldViews || {};

            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                if (this._hookedFieldViews[fieldName]) return;
                var fieldView = this.getFieldView(fieldName);
                if (fieldView) {
                    this._hookedFieldViews[fieldName] = true;
                    this.listenTo(fieldView, 'after:render', function () {
                        this.applyFieldPlaceholder(fieldName);
                    }.bind(this));
                }
            }, this);
        }

    });

});
