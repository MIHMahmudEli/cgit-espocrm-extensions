<?php

namespace Espo\Custom\Hooks\Opportunity;

use Espo\Core\Hook\Hook\AfterRelate;
use Espo\Core\Hook\Hook\AfterSave;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\RelateOptions;
use Espo\ORM\Repository\Option\SaveOptions;

/**
 * Automatically associates an Opportunity's Product/Service(s) with its linked
 * Account and Contacts (appending without removing existing associations).
 */
class SyncProductServiceToClients implements AfterSave, AfterRelate
{
    public static int $order = 15;

    public function __construct(
        private EntityManager $entityManager
    ) {}

    public function afterSave(Entity $entity, SaveOptions $options): void
    {
        $productIds = $this->extractProductServiceIds($entity);
        if (empty($productIds)) {
            return;
        }

        $accountId = $entity->get('accountId');
        if ($accountId) {
            $account = $this->entityManager->getEntityById('Account', $accountId);
            if ($account) {
                $this->syncProductsToClient($account, $productIds);
            }
        }

        $contactIds = [];
        if ($entity->get('contactId')) {
            $contactIds[] = $entity->get('contactId');
        }
        if ($entity->hasLinkMultipleField('contacts')) {
            foreach ($entity->getLinkMultipleIdList('contacts') as $cId) {
                $contactIds[] = $cId;
            }
        }
        if ($entity->hasRelation('contacts') && $entity->getId()) {
            $persistedContacts = $this->entityManager
                ->getRDBRepository('Opportunity')
                ->getRelation($entity, 'contacts')
                ->select(['id'])
                ->find();
            foreach ($persistedContacts as $c) {
                $contactIds[] = $c->getId();
            }
        }

        $contactIds = array_values(array_unique(array_filter($contactIds)));
        foreach ($contactIds as $contactId) {
            $contact = $this->entityManager->getEntityById('Contact', $contactId);
            if ($contact) {
                $this->syncProductsToClient($contact, $productIds);
            }
        }
    }

    public function afterRelate(
        Entity $entity,
        string $relationName,
        Entity $relatedEntity,
        array $columnData,
        RelateOptions $options
    ): void {
        if ($relationName !== 'contacts' && $relationName !== 'account') {
            return;
        }

        $productIds = $this->extractProductServiceIds($entity);
        if (empty($productIds)) {
            return;
        }

        if ($relationName === 'contacts' && $relatedEntity->getEntityType() === 'Contact') {
            $this->syncProductsToClient($relatedEntity, $productIds);
        } elseif ($relationName === 'account' && $relatedEntity->getEntityType() === 'Account') {
            $this->syncProductsToClient($relatedEntity, $productIds);
        }
    }

    /**
     * @return string[]
     */
    private function extractProductServiceIds(Entity $entity): array
    {
        $ids = [];

        if ($entity->get('cProductServiceId')) {
            $ids[] = $entity->get('cProductServiceId');
        }
        if ($entity->hasAttribute('cWonProductId') && $entity->get('cWonProductId')) {
            $ids[] = $entity->get('cWonProductId');
        }
        if ($entity->hasLinkMultipleField('cProductServices')) {
            foreach ($entity->getLinkMultipleIdList('cProductServices') as $pId) {
                $ids[] = $pId;
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * @param string[] $productIds
     */
    private function syncProductsToClient(Entity $clientEntity, array $productIds): void
    {
        if (!$clientEntity->hasRelation('cProductServices')) {
            return;
        }

        $relation = $this->entityManager
            ->getRDBRepository($clientEntity->getEntityType())
            ->getRelation($clientEntity, 'cProductServices');

        foreach ($productIds as $productId) {
            $product = $this->entityManager->getEntityById('CProductService', $productId);
            if (!$product) {
                continue;
            }

            if (!$relation->isRelated($product)) {
                $relation->relate($product);
            }
        }
    }
}
