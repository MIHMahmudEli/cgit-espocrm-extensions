<?php

namespace Espo\Custom\Tools\ActivityMonitor;

use DateTimeImmutable;
use DateTimeZone;
use Espo\Core\Acl;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\ORM\EntityManager;
use Espo\Core\Utils\Language;
use Espo\Core\Utils\Metadata;
use Espo\Entities\User;
use PDO;

class Service
{
    public const ALLOWED_ENTITIES = [
        'Account',
        'Contact',
        'Lead',
        'Opportunity',
        'Email',
        'Meeting',
        'Call',
        'CProductService',
        'CClientSubscription',
        'CSubscriptionPlan',
        'Task',
        'Calendar',
        'Case',
        'KnowledgeBaseArticle',
        'KnowledgeBaseCategory',
    ];

    private const STATUS_FIELDS = ['status', 'stage', 'state', 'phase'];

    public function __construct(
        private EntityManager $entityManager,
        private Metadata $metadata,
        private Language $language,
        private Acl $acl,
        private User $user,
    ) {}

    private function getPdo(): PDO
    {
        return $this->entityManager->getPDO();
    }

    /**
     * Parse date range string into UTC datetimes.
     *
     * @return array{0: string, 1: string, 2: string} [fromUtc, toUtc, timezone]
     */
    public function resolveDateRange(array $params): array
    {
        $timezone = !empty($params['timezone']) ? (string) $params['timezone'] : 'Asia/Dhaka';

        try {
            $tz = new DateTimeZone($timezone);
        } catch (\Throwable) {
            $timezone = 'Asia/Dhaka';
            $tz = new DateTimeZone($timezone);
        }

        $now = new DateTimeImmutable('now', $tz);
        $quick = !empty($params['quickRange']) ? (string) $params['quickRange'] : null;

        if ($quick) {
            switch ($quick) {
                case '3h':
                    $fromDt = $now->modify('-3 hours');
                    $toDt = $now;
                    break;
                case '24h':
                    $fromDt = $now->modify('-24 hours');
                    $toDt = $now;
                    break;
                case '7d':
                    $fromDt = $now->modify('-7 days');
                    $toDt = $now;
                    break;
                case 'today':
                    $fromDt = $now->setTime(0, 0, 0);
                    $toDt = $now;
                    break;
                case 'yesterday':
                    $fromDt = $now->modify('-1 day')->setTime(0, 0, 0);
                    $toDt = $now->modify('-1 day')->setTime(23, 59, 59);
                    break;
                case 'thisWeek':
                    $fromDt = $now->modify('monday this week')->setTime(0, 0, 0);
                    $toDt = $now;
                    break;
                case 'lastWeek':
                    $fromDt = $now->modify('monday last week')->setTime(0, 0, 0);
                    $toDt = $now->modify('sunday last week')->setTime(23, 59, 59);
                    break;
                case 'thisMonth':
                    $fromDt = $now->modify('first day of this month')->setTime(0, 0, 0);
                    $toDt = $now;
                    break;
                case 'last30d':
                    $fromDt = $now->modify('-30 days');
                    $toDt = $now;
                    break;
                default:
                    $quick = null;
                    break;
            }
        }

        if (!$quick) {
            $fromStr = !empty($params['from']) ? trim((string) $params['from']) : null;
            $toStr = !empty($params['to']) ? trim((string) $params['to']) : null;

            if ($fromStr) {
                try {
                    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $fromStr)) {
                        $fromStr .= ' 00:00:00';
                    }
                    $fromDt = new DateTimeImmutable($fromStr);
                    if (!preg_match('/[+-]\d{2}:\d{2}|Z$/i', $fromStr)) {
                        $fromDt = new DateTimeImmutable($fromStr, $tz);
                    }
                } catch (\Throwable) {
                    $fromDt = $now->modify('-24 hours');
                }
            } else {
                $fromDt = $now->modify('-24 hours');
            }

            if ($toStr) {
                try {
                    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $toStr)) {
                        $toStr .= ' 23:59:59';
                    }
                    $toDt = new DateTimeImmutable($toStr);
                    if (!preg_match('/[+-]\d{2}:\d{2}|Z$/i', $toStr)) {
                        $toDt = new DateTimeImmutable($toStr, $tz);
                    }
                } catch (\Throwable) {
                    $toDt = $now;
                }
            } else {
                $toDt = $now;
            }
        }

        $utcTz = new DateTimeZone('UTC');
        $fromUtc = $fromDt->setTimezone($utcTz)->format('Y-m-d H:i:s');
        $toUtc = $toDt->setTimezone($utcTz)->format('Y-m-d H:i:s');

        return [$fromUtc, $toUtc, $timezone];
    }

    /**
     * Get list of activities with filtering and pagination.
     */
    public function getList(array $params): array
    {
        [$fromUtc, $toUtc, $timezone] = $this->resolveDateRange($params);

        $userIds = $this->parseArrayParam($params['userIds'] ?? null);
        $entityTypes = $this->parseArrayParam($params['entityTypes'] ?? null);
        $activityTypes = $this->parseArrayParam($params['activityTypes'] ?? null);
        $search = !empty($params['search']) ? trim((string) $params['search']) : null;

        $offset = max(0, (int) ($params['offset'] ?? 0));
        $maxSize = max(1, min(100, (int) ($params['maxSize'] ?? 25)));

        $allActivities = $this->fetchRawActivities($fromUtc, $toUtc, $userIds, $entityTypes, $activityTypes, $search);

        $total = count($allActivities);
        $sliced = array_slice($allActivities, $offset, $maxSize);

        // Enrich with record names and field change details
        $enriched = $this->enrichActivities($sliced, $timezone);

        return [
            'list' => $enriched,
            'total' => $total,
            'offset' => $offset,
            'maxSize' => $maxSize,
            'hasMore' => ($offset + $maxSize) < $total,
            'fromUtc' => $fromUtc,
            'toUtc' => $toUtc,
            'timezone' => $timezone,
        ];
    }

    /**
     * Get management summary metrics & breakdowns.
     */
    public function getSummary(array $params): array
    {
        [$fromUtc, $toUtc, $timezone] = $this->resolveDateRange($params);

        $userIds = $this->parseArrayParam($params['userIds'] ?? null);
        $entityTypes = $this->parseArrayParam($params['entityTypes'] ?? null);
        $activityTypes = $this->parseArrayParam($params['activityTypes'] ?? null);
        $search = !empty($params['search']) ? trim((string) $params['search']) : null;

        $allActivities = $this->fetchRawActivities($fromUtc, $toUtc, $userIds, $entityTypes, $activityTypes, $search);
        $enriched = $this->enrichActivities($allActivities, $timezone);

        $total = count($enriched);
        $typeCounts = [
            'Created' => 0,
            'Updated' => 0,
            'Status Changed' => 0,
            'statusChanged' => 0,
            'Converted' => 0,
            'Deleted' => 0,
            'Assigned' => 0,
            'Post' => 0,
        ];

        $userCounts = [];
        $entityCounts = [];
        $timelineBuckets = [];

        $useHourly = (strtotime($toUtc) - strtotime($fromUtc)) <= 48 * 3600;

        foreach ($enriched as $item) {
            $type = $item['activityType'];
            if (!isset($typeCounts[$type])) {
                $typeCounts[$type] = 0;
            }
            $typeCounts[$type]++;
            if ($type === 'Status Changed') {
                $typeCounts['statusChanged']++;
            }

            // User stats (human users only on leaderboard)
            $uId = $item['userId'];
            if ($uId && strtolower((string) $uId) !== 'system') {
                $uName = $item['userName'] ?: 'User #' . $uId;
                if (!isset($userCounts[$uId])) {
                    $userCounts[$uId] = [
                        'userId' => $uId,
                        'userName' => $uName,
                        'count' => 0,
                    ];
                }
                $userCounts[$uId]['count']++;
            }

            // Entity stats
            $eType = $item['entityType'];
            $eLabel = $this->getEntityLabel($eType);
            if (!isset($entityCounts[$eType])) {
                $entityCounts[$eType] = [
                    'entityType' => $eType,
                    'entityLabel' => $eLabel,
                    'count' => 0,
                ];
            }
            $entityCounts[$eType]['count']++;

            // Timeline bucket
            $dtLocal = new DateTimeImmutable($item['createdAtUtc']);
            $dtInTz = $dtLocal->setTimezone(new DateTimeZone($timezone));
            $bucketKey = $useHourly ? $dtInTz->format('Y-m-d H:00') : $dtInTz->format('Y-m-d');
            if (!isset($timelineBuckets[$bucketKey])) {
                $timelineBuckets[$bucketKey] = 0;
            }
            $timelineBuckets[$bucketKey]++;
        }

        // Calculate percentages & sort
        usort($userCounts, fn($a, $b) => $b['count'] <=> $a['count']);
        $humanTotal = array_sum(array_column($userCounts, 'count'));
        foreach ($userCounts as &$u) {
            $u['percentage'] = $humanTotal > 0 ? round(($u['count'] / $humanTotal) * 100, 1) : 0;
        }

        usort($entityCounts, fn($a, $b) => $b['count'] <=> $a['count']);
        foreach ($entityCounts as &$e) {
            $e['percentage'] = $total > 0 ? round(($e['count'] / $total) * 100, 1) : 0;
        }

        // Timeline array sorted chronologically
        ksort($timelineBuckets);
        $timeline = [];
        foreach ($timelineBuckets as $key => $count) {
            $timeline[] = [
                'time' => $key,
                'count' => $count,
            ];
        }

        return [
            'totalActivities' => $total,
            'typeCounts' => $typeCounts,
            'userStats' => array_values($userCounts),
            'entityStats' => array_values($entityCounts),
            'timeline' => $timeline,
            'fromUtc' => $fromUtc,
            'toUtc' => $toUtc,
            'timezone' => $timezone,
        ];
    }

    /**
     * Get filter options (users list, entity list, activity types).
     */
    public function getFilterData(): array
    {
        $pdo = $this->getPdo();

        // Active and relevant users (strictly excluding system accounts)
        $stmtUsers = $pdo->query("
            SELECT id, user_name, first_name, last_name, type, avatar_color 
            FROM `user` 
            WHERE deleted = 0 
              AND type != 'system' 
              AND id != 'system'
              AND LOWER(COALESCE(user_name, '')) != 'system'
            ORDER BY is_active DESC, type ASC, first_name ASC, last_name ASC
        ");
        $userRows = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);

        $users = [];
        foreach ($userRows as $r) {
            $name = trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''));
            if (!$name) {
                $name = $r['user_name'];
            }
            $users[] = [
                'id' => $r['id'],
                'name' => $name,
                'userName' => $r['user_name'],
                'type' => $r['type'],
            ];
        }

        // Allowed entity scopes only
        $scopes = $this->metadata->get('scopes') ?? [];
        $entities = [];

        foreach (self::ALLOWED_ENTITIES as $pe) {
            if (isset($scopes[$pe])) {
                $entities[] = [
                    'name' => $pe,
                    'label' => $this->getEntityLabel($pe),
                ];
            }
        }

        $activityTypes = [
            ['name' => 'Created', 'label' => 'Created'],
            ['name' => 'Updated', 'label' => 'Updated'],
            ['name' => 'Status Changed', 'label' => 'Status Changed'],
            ['name' => 'Converted', 'label' => 'Converted'],
            ['name' => 'Deleted', 'label' => 'Deleted'],
            ['name' => 'Assigned', 'label' => 'Assigned'],
            ['name' => 'Post', 'label' => 'Post / Note'],
        ];

        return [
            'users' => $users,
            'entities' => $entities,
            'activityTypes' => $activityTypes,
            'defaultTimezone' => 'Asia/Dhaka',
        ];
    }

    /**
     * Fetch raw activity rows from note and action_history_record.
     */
    private function fetchRawActivities(
        string $fromUtc,
        string $toUtc,
        array $userIds,
        array $entityTypes,
        array $activityTypes,
        ?string $search,
    ): array {
        $pdo = $this->getPdo();
        $activities = [];

        // Strictly enforce allowed entities
        $effectiveEntityTypes = !empty($entityTypes)
            ? array_values(array_intersect($entityTypes, self::ALLOWED_ENTITIES))
            : self::ALLOWED_ENTITIES;

        if (empty($effectiveEntityTypes)) {
            return [];
        }

        // Check if we need note table
        $needNotes = empty($activityTypes) || array_intersect(
            $activityTypes,
            ['Created', 'Updated', 'Status Changed', 'Converted', 'Assigned', 'Post']
        );

        if ($needNotes) {
            $whereClauses = [
                'n.deleted = 0',
                'n.created_at >= :fromUtc',
                'n.created_at <= :toUtc',
                "n.created_by_id != 'system'",
                'n.created_by_id IS NOT NULL',
                "n.created_by_id != ''",
                "(u.type IS NULL OR u.type != 'system')",
                "(u.user_name IS NULL OR LOWER(u.user_name) != 'system')",
            ];
            $bindings = [
                ':fromUtc' => $fromUtc,
                ':toUtc' => $toUtc,
            ];

            if (!empty($userIds)) {
                $inPlaceholders = [];
                foreach ($userIds as $idx => $uid) {
                    if ($uid === 'system') continue;
                    $ph = ":uid_$idx";
                    $inPlaceholders[] = $ph;
                    $bindings[$ph] = $uid;
                }
                if (!empty($inPlaceholders)) {
                    $whereClauses[] = 'n.created_by_id IN (' . implode(',', $inPlaceholders) . ')';
                }
            }

            // Entity types filter for note (restricted strictly to allowed entities)
            $entPlaceholders = [];
            foreach ($effectiveEntityTypes as $idx => $et) {
                $ph = ":ent_$idx";
                $entPlaceholders[] = $ph;
                $bindings[$ph] = $et;
            }
            $inEnt = implode(',', $entPlaceholders);
            $whereClauses[] = "(
                (n.type = 'CreateRelated' AND (n.related_type IN ($inEnt) OR n.parent_type IN ($inEnt)))
                OR (n.type != 'CreateRelated' AND n.parent_type IN ($inEnt))
            )";

            // Note types
            $noteTypes = [];
            if (!empty($activityTypes)) {
                if (in_array('Created', $activityTypes)) {
                    $noteTypes[] = 'Create';
                    $noteTypes[] = 'CreateRelated';
                }
                if (in_array('Updated', $activityTypes) || in_array('Status Changed', $activityTypes) || in_array('Converted', $activityTypes)) {
                    $noteTypes[] = 'Update';
                }
                if (in_array('Assigned', $activityTypes)) {
                    $noteTypes[] = 'Assign';
                }
                if (in_array('Post', $activityTypes)) {
                    $noteTypes[] = 'Post';
                }
            } else {
                $noteTypes = ['Create', 'CreateRelated', 'Update', 'Assign', 'Post'];
            }

            if (!empty($noteTypes)) {
                $ntPlaceholders = [];
                foreach (array_unique($noteTypes) as $idx => $nt) {
                    $ph = ":nt_$idx";
                    $ntPlaceholders[] = $ph;
                    $bindings[$ph] = $nt;
                }
                $whereClauses[] = 'n.type IN (' . implode(',', $ntPlaceholders) . ')';
            }

            $sql = "
                SELECT 
                    n.id,
                    'note' as source,
                    n.type as note_type,
                    n.post,
                    n.data,
                    n.created_at,
                    n.parent_id,
                    n.parent_type,
                    n.related_id,
                    n.related_type,
                    n.created_by_id,
                    u.first_name,
                    u.last_name,
                    u.user_name,
                    u.avatar_color
                FROM note n
                LEFT JOIN `user` u ON u.id = n.created_by_id
                WHERE " . implode(' AND ', $whereClauses) . "
                ORDER BY n.created_at DESC
                LIMIT 5000
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($bindings);
            $noteRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($noteRows as $row) {
                // Determine target entity & action type
                $item = $this->parseNoteRow($row);
                if ($item) {
                    // Check activityTypes filter for sub-types (Status Changed, Converted)
                    if (!empty($activityTypes)) {
                        if (!in_array($item['activityType'], $activityTypes)) {
                            // If user selected Updated, and item is Status Changed, allow it
                            if (in_array('Updated', $activityTypes) && $item['activityType'] === 'Status Changed') {
                                // allowed
                            } else {
                                continue;
                            }
                        }
                    }
                    $activities[] = $item;
                }
            }
        }

        // Check if we need delete actions from action_history_record
        $needDeletes = empty($activityTypes) || in_array('Deleted', $activityTypes);

        if ($needDeletes) {
            $whereDel = [
                'a.action = "delete"',
                'a.deleted = 0',
                'a.created_at >= :fromUtc',
                'a.created_at <= :toUtc',
                "a.user_id != 'system'",
                'a.user_id IS NOT NULL',
                "a.user_id != ''",
                "(u.type IS NULL OR u.type != 'system')",
                "(u.user_name IS NULL OR LOWER(u.user_name) != 'system')",
            ];
            $delBindings = [
                ':fromUtc' => $fromUtc,
                ':toUtc' => $toUtc,
            ];

            if (!empty($userIds)) {
                $inPlaceholders = [];
                foreach ($userIds as $idx => $uid) {
                    if ($uid === 'system') continue;
                    $ph = ":duid_$idx";
                    $inPlaceholders[] = $ph;
                    $delBindings[$ph] = $uid;
                }
                if (!empty($inPlaceholders)) {
                    $whereDel[] = 'a.user_id IN (' . implode(',', $inPlaceholders) . ')';
                }
            }

            // Entity types filter for delete (strictly allowed entities)
            $entPlaceholders = [];
            foreach ($effectiveEntityTypes as $idx => $et) {
                $ph = ":dent_$idx";
                $entPlaceholders[] = $ph;
                $delBindings[$ph] = $et;
            }
            $whereDel[] = 'a.target_type IN (' . implode(',', $entPlaceholders) . ')';

            $sqlDel = "
                SELECT 
                    a.id,
                    'action_history' as source,
                    'delete' as note_type,
                    NULL as post,
                    a.data,
                    a.created_at,
                    a.target_id as parent_id,
                    a.target_type as parent_type,
                    NULL as related_id,
                    NULL as related_type,
                    a.user_id as created_by_id,
                    u.first_name,
                    u.last_name,
                    u.user_name,
                    u.avatar_color
                FROM action_history_record a
                LEFT JOIN `user` u ON u.id = a.user_id
                WHERE " . implode(' AND ', $whereDel) . "
                ORDER BY a.created_at DESC
                LIMIT 1000
            ";

            $stmtDel = $pdo->prepare($sqlDel);
            $stmtDel->execute($delBindings);
            $delRows = $stmtDel->fetchAll(PDO::FETCH_ASSOC);

            foreach ($delRows as $row) {
                $item = $this->parseDeleteRow($row);
                if ($item) {
                    $activities[] = $item;
                }
            }
        }

        // Sort all merged activities by createdAt DESC
        usort($activities, fn($a, $b) => strcmp($b['createdAtUtc'], $a['createdAtUtc']));

        // Deduplicate any rare overlapping create events
        $seen = [];
        $unique = [];
        foreach ($activities as $act) {
            $dedupKey = $act['activityType'] . '_' . $act['entityType'] . '_' . $act['recordId'] . '_' . substr($act['createdAtUtc'], 0, 16);
            if (isset($seen[$dedupKey])) {
                continue;
            }
            $seen[$dedupKey] = true;
            $unique[] = $act;
        }

        // Search filter if provided
        if ($search !== null && $search !== '') {
            $searchLower = strtolower($search);
            $unique = array_values(array_filter($unique, function ($act) use ($searchLower) {
                if (str_contains(strtolower($act['recordName'] ?? ''), $searchLower)) return true;
                if (str_contains(strtolower($act['userName'] ?? ''), $searchLower)) return true;
                if (str_contains(strtolower($act['entityType'] ?? ''), $searchLower)) return true;
                if (str_contains(strtolower($act['activityType'] ?? ''), $searchLower)) return true;
                if (!empty($act['postContent']) && str_contains(strtolower($act['postContent']), $searchLower)) return true;
                if (!empty($act['fieldChanges'])) {
                    foreach ($act['fieldChanges'] as $fc) {
                        if (str_contains(strtolower($fc['fieldLabel'] ?? ''), $searchLower)) return true;
                        if (str_contains(strtolower($fc['was'] ?? ''), $searchLower)) return true;
                        if (str_contains(strtolower($fc['became'] ?? ''), $searchLower)) return true;
                    }
                }
                return false;
            }));
        }

        return $unique;
    }

    /**
     * Parse note table row into normalized activity data.
     */
    private function parseNoteRow(array $row): ?array
    {
        $userId = $row['created_by_id'] ?? null;
        $userName = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
        if (!$userName) {
            $userName = $row['user_name'] ?: '';
        }

        // Exclude system user activity
        if ($userId === 'system' || empty($userId) || strtolower($userName) === 'system') {
            return null;
        }

        $noteType = $row['note_type'];
        $data = $row['data'] ? json_decode($row['data'], true) : [];

        $entityType = $row['parent_type'];
        $recordId = $row['parent_id'];
        $relatedEntityType = null;
        $relatedRecordId = null;

        $activityType = 'Updated';
        $fieldChanges = [];
        $postContent = null;

        if ($noteType === 'CreateRelated') {
            $activityType = 'Created';
            $entityType = $row['related_type'] ?: $row['parent_type'];
            $recordId = $row['related_id'] ?: $row['parent_id'];
            $relatedEntityType = $row['parent_type'];
            $relatedRecordId = $row['parent_id'];
        } elseif ($noteType === 'Create') {
            $activityType = 'Created';
        } elseif ($noteType === 'Assign') {
            $activityType = 'Assigned';
            if (!empty($data['assignedUserName'])) {
                $fieldChanges[] = [
                    'field' => 'assignedUser',
                    'fieldLabel' => 'Assigned User',
                    'was' => '-',
                    'became' => $data['assignedUserName'],
                ];
            }
        } elseif ($noteType === 'Post') {
            $activityType = 'Post';
            $postContent = $row['post'] ?? ($data['post'] ?? '');
        } elseif ($noteType === 'Update') {
            $activityType = 'Updated';

            // Check if it's a lead conversion
            if ($entityType === 'Lead' && (
                ($data['value'] ?? null) === 'Converted' ||
                (($data['attributes']['became']['status'] ?? null) === 'Converted') ||
                !empty($data['attributes']['became']['isConverted'])
            )) {
                $activityType = 'Converted';
            }

            // Parse field diffs
            if (!empty($data['fields']) && is_array($data['fields'])) {
                $wasAttrs = $data['attributes']['was'] ?? [];
                $becameAttrs = $data['attributes']['became'] ?? [];

                $hasStatusChange = false;

                foreach ($data['fields'] as $f) {
                    if (in_array(strtolower($f), self::STATUS_FIELDS)) {
                        $hasStatusChange = true;
                    }

                    $fieldLabel = $this->formatFieldLabel($f, $entityType);

                    // Link fields: prefer planName over planId, etc.
                    $wasVal = $wasAttrs[$f . 'Name'] ?? ($wasAttrs[$f] ?? null);
                    $becameVal = $becameAttrs[$f . 'Name'] ?? ($becameAttrs[$f] ?? null);

                    $fieldChanges[] = [
                        'field' => $f,
                        'fieldLabel' => $fieldLabel,
                        'was' => $this->formatValue($wasVal),
                        'became' => $this->formatValue($becameVal),
                    ];
                }

                if ($hasStatusChange && $activityType !== 'Converted') {
                    $activityType = 'Status Changed';
                }
            }
        }

        if (!$entityType || !$recordId) {
            return null;
        }

        if (!in_array($entityType, self::ALLOWED_ENTITIES)) {
            return null;
        }

        $cachedName = $data['attributes']['became']['name'] 
            ?? $data['attributes']['was']['name'] 
            ?? $data['name'] 
            ?? $data['parentName'] 
            ?? null;

        return [
            'id' => $row['id'],
            'source' => 'note',
            'activityType' => $activityType,
            'entityType' => $entityType,
            'recordId' => $recordId,
            'recordName' => $cachedName,
            'relatedEntityType' => $relatedEntityType,
            'relatedRecordId' => $relatedRecordId,
            'relatedRecordName' => null,
            'userId' => $userId,
            'userName' => $userName,
            'userAvatarColor' => $row['avatar_color'] ?? '#6c757d',
            'createdAtUtc' => $row['created_at'],
            'fieldChanges' => $fieldChanges,
            'postContent' => $postContent,
            'isDeleted' => false,
        ];
    }

    /**
     * Parse action_history_record delete row into normalized activity data.
     */
    private function parseDeleteRow(array $row): ?array
    {
        $userId = $row['created_by_id'] ?? null;
        $userName = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
        if (!$userName) {
            $userName = $row['user_name'] ?: '';
        }

        // Exclude system user activity
        if ($userId === 'system' || empty($userId) || strtolower($userName) === 'system') {
            return null;
        }

        $entityType = $row['parent_type'];
        if (!$entityType || !in_array($entityType, self::ALLOWED_ENTITIES)) {
            return null;
        }

        return [
            'id' => $row['id'],
            'source' => 'action_history',
            'activityType' => 'Deleted',
            'entityType' => $entityType,
            'recordId' => $row['parent_id'],
            'recordName' => null, // will be enriched
            'relatedEntityType' => null,
            'relatedRecordId' => null,
            'relatedRecordName' => null,
            'userId' => $userId,
            'userName' => $userName,
            'userAvatarColor' => $row['avatar_color'] ?? '#dc3545',
            'createdAtUtc' => $row['created_at'],
            'fieldChanges' => [],
            'postContent' => null,
            'isDeleted' => true,
        ];
    }

    /**
     * Enrich activity rows with record names and local timestamps.
     */
    private function enrichActivities(array $activities, string $timezone): array
    {
        if (empty($activities)) {
            return [];
        }

        // Batch gather entity IDs to fetch names
        $entityIdMap = [];
        foreach ($activities as $act) {
            $entityIdMap[$act['entityType']][$act['recordId']] = true;
            if ($act['relatedEntityType'] && $act['relatedRecordId']) {
                $entityIdMap[$act['relatedEntityType']][$act['relatedRecordId']] = true;
            }
        }

        $namesMap = $this->batchFetchRecordNames($entityIdMap);

        $tz = new DateTimeZone($timezone);
        $now = new DateTimeImmutable('now', $tz);

        foreach ($activities as &$act) {
            $eType = $act['entityType'];
            $rId = $act['recordId'];

            $act['entityLabel'] = $this->getEntityLabel($eType);

            if (isset($namesMap[$eType][$rId])) {
                $act['recordName'] = $namesMap[$eType][$rId]['name'];
                if ($namesMap[$eType][$rId]['deleted']) {
                    $act['isDeleted'] = true;
                }
            } else {
                $act['isDeleted'] = true;
                if (empty($act['recordName'])) {
                    $act['recordName'] = 'Deleted ' . $act['entityLabel'];
                }
            }

            $act['shortRecordId'] = strlen((string) $rId) > 10 ? substr((string) $rId, 0, 8) . '...' : (string) $rId;

            if ($act['relatedEntityType'] && $act['relatedRecordId']) {
                $reType = $act['relatedEntityType'];
                $reId = $act['relatedRecordId'];
                $act['relatedEntityLabel'] = $this->getEntityLabel($reType);
                if (isset($namesMap[$reType][$reId])) {
                    $act['relatedRecordName'] = $namesMap[$reType][$reId]['name'];
                    if ($namesMap[$reType][$reId]['deleted']) {
                        $act['isRelatedDeleted'] = true;
                    }
                } else {
                    $act['isRelatedDeleted'] = true;
                    if (empty($act['relatedRecordName'])) {
                        $act['relatedRecordName'] = 'Deleted ' . $act['relatedEntityLabel'];
                    }
                }
            }

            // Url link
            $act['recordUrl'] = '#' . $eType . '/view/' . $rId;

            // Timestamp formatting
            $dt = new DateTimeImmutable($act['createdAtUtc']);
            $dtLocal = $dt->setTimezone($tz);
            $act['timestampFormatted'] = $dtLocal->format('Y-m-d h:i A');
            $act['timeFormatted'] = $dtLocal->format('h:i:s A');
            $act['dateFormatted'] = $dtLocal->format('M d, Y');
            $act['relativeTime'] = $this->getRelativeTime($dtLocal, $now);

            $act['isSystemUser'] = ($act['userId'] === 'system' || empty($act['userId']));
            if ($act['isSystemUser']) {
                $act['userName'] = 'System';
                $act['userAvatarColor'] = '#6c757d';
            }
        }

        return $activities;
    }

    /**
     * Batch fetch names for record IDs grouped by entity type.
     */
    private function batchFetchRecordNames(array $entityIdMap): array
    {
        $pdo = $this->getPdo();
        $result = [];

        foreach ($entityIdMap as $entityType => $idSet) {
            $ids = array_keys($idSet);
            if (empty($ids)) continue;

            $tableName = strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $entityType));

            // Verify table exists
            try {
                $chk = $pdo->query("SHOW TABLES LIKE '$tableName'")->fetchColumn();
                if (!$chk) {
                    continue;
                }

                $placeholders = implode(',', array_fill(0, count($ids), '?'));

                if (in_array($entityType, ['Lead', 'Contact'])) {
                    $sql = "SELECT id, first_name, last_name, deleted FROM `$tableName` WHERE id IN ($placeholders)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($ids);
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $name = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
                        $result[$entityType][$row['id']] = [
                            'name' => $name ?: "(No Name)",
                            'deleted' => (bool) $row['deleted'],
                        ];
                    }
                } else {
                    $cols = $pdo->query("DESCRIBE `$tableName`")->fetchAll(PDO::FETCH_COLUMN);
                    $hasName = in_array('name', $cols);
                    $hasDeleted = in_array('deleted', $cols);

                    $selName = $hasName ? 'name' : 'id as name';
                    $selDel = $hasDeleted ? 'deleted' : '0 as deleted';

                    $sql = "SELECT id, $selName, $selDel FROM `$tableName` WHERE id IN ($placeholders)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($ids);
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $result[$entityType][$row['id']] = [
                            'name' => $row['name'] ?: "(No Name)",
                            'deleted' => (bool) $row['deleted'],
                        ];
                    }
                }
            } catch (\Throwable) {
                // Table query fallback
            }
        }

        return $result;
    }

    private function getRelativeTime(DateTimeImmutable $then, DateTimeImmutable $now): string
    {
        $diff = $now->getTimestamp() - $then->getTimestamp();
        if ($diff < 60) {
            return 'Just now';
        }
        if ($diff < 3600) {
            $m = (int) ($diff / 60);
            return $m === 1 ? '1 minute ago' : "$m minutes ago";
        }
        if ($diff < 86400) {
            $h = (int) ($diff / 3600);
            return $h === 1 ? '1 hour ago' : "$h hours ago";
        }
        $d = (int) ($diff / 86400);
        return $d === 1 ? 'Yesterday' : "$d days ago";
    }

    public function getEntityLabel(string $entityType): string
    {
        $label = $this->language->translate($entityType, 'scopeNames');
        if ($label && $label !== $entityType) {
            return $label;
        }

        $singular = $this->language->translate($entityType, 'scopeNamesSingular');
        if ($singular && $singular !== $entityType) {
            return $singular;
        }

        // Clean up custom entity prefixes (e.g. CClientSubscription -> Client Subscription)
        $clean = preg_replace('/^C([A-Z])/', '$1', $entityType);
        return ucwords(preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', $clean));
    }

    private function formatFieldLabel(string $field, ?string $entityType = null): string
    {
        if ($entityType) {
            $translated = $this->language->translate($field, 'fields', $entityType);
            if ($translated && $translated !== $field) {
                return $translated;
            }
        }

        $global = $this->language->translate($field, 'fields', 'Global');
        if ($global && $global !== $field) {
            return $global;
        }

        // CamelCase to Human Words (e.g. cChangeReason -> Change Reason)
        $clean = preg_replace('/^c([A-Z])/', '$1', $field);
        $spaced = preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', $clean);
        return ucwords($spaced);
    }

    private function formatValue(mixed $val): string
    {
        if ($val === null) {
            return 'None';
        }
        if (is_bool($val)) {
            return $val ? 'true' : 'false';
        }
        if (is_array($val) || is_object($val)) {
            return json_encode($val);
        }
        $str = (string) $val;
        return $str === '' ? 'Empty' : $str;
    }

    private function parseArrayParam(mixed $raw): array
    {
        if (!$raw) {
            return [];
        }
        if (is_array($raw)) {
            return array_values(array_filter(array_map('trim', $raw)));
        }
        $parts = explode(',', (string) $raw);
        return array_values(array_filter(array_map('trim', $parts)));
    }
}
