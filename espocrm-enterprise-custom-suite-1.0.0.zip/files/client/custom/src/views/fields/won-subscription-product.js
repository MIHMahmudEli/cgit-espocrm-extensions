define('custom:views/fields/won-subscription-product', ['views/fields/link'], function (Dep) {
    return Dep.extend({
        getSelectFilters: function () {
            return Object.assign({}, Dep.prototype.getSelectFilters.call(this) || {}, {
                active: { type: 'equals', attribute: 'status', value: 'Active' },
                subscription: { type: 'equals', attribute: 'type', value: 'Subscription' }
            });
        },
        setup: function () {
            Dep.prototype.setup.call(this);
            this.listenTo(this.model, 'change:cWonProductId', function (model, id, options) {
                if (!options || !options.fromProductService) {
                    this.model.set({
                        cProductServiceId: id || null,
                        cProductServiceName: id ? this.model.get('cWonProductName') : null
                    }, { fromWonProduct: true });
                }
                if (this.model.get('stage') !== 'Closed Won') return;
                this.model.set({
                    cWonPlanId: null,
                    cWonPlanName: null,
                    cWonPlanPrice: null,
                    cWonPeriod: null,
                    cWonInitialTotal: null
                }, { ui: true, fromField: 'cWonProduct' });
                if (id) this.choosePlan(id);
            });
        },
        choosePlan: async function (productId) {
            if (!productId || !/^[a-z0-9]{17}$/i.test(productId)) return;
            try {
                var res = await Espo.Ajax.getRequest('CSubscriptionPlan', {
                    where: [
                        { type: 'equals', attribute: 'productId', value: productId },
                        { type: 'equals', attribute: 'status', value: 'Active' }
                    ],
                    maxSize: 20
                }, { returnError: true });
                if (!res) return;
                var list = res.list || [];
                var total = (typeof res.total === 'number') ? res.total : list.length;

                if (total === 1 && list.length === 1) {
                    var singlePlan = list[0];
                    var values = {
                        cWonPlanId: singlePlan.id,
                        cWonPlanName: singlePlan.name
                    };
                    if (singlePlan.monthlyPrice != null) {
                        values.cWonPlanPrice = singlePlan.monthlyPrice;
                        values.cWonPlanPriceCurrency = singlePlan.monthlyPriceCurrency;
                    }
                    if (singlePlan.billingPeriod) {
                        values.cWonPeriod = singlePlan.billingPeriod;
                    }
                    this.model.set(values, { ui: true, fromField: 'cWonProduct' });

                    var parentView = typeof this.getParentView === 'function' ? this.getParentView() : null;
                    if (parentView && typeof parentView.syncWonPlanFieldUI === 'function') {
                        parentView.syncWonPlanFieldUI(singlePlan.id, singlePlan.name);
                    } else {
                        var planFieldView = parentView && typeof parentView.getFieldView === 'function' ? parentView.getFieldView('cWonPlan') : null;
                        if (planFieldView) {
                            if (planFieldView.$elementName) planFieldView.$elementName.val(singlePlan.name);
                            if (planFieldView.$elementId) planFieldView.$elementId.val(singlePlan.id);
                            if (typeof planFieldView.loadPlan === 'function') planFieldView.loadPlan();
                            else if (typeof planFieldView.reRender === 'function') planFieldView.reRender();
                        }
                    }
                    return;
                }
                if (total === 0 || list.length === 0) {
                    return;
                }

                if (this.hasView('wonPlanPicker') || this.isOpeningPlanPicker) {
                    return;
                }
                this.isOpeningPlanPicker = true;

                var onPlanSelected = (record) => {
                    this.isOpeningPlanPicker = false;
                    if (Array.isArray(record)) record = record[0];
                    if (!record) return;
                    if (this.model.get('cWonProductId') !== productId) return;

                    var planId = record.id || (typeof record.get === 'function' ? record.get('id') : null);
                    var planName = (typeof record.get === 'function' ? record.get('name') : record.name) || '';
                    var planPrice = typeof record.get === 'function' ? record.get('monthlyPrice') : record.monthlyPrice;
                    var planCurrency = typeof record.get === 'function' ? record.get('monthlyPriceCurrency') : record.monthlyPriceCurrency;
                    var planPeriod = typeof record.get === 'function' ? record.get('billingPeriod') : record.billingPeriod;

                    var values = {
                        cWonPlanId: planId,
                        cWonPlanName: planName
                    };
                    if (planPrice != null) {
                        values.cWonPlanPrice = planPrice;
                        values.cWonPlanPriceCurrency = planCurrency;
                    }
                    if (planPeriod) {
                        values.cWonPeriod = planPeriod;
                    }
                    this.model.set(values, { ui: true, fromField: 'cWonProduct' });

                    var parentView = typeof this.getParentView === 'function' ? this.getParentView() : null;
                    if (parentView && typeof parentView.syncWonPlanFieldUI === 'function') {
                        parentView.syncWonPlanFieldUI(planId, planName);
                    } else {
                        var planFieldView = parentView && typeof parentView.getFieldView === 'function' ? parentView.getFieldView('cWonPlan') : null;
                        if (planFieldView) {
                            if (planFieldView.$elementName) planFieldView.$elementName.val(planName);
                            if (planFieldView.$elementId) planFieldView.$elementId.val(planId);
                            if (typeof planFieldView.loadPlan === 'function') {
                                planFieldView.loadPlan();
                            } else if (typeof planFieldView.reRender === 'function') {
                                planFieldView.reRender();
                            }
                        }
                    }
                };

                const modal = await this.createView('wonPlanPicker', 'views/modals/select-records', {
                    scope: 'CSubscriptionPlan',
                    multiple: false,
                    createButton: false,
                    filters: {
                        product: { type: 'equals', attribute: 'productId', value: productId },
                        active: { type: 'equals', attribute: 'status', value: 'Active' }
                    },
                    onSelect: onPlanSelected
                });
                this.listenToOnce(modal, 'select', onPlanSelected);
                this.listenToOnce(modal, 'close remove', () => {
                    this.isOpeningPlanPicker = false;
                });
                modal.render();
            } catch (e) {
                this.isOpeningPlanPicker = false;
                Espo.Ui.error('Could not open plans for this product. Select the Subscription Plan field to try again.');
            }
        }
    });
});
