define('custom:views/c-client-subscription/record/edit', ['views/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    var TARGET_PLACEHOLDER_FIELDS = [
        'name',
        'description',
        'verificationEvidence'
    ];

    return Dep.extend({

        getAuthorizedUser: function () {
            if (typeof this.getUser === 'function' && this.getUser()) {
                return this.getUser();
            }
            if (this._helper && this._helper.user) {
                return this._helper.user;
            }
            if (typeof this.getHelper === 'function' && this.getHelper() && this.getHelper().user) {
                return this.getHelper().user;
            }
            if (typeof Espo !== 'undefined' && Espo.user) {
                return Espo.user;
            }
            return null;
        },

        setup: function () {
            if (this.model.isNew() && !this.model.get('assignedUserId')) {
                var user = this.getAuthorizedUser();
                if (user && user.id && user.id !== 'system') {
                    var userName = typeof user.get === 'function' ? user.get('name') : (user.name || '');
                    this.model.set({
                        assignedUserId: user.id,
                        assignedUserName: userName
                    });
                }
            }

            Dep.prototype.setup.call(this);

            this.listenTo(this.model, 'change:clientId change:clientType', function (model, val, options) {
                if (options && (options.fromSelf || options.silent)) return;
                this.handleClientChange();
            });

            this.listenTo(this.model, 'change:productId change:productName change:planId change:planName change:clientName change:billingPeriod', function (model, val, options) {
                this.updateNameAndPlaceholder();
            });
        },

        syncAssignedUserField: function () {
            if (this.model.isNew() && !this.model.get('assignedUserId')) {
                var user = this.getAuthorizedUser();
                if (user && user.id && user.id !== 'system') {
                    var userName = typeof user.get === 'function' ? user.get('name') : (user.name || '');
                    this.model.set({
                        assignedUserId: user.id,
                        assignedUserName: userName
                    });
                }
            }

            var userId = this.model.get('assignedUserId');
            var userName = this.model.get('assignedUserName');
            if (userId) {
                var assignedView = this.getFieldView('assignedUser');
                if (assignedView) {
                    if (typeof assignedView.setValue === 'function') {
                        assignedView.setValue(userId, userName);
                    } else if (typeof assignedView.render === 'function' && !assignedView.isRendered()) {
                        assignedView.render();
                    }
                }
            }
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            this.updateAllPlaceholders();
            this.hookFieldViewRenderListeners();
            this.syncAssignedUserField();

            if (this.model.isNew() && this.model.get('clientId') && !this.model.get('productId') && !this.model.get('planId')) {
                this.handleClientChange();
            }
        },

        generateSubscriptionName: function () {
            var clientName = (this.model.get('clientName') || '').trim();
            var planName = (this.model.get('planName') || '').trim();
            var productName = (this.model.get('productName') || '').trim();

            if (clientName && planName) {
                if (productName && planName.toLowerCase().indexOf(productName.toLowerCase()) === -1) {
                    return clientName + ' - ' + productName + ' (' + planName + ')';
                }
                return clientName + ' - ' + planName;
            }

            if (clientName && productName) {
                return clientName + ' - ' + productName + ' Subscription';
            }

            if (clientName) {
                return clientName + ' - Subscription';
            }

            if (productName && planName) {
                if (planName.toLowerCase().indexOf(productName.toLowerCase()) === -1) {
                    return productName + ' - ' + planName;
                }
                return planName;
            }

            if (planName) {
                return planName;
            }

            return '';
        },

        getNamePlaceholder: function () {
            var clientName = (this.model.get('clientName') || '').trim();
            var productName = (this.model.get('productName') || '').trim();

            if (clientName && productName) {
                return 'e.g. ' + clientName + ' - ' + productName + ' (Plan Name)...';
            }
            if (clientName) {
                return 'e.g. ' + clientName + ' - Product (Plan Name)...';
            }
            return 'e.g. Acme Corporation - CloudApp (Pro Plan)...';
        },

        getFieldPlaceholders: function () {
            return {
                name: this.getNamePlaceholder(),
                description: 'e.g. Subscription terms agreed upon onboarding, custom SLA provisions, monthly invoice delivery instructions, or contract references...',
                verificationEvidence: 'e.g. Signed contract link (DocuSign/Dropbox Sign), payment gateway transaction ID, bank wire confirmation slip, or client email approval...'
            };
        },

        applyFieldPlaceholder: function (fieldName, placeholder) {
            if (!placeholder) {
                var placeholders = this.getFieldPlaceholders();
                placeholder = placeholders[fieldName];
            }
            if (!placeholder) return;

            // 1. Direct DOM search by data-name or cell/field container
            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="' + fieldName + '"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('input, textarea');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="' + fieldName + '"], .field[data-name="' + fieldName + '"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('input, textarea');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            // 2. Field view update
            var fieldView = this.getFieldView(fieldName);
            if (fieldView) {
                fieldView.placeholder = placeholder;
                if (fieldView.params) {
                    fieldView.params.placeholder = placeholder;
                }
                if (fieldView.$element) {
                    if (typeof fieldView.$element.attr === 'function') {
                        fieldView.$element.attr('placeholder', placeholder);
                    } else if (fieldView.$element[0] && typeof fieldView.$element[0].setAttribute === 'function') {
                        fieldView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (fieldView.$el && typeof fieldView.$el.find === 'function') {
                    var $inputs = fieldView.$el.find('input, textarea');
                    if ($inputs.length) {
                        if (typeof $inputs.attr === 'function') {
                            $inputs.attr('placeholder', placeholder);
                        } else if ($inputs[0] && typeof $inputs[0].setAttribute === 'function') {
                            $inputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        },

        updateAllPlaceholders: function () {
            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                this.applyFieldPlaceholder(fieldName);
            }, this);
        },

        hookFieldViewRenderListeners: function () {
            this._hookedFieldViews = this._hookedFieldViews || {};

            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                if (this._hookedFieldViews[fieldName]) return;
                var fieldView = this.getFieldView(fieldName);
                if (fieldView) {
                    this._hookedFieldViews[fieldName] = true;
                    this.listenTo(fieldView, 'after:render', function () {
                        this.applyFieldPlaceholder(fieldName);
                    }.bind(this));
                }
            }, this);
        },

        updateNameAndPlaceholder: function () {
            this.applyFieldPlaceholder('name', this.getNamePlaceholder());

            if (this.model.isNew()) {
                var currentName = (this.model.get('name') || '').trim();
                if (!currentName || currentName === this._lastGeneratedName) {
                    var newName = this.generateSubscriptionName();
                    if (newName) {
                        this._lastGeneratedName = newName;
                        this.model.set('name', newName, { fromSelf: true });
                    }
                }
            }
        },

        handleClientChange: async function () {
            var clientId = this.model.get('clientId');
            var clientType = this.model.get('clientType');

            if (!clientId || !clientType) return;

            var client = null;
            try {
                if (typeof Espo !== 'undefined' && Espo.Ajax && typeof Espo.Ajax.getRequest === 'function') {
                    client = await Espo.Ajax.getRequest(clientType + '/' + encodeURIComponent(clientId));
                }
            } catch (e) {
                return;
            }

            if (!client) return;

            if (clientType === 'Opportunity') {
                var realType = client.accountId ? 'Account' : (client.contactId ? 'Contact' : null);
                var realId = realType === 'Account' ? client.accountId : client.contactId;
                var realName = realType === 'Account' ? client.accountName : client.contactName;

                var updates = {
                    cWonOpportunityId: client.id,
                    cWonOpportunityName: client.name
                };

                if (realType && realId) {
                    updates.clientType = realType;
                    updates.clientId = realId;
                    updates.clientName = realName;
                }

                if (client.cProductServiceId) {
                    updates.productId = client.cProductServiceId;
                    updates.productName = client.cProductServiceName;
                }

                this.model.set(updates, { fromSelf: true });
                this.updateNameAndPlaceholder();

                if (client.cProductServiceId) {
                    this.choosePlanForProduct(client.cProductServiceId);
                }
                return;
            }

            var prodIds = client.cProductServicesIds || [];
            var prodNames = client.cProductServicesNames || {};

            if (!prodIds.length && clientType === 'Contact' && client.accountId) {
                try {
                    if (typeof Espo !== 'undefined' && Espo.Ajax && typeof Espo.Ajax.getRequest === 'function') {
                        var acc = await Espo.Ajax.getRequest('Account/' + encodeURIComponent(client.accountId));
                        if (acc && acc.cProductServicesIds && acc.cProductServicesIds.length) {
                            prodIds = acc.cProductServicesIds;
                            prodNames = acc.cProductServicesNames || {};
                        }
                    }
                } catch (e) {}
            }

            if (prodIds.length === 1) {
                var prodId = prodIds[0];
                var prodName = prodNames[prodId] || '';

                if (!prodName && typeof Espo !== 'undefined' && Espo.Ajax && typeof Espo.Ajax.getRequest === 'function') {
                    try {
                        var p = await Espo.Ajax.getRequest('CProductService/' + encodeURIComponent(prodId));
                        if (p && p.name) prodName = p.name;
                    } catch (e) {}
                }

                this.model.set({
                    productId: prodId,
                    productName: prodName,
                    planId: null,
                    planName: null
                }, { fromSelf: true });

                this.updateNameAndPlaceholder();
                this.choosePlanForProduct(prodId);
            } else if (prodIds.length > 1) {
                this.chooseProductFromList(prodIds, prodNames);
            } else {
                this.updateNameAndPlaceholder();
            }
        },

        chooseProductFromList: async function (prodIds, prodNames) {
            try {
                var modal = await this.createView('productPickerModal', 'views/modals/select-records', {
                    scope: 'CProductService',
                    multiple: false,
                    createButton: false,
                    filters: {
                        id: { type: 'in', value: prodIds },
                        status: { type: 'equals', attribute: 'status', value: 'Active' }
                    }
                });

                this.listenToOnce(modal, 'select', function (record) {
                    var prodId = record.id;
                    var prodName = (typeof record.get === 'function' ? record.get('name') : null) || (record.attributes && record.attributes.name) || '';

                    this.model.set({
                        productId: prodId,
                        productName: prodName,
                        planId: null,
                        planName: null
                    }, { fromSelf: true });

                    this.updateNameAndPlaceholder();
                    this.choosePlanForProduct(prodId);
                }.bind(this));

                modal.render();
            } catch (e) {
                console.error(e);
            }
        },

        choosePlanForProduct: async function (productId) {
            if (!productId) return;
            try {
                var modal = await this.createView('planPickerModal', 'views/modals/select-records', {
                    scope: 'CSubscriptionPlan',
                    multiple: false,
                    createButton: false,
                    filters: {
                        product: { type: 'equals', attribute: 'productId', value: productId },
                        active: { type: 'equals', attribute: 'status', value: 'Active' }
                    }
                });

                this.listenToOnce(modal, 'select', function (record) {
                    var planName = (typeof record.get === 'function' ? record.get('name') : null) || (record.attributes && record.attributes.name) || '';
                    var period = (typeof record.get === 'function' ? record.get('billingPeriod') : null) || (record.attributes && record.attributes.billingPeriod) || 'Monthly';
                    var price = typeof record.get === 'function' && record.get('monthlyPrice') !== undefined ? record.get('monthlyPrice') : (record.attributes && record.attributes.monthlyPrice);
                    var currency = (typeof record.get === 'function' ? record.get('monthlyPriceCurrency') : null) || (record.attributes && record.attributes.monthlyPriceCurrency);

                    this.model.set({
                        planId: record.id,
                        planName: planName,
                        billingPeriod: period,
                        monthlyPrice: price,
                        monthlyPriceCurrency: currency
                    }, { ui: true });

                    var planFieldView = (typeof this.getFieldView === 'function') ? this.getFieldView('plan') : null;
                    if (planFieldView) {
                        if (planFieldView.$elementName) planFieldView.$elementName.val(planName);
                        if (planFieldView.$elementId) planFieldView.$elementId.val(record.id);
                        if (typeof planFieldView.trigger === 'function') planFieldView.trigger('change');
                        if (typeof planFieldView.reRender === 'function') planFieldView.reRender();
                    }
                    if (this.$el && typeof this.$el.find === 'function') {
                        this.$el.find('input[data-name="planName"]').val(planName);
                        this.$el.find('input[data-name="planId"]').val(record.id);
                        this.$el.find('.field[data-name="plan"] input.main-element').val(planName);
                    }

                    this.updateNameAndPlaceholder();
                }.bind(this));

                modal.render();
            } catch (e) {
                console.error('Could not open plan picker modal', e);
            }
        }

    });

});
