define('custom:views/opportunity/record/kanban', [
    'crm:views/opportunity/record/kanban',
    'helpers/record-modal'
], function (Dep, RecordModal) {

    const RecordModalClass = (RecordModal && RecordModal.default) ? RecordModal.default : RecordModal;

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            this.groupChangeSaveHandler = this.handleGroupChangeSave.bind(this);
        },

        handleGroupChangeSave: function (model) {
            const statusField = this.statusField || 'stage';
            const targetStage = model.get(statusField);

            if (targetStage !== 'Closed Won') {
                return model.save(null, { patch: true, isDrop: true });
            }

            const previousStage = (typeof model.previous === 'function' ? model.previous(statusField) : null) || 'Prospecting';
            const prevAttributes = (typeof model.getClonedAttributes === 'function')
                ? model.getClonedAttributes()
                : (model.attributes ? Object.assign({}, model.attributes) : null);

            return new Promise((resolve, reject) => {
                let isSaved = false;

                const modal = new RecordModalClass();

                modal.showEdit(this, {
                    entityType: this.scope || 'Opportunity',
                    id: model.id,
                    model: model,
                    layoutName: 'detailSmall',
                    fullFormDisabled: false,
                    beforeRender: (modalView) => {
                        const setWonStage = () => {
                            if (!modalView.model) return;

                            modalView.model.set({
                                stage: 'Closed Won',
                                probability: 100
                            });

                            const hasSubScope = Boolean(
                                this.getMetadata() &&
                                typeof this.getMetadata().hasScope === 'function' &&
                                this.getMetadata().hasScope('CSubscriptionPlan')
                            );

                            if (hasSubScope) {
                                const prodId = modalView.model.get('cProductServiceId') || modalView.model.get('cWonProductId');
                                if (prodId && !modalView.model.get('cWonProductId')) {
                                    modalView.model.set({
                                        cWonProductId: prodId,
                                        cWonProductName: modalView.model.get('cProductServiceName')
                                    });
                                }

                                const currentSub = (modalView.model.get('cSubdomain') || '').trim();
                                if (!currentSub || currentSub.startsWith('.')) {
                                    let clientSlug = (modalView.model.get('accountName') || modalView.model.get('leadName') || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'client';
                                    let prodName = (modalView.model.get('cProductServiceName') || modalView.model.get('cWonProductName') || '').trim();
                                    let prodSlug = prodName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'service';
                                    let genSub = clientSlug + '.' + prodSlug + '.com';
                                    modalView.model.set('cSubdomain', genSub);
                                }
                            }
                        };

                        setWonStage();

                        if (modalView.model) {
                            modalView.listenTo(modalView.model, 'sync', setWonStage);
                        }

                        modalView.once('after:render', () => {
                            setWonStage();
                            const editView = modalView.getView('edit') || (typeof modalView.getRecordView === 'function' ? modalView.getRecordView() : null);
                            if (editView && editView.model) {
                                setWonStage();
                                if (typeof editView.manageWonSubscriptionPanels === 'function') {
                                    editView.manageWonSubscriptionPanels();
                                }
                                if (typeof editView.setupDiscountLiveCalculation === 'function') {
                                    editView.setupDiscountLiveCalculation();
                                }
                                const prodId = editView.model.get('cProductServiceId') || editView.model.get('cWonProductId');
                                if (prodId && typeof editView.ensureProductData === 'function') {
                                    editView.ensureProductData(prodId).then(() => {
                                        if (typeof editView.updateSubdomainValue === 'function') {
                                            editView.updateSubdomainValue(true);
                                        }
                                        if (prodId && !editView.model.get('cWonPlanId') && typeof editView.checkAndPromptPlans === 'function') {
                                            editView.checkAndPromptPlans(prodId);
                                        }
                                    });
                                } else {
                                    if (typeof editView.updateSubdomainValue === 'function') {
                                        editView.updateSubdomainValue(true);
                                    }
                                    if (prodId && !editView.model.get('cWonPlanId') && typeof editView.checkAndPromptPlans === 'function') {
                                        editView.checkAndPromptPlans(prodId);
                                    }
                                }
                            }
                        });

                        modalView.once('close remove', () => {
                            if (!isSaved) {
                                if (prevAttributes) {
                                    model.set(prevAttributes);
                                } else {
                                    model.set(statusField, previousStage);
                                }
                                reject(new Error('Closed Won modal canceled'));
                            }
                        });
                    },
                    afterSave: (savedModel) => {
                        isSaved = true;
                        if (savedModel && typeof savedModel.getClonedAttributes === 'function') {
                            model.set(savedModel.getClonedAttributes(), { sync: true });
                        } else if (savedModel && savedModel.attributes) {
                            model.set(savedModel.attributes, { sync: true });
                        }
                        resolve();
                    }
                }).catch(err => {
                    if (!isSaved) {
                        if (prevAttributes) {
                            model.set(prevAttributes);
                        } else {
                            model.set(statusField, previousStage);
                        }
                        reject(err);
                    }
                });
            });
        }
    });
});
