define('custom:views/fields/lead-source', ['views/fields/enum', 'views/modal'], function (Dep, ModalView) {

    Dep = Dep && Dep.default ? Dep.default : Dep;
    ModalView = ModalView && ModalView.default ? ModalView.default : ModalView;

    var AddSourceModal = ModalView.extend({
        headerText: 'Add Lead Source',
        templateContent: '<div class="form-group">' +
            '<label class="control-label">New Source Name</label>' +
            '<input type="text" class="form-control" data-name="newSourceName" placeholder="e.g. LinkedIn, Referral..." maxlength="100">' +
            '</div>',
        buttonList: [
            { name: 'save', label: 'Save', style: 'primary' },
            { name: 'cancel', label: 'Cancel' }
        ],
        afterRender: function () {
            ModalView.prototype.afterRender.call(this);
            var $input = this.$el.find('[data-name="newSourceName"]');
            setTimeout(function () { $input.focus(); }, 50);
            $input.on('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.actionSave();
                }
            }.bind(this));
        },
        actionSave: function () {
            var val = (this.$el.find('[data-name="newSourceName"]').val() || '').trim();
            if (!val) {
                Espo.Ui.warning('Please enter a source name.');
                return;
            }
            this.trigger('add-source', val);
            this.close();
        }
    });

    return Dep.extend({

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            if (!this.isEditMode() || !this.getUser().isAdmin()) {
                return;
            }

            var $select = this.$el.find('select').first();
            if (!$select.length) {
                return;
            }

            if (this.$el.find('.lead-source-add-btn').length) {
                return;
            }

            var $btnWrap = $('<div class="lead-source-add-wrap" style="margin-top: 5px;"></div>');
            var $btn = $('<button type="button" class="btn btn-default btn-xs lead-source-add-btn" title="Add Source">' +
                '<span class="fas fa-plus"></span>' +
                '</button>');

            $btn.on('click', function () {
                this.openAddSourceModal();
            }.bind(this));

            $btnWrap.append($btn);
            this.$el.append($btnWrap);
        },

        openAddSourceModal: function () {
            var modal = new AddSourceModal({});
            this.assignView('addSourceDialog', modal);
            modal.render();

            this.listenToOnce(modal, 'add-source', function (newSource) {
                this.saveNewSourceOption(newSource);
            }.bind(this));
        },

        addOptionToField: function (scope, fieldName, newSource) {
            return Espo.Ajax.getRequest('Admin/fieldManager/' + scope + '/' + fieldName).then(function (fieldData) {
                var options = Array.isArray(fieldData.options) ? fieldData.options.slice() : [];
                var existing = options.find(function (opt) {
                    return String(opt).toLowerCase() === newSource.toLowerCase();
                });

                if (existing !== undefined) {
                    return { existing: existing, options: options, translatedOptions: fieldData.translatedOptions || {} };
                }

                var othersIdx = options.indexOf('Others');
                if (othersIdx !== -1) {
                    options.splice(othersIdx, 0, newSource);
                } else {
                    options.push(newSource);
                }

                var translatedOptions = Object.assign({}, fieldData.translatedOptions || {});
                translatedOptions[newSource] = newSource;

                fieldData.options = options;
                fieldData.translatedOptions = translatedOptions;

                return Espo.Ajax.putRequest('Admin/fieldManager/' + scope + '/' + fieldName, fieldData).then(function () {
                    var meta = this.getMetadata();
                    if (meta && meta.data && meta.data.entityDefs && meta.data.entityDefs[scope] &&
                        meta.data.entityDefs[scope].fields && meta.data.entityDefs[scope].fields[fieldName]) {
                        meta.data.entityDefs[scope].fields[fieldName].options = options;
                    }
                    return { existing: null, options: options, translatedOptions: translatedOptions };
                }.bind(this));
            }.bind(this));
        },

        saveNewSourceOption: function (newSource) {
            Espo.Ui.notify('Saving...');

            this.addOptionToField('Lead', 'source', newSource).then(function (result) {
                if (result.existing !== null) {
                    Espo.Ui.warning('Source "' + newSource + '" already exists.');
                    this.model.set(this.name, result.existing);
                    this.reRender();
                    return;
                }

                // Sync new source option to Account.cLeadSource and Contact.cLeadSource if present
                var syncPromises = [];
                if (this.getMetadata().get(['entityDefs', 'Account', 'fields', 'cLeadSource'])) {
                    syncPromises.push(this.addOptionToField('Account', 'cLeadSource', newSource).catch(function () {}));
                }
                if (this.getMetadata().get(['entityDefs', 'Contact', 'fields', 'cLeadSource'])) {
                    syncPromises.push(this.addOptionToField('Contact', 'cLeadSource', newSource).catch(function () {}));
                }

                Promise.all(syncPromises).then(function () {
                    this.params.options = result.options;
                    this.translatedOptions = Object.assign({}, this.translatedOptions || {}, result.translatedOptions);
                    this.model.set(this.name, newSource);
                    this.reRender();
                    Espo.Ui.success('Added source "' + newSource + '".');
                }.bind(this));
            }.bind(this));
        }

    });

});
