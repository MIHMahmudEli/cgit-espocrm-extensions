define('custom:views/opportunity/record/panels/activities', ['custom:views/record/panels/activities'], function (Dep) {

    return Dep.extend({

        setup: function () {
            this.listLayout = {
                'Email': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true }
                    ], [
                        { name: 'dateSent', soft: true },
                        { name: 'from' },
                        { name: 'hasAttachment', view: 'views/email/fields/has-attachment' }
                    ]]
                },
                'Call': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'description' }
                    ]]
                },
                'Meeting': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'description' }
                    ]]
                }
            };

            Dep.prototype.setup.call(this);
        },

        getComposeEmailAttributes: function (scope, data, callback) {
            data = data || {};

            Espo.Ui.notifyWait();

            Dep.prototype.getComposeEmailAttributes.call(this, scope, data, (attributes) => {
                attributes = attributes || {};
                Espo.Ajax.getRequest('Opportunity/action/emailAddressList?id=' + this.model.id).then(list => {
                    attributes.to = '';
                    attributes.cc = '';
                    attributes.nameHash = {};

                    if (Array.isArray(list)) {
                        list.forEach((item) => {
                            if (item && item.emailAddress) {
                                attributes.to += item.emailAddress + ';';
                                if (item.name) {
                                    attributes.nameHash[item.emailAddress] = item.name;
                                }
                            }
                        });
                    }

                    Espo.Ui.notify(false);

                    callback(attributes);
                }).catch(() => {
                    Espo.Ui.notify(false);
                    callback(attributes);
                });
            });
        }

    });

});
