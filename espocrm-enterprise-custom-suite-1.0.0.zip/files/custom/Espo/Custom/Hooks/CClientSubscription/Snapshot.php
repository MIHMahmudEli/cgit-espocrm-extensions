<?php
namespace Espo\Custom\Hooks\CClientSubscription;
use Espo\Core\Exceptions\BadRequest;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\SaveOptions;
use Espo\ORM\Repository\Option\RemoveOptions;
class Snapshot implements \Espo\Core\Hook\Hook\BeforeSave, \Espo\Core\Hook\Hook\BeforeRemove, \Espo\Core\Di\EntityManagerAware
{
    public static int $order = 5;
    private ?EntityManager $entityManager = null;
    public function setEntityManager(EntityManager $entityManager): void { $this->entityManager = $entityManager; }

    public function beforeRemove(Entity $entity, RemoveOptions $options): void
    {
        $entity->set('clientProductKey', null);
        try {
            $this->entityManager->getPDO()->prepare("UPDATE c_client_subscription SET client_product_key = NULL WHERE id = ?")->execute([$entity->getId()]);
        } catch (\Throwable) {}
    }
    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        if ($entity->get('status') === 'Active' && (!$entity->get('effectiveDate') || trim((string) $entity->get('verificationEvidence')) === '')) {
            throw new BadRequest('An active subscription requires an effective date and verification evidence.');
        }
        $type = $entity->get('clientType'); $id = $entity->get('clientId');
        if ($type === 'Opportunity' && $id) {
            $opp = $this->entityManager->getEntityById('Opportunity', $id);
            if ($opp) {
                $type = $opp->get('accountId') ? 'Account' : ($opp->get('contactId') ? 'Contact' : null);
                $id = $type ? $opp->get($type === 'Account' ? 'accountId' : 'contactId') : null;
                if ($type && $id) {
                    $entity->set('clientType', $type);
                    $entity->set('clientId', $id);
                    $entity->set('cWonOpportunityId', $opp->getId());
                }
            }
        }
        if (!in_array($type, ['Lead', 'Account', 'Contact'], true) || !$id || !$this->entityManager->getEntityById($type, $id)) {
            throw new BadRequest('Select an existing Lead, Account, or Contact.');
        }
        if (!$entity->isNew() && ($entity->isAttributeChanged('clientId') || $entity->isAttributeChanged('clientType'))) {
            throw new BadRequest('The client cannot change on an existing subscription.');
        }
        $reason=$entity->get('changeReason');
        if($entity->isNew()) {
            if($reason!==null&&$reason!==''&&$reason!=='Initial')throw new BadRequest('New subscriptions must use Initial.');
            $entity->set('changeReason','Initial');
        } elseif($entity->isAttributeChanged('changeReason')&&!in_array($reason,['Upgrade','Downgrade'],true)) {
            throw new BadRequest('Choose Upgrade or Downgrade. Initial is only for new subscriptions.');
        }
        $plan = $entity->get('planId') ? $this->entityManager->getEntityById('CSubscriptionPlan', $entity->get('planId')) : null;
        if (!$plan) { throw new BadRequest('Select an existing subscription plan.'); }
        $changing = $entity->isNew() || $entity->isAttributeChanged('planId');
        if ($changing) {
            if ($plan->get('status') !== 'Active') { throw new BadRequest('Select an active plan.'); }
            if (!$entity->isNew() && $entity->getFetched('productId') !== $plan->get('productId')) {
                throw new BadRequest('Plan changes must stay within the same product.');
            }
            if (!$entity->isNew() && !$entity->get('effectiveDate')) {
                throw new BadRequest('Specify the effective date of this plan change.');
            }
            if (!$entity->isNew() && !in_array($entity->get('changeReason'), ['Upgrade', 'Downgrade'], true)) {
                throw new BadRequest('Choose Upgrade or Downgrade for a plan change.');
            }
            if (!$entity->isNew() && $entity->getFetched('effectiveDate') && $entity->get('effectiveDate') < $entity->getFetched('effectiveDate')) {
                throw new BadRequest('A plan change cannot precede the previous effective date.');
            }
            $entity->set('productId', $plan->get('productId'));
            $entity->set('monthlyPrice', $plan->get('monthlyPrice'));
            $entity->set('monthlyPriceCurrency', $plan->get('monthlyPriceCurrency'));
            $period=$plan->get('billingPeriod')??'Monthly';
            if(!in_array($period,['Monthly','Quarterly','Semiannual','Annual'],true))throw new BadRequest('The selected plan has an invalid billing period.');
            $entity->set('billingPeriod',$period);
        } else {
            // Preserve the agreed amount even if the catalog plan price was edited.
            foreach (['productId', 'monthlyPrice', 'monthlyPriceCurrency', 'billingPeriod'] as $field) {
                $entity->set($field, $entity->getFetched($field));
            }
        }
        $saleId=$entity->get('cWonOpportunityId');
        if($saleId){
            $sale=$this->entityManager->getEntityById('Opportunity',$saleId);
            $sourceChanged=$entity->isNew()||$entity->isAttributeChanged('cWonOpportunityId');
            if($sourceChanged||($changing&&$sale&&$sale->get('cWonPlanId')===$entity->get('planId'))){
                if(!$sale||$sale->get('stage')!=='Closed Won'||$sale->get('cWonPlanId')!==$entity->get('planId')||$sale->get('cWonProductId')!==$plan->get('productId'))throw new BadRequest('The subscription must match the Closed Won opportunity plan and product.');
                $match = false;
                if ($type === 'Contact' && ($id === $sale->get('contactId') || in_array($id, $sale->getLinkMultipleIdList('contacts') ?? [], true))) {
                    $match = true;
                } elseif ($type === 'Account' && $id === $sale->get('accountId')) {
                    $match = true;
                }
                if (!$match) throw new BadRequest('The subscription client must match its sales opportunity.');
                if($sale->get('cWonPlanPrice')===null||!$sale->get('cWonPlanPriceCurrency'))throw new BadRequest('The sales opportunity has no verified price snapshot.');
                $agreedPrice = round((float)$sale->get('cWonPlanPrice') - (float)($sale->get('cWonDiscountTotal') ?? 0), 2);
                $entity->set('monthlyPrice', $agreedPrice);
                $entity->set('monthlyPriceCurrency',$sale->get('cWonPlanPriceCurrency'));
                $entity->set('billingPeriod',$sale->get('cWonPeriod'));
            }
        }
        $key = hash('sha256', $type . ':' . $id . ':' . $plan->get('productId'));
        try {
            $this->entityManager->getPDO()->prepare("UPDATE c_client_subscription SET client_product_key = NULL WHERE deleted = 1 AND client_product_key = ?")->execute([$key]);
        } catch (\Throwable) {}
        $existing = $this->entityManager->getRDBRepository('CClientSubscription')->where(['clientProductKey' => $key])->findOne();
        if ($existing && $existing->getId() !== $entity->getId()) {
            throw new BadRequest('This client already has a subscription for this product. Change its plan instead.');
        }
        $entity->set('clientProductKey', $key);
    }
}
