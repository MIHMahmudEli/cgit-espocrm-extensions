<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM — Open Source CRM application.
 * Copyright (C) 2014-2026 EspoCRM, Inc.
 * Website: https://www.espocrm.com
 ************************************************************************/

namespace Espo\Custom\Hooks\Notification;

use Espo\Core\Hook\Hook\AfterSave;
use Espo\Custom\WebPush\NotificationDispatcher;
use Espo\Entities\Notification;
use Espo\ORM\Entity;
use Espo\ORM\Repository\Option\SaveOptions;

/**
 * Mirrors Core WebSocketSubmit on Notification: dispatches a Web Push
 * whenever any new persistent Notification is created across EspoCRM.
 *
 * @implements AfterSave<Notification>
 */
class WebPushSubmit implements AfterSave
{
    public static int $order = 25;

    public function __construct(
        private NotificationDispatcher $dispatcher,
    ) {}

    public function afterSave(Entity $entity, SaveOptions $options): void
    {
        if (!$entity instanceof Notification || !$entity->isNew()) {
            return;
        }

        if ($options->get('skipWebPush')) {
            $this->dispatcher->markDispatched($entity->getId());
            return;
        }

        $this->dispatcher->dispatchNotification($entity);
    }
}
