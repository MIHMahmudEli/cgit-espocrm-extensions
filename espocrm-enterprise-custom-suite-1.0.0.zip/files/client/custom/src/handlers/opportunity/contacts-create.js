define('custom:handlers/opportunity/contacts-create', ['handlers/create-related'], function (Dep) {

    var BaseClass = (Dep && Dep.default) || Dep || class {};

    return class extends BaseClass {

        constructor(viewHelper, options) {
            super(viewHelper);
            this.options = options || {};
        }

        async fetchLead(model) {
            try {
                if (!model) return null;
                var leadId = typeof model.get === 'function' ? model.get('originalLeadId') : model.originalLeadId;
                if (!leadId && model.id && typeof Espo !== 'undefined' && Espo.Ajax) {
                    var res = await Espo.Ajax.getRequest('Lead', {
                        where: [
                            {
                                type: 'equals',
                                attribute: 'createdOpportunityId',
                                value: model.id
                            }
                        ],
                        maxSize: 1
                    });
                    if (res && res.list && res.list.length > 0 && res.list[0].id) {
                        leadId = res.list[0].id;
                    }
                }
                if (leadId && typeof Espo !== 'undefined' && Espo.Ajax) {
                    return await Espo.Ajax.getRequest('Lead/' + encodeURIComponent(leadId));
                }
            } catch (e) {}
            return null;
        }

        async getAttributes(model, link) {
            try {
                var attributes = {};
                if (!model) return attributes;

                var lead = await this.fetchLead(model);

                // 1. Account attributes
                var accountId = typeof model.get === 'function' ? model.get('accountId') : model.accountId;
                var accountName = typeof model.get === 'function' ? model.get('accountName') : model.accountName;
                if (accountId) {
                    attributes.accountId = accountId;
                    attributes.accountsIds = [accountId];
                    if (accountName) {
                        attributes.accountName = accountName;
                        attributes.accountsNames = {};
                        attributes.accountsNames[accountId] = accountName;
                    }
                }

                // 2. Product Services
                var prodId = typeof model.get === 'function' ? (model.get('cProductServiceId') || model.get('cWonProductId')) : null;
                var prodName = typeof model.get === 'function' ? (model.get('cProductServiceName') || model.get('cWonProductName')) : null;
                if (prodId) {
                    attributes.cProductServicesIds = [prodId];
                    if (prodName) {
                        attributes.cProductServicesNames = {};
                        attributes.cProductServicesNames[prodId] = prodName;
                    }
                } else if (lead && Array.isArray(lead.cProductServicesIds) && lead.cProductServicesIds.length) {
                    attributes.cProductServicesIds = lead.cProductServicesIds.slice();
                    if (lead.cProductServicesNames && typeof lead.cProductServicesNames === 'object') {
                        attributes.cProductServicesNames = Object.assign({}, lead.cProductServicesNames);
                    }
                }

                // 3. Lead Source
                var leadSource = (typeof model.get === 'function' ? model.get('leadSource') : null) || (lead && lead.source);
                if (leadSource) {
                    attributes.cLeadSource = leadSource;
                }

                // 4. Assigned User
                var assignedUserId = (typeof model.get === 'function' ? model.get('assignedUserId') : null) || (lead && lead.assignedUserId);
                var assignedUserName = (typeof model.get === 'function' ? model.get('assignedUserName') : null) || (lead && lead.assignedUserName);
                if (assignedUserId) {
                    attributes.assignedUserId = assignedUserId;
                    if (assignedUserName) {
                        attributes.assignedUserName = assignedUserName;
                    }
                }

                // 5. Teams
                var teamsIds = (typeof model.get === 'function' ? model.get('teamsIds') : null) || (lead && lead.teamsIds);
                var teamsNames = (typeof model.get === 'function' ? model.get('teamsNames') : null) || (lead && lead.teamsNames);
                if (Array.isArray(teamsIds) && teamsIds.length) {
                    attributes.teamsIds = teamsIds.slice();
                    if (teamsNames && typeof teamsNames === 'object') {
                        attributes.teamsNames = Object.assign({}, teamsNames);
                    }
                }

                // 6. Description
                var description = (lead && lead.description) || (typeof model.get === 'function' ? model.get('description') : null);
                if (description) {
                    attributes.description = description;
                }

                // 7. Lead Contact Info
                if (lead) {
                    if (lead.firstName) attributes.firstName = lead.firstName;
                    if (lead.lastName) {
                        attributes.lastName = lead.lastName;
                    } else if (lead.name) {
                        attributes.lastName = lead.name;
                    }
                    if (lead.salutationName) attributes.salutationName = lead.salutationName;
                    if (lead.title) attributes.title = lead.title;

                    if (lead.emailAddress) {
                        attributes.emailAddress = lead.emailAddress;
                        if (lead.emailAddressData) {
                            attributes.emailAddressData = lead.emailAddressData;
                        }
                    }
                    if (lead.phoneNumber) {
                        attributes.phoneNumber = lead.phoneNumber;
                        if (lead.phoneNumberData) {
                            attributes.phoneNumberData = lead.phoneNumberData;
                        }
                    }
                    if (lead.addressStreet) attributes.addressStreet = lead.addressStreet;
                    if (lead.addressCity) attributes.addressCity = lead.addressCity;
                    if (lead.addressState) attributes.addressState = lead.addressState;
                    if (lead.addressCountry) attributes.addressCountry = lead.addressCountry;
                    if (lead.addressPostalCode) attributes.addressPostalCode = lead.addressPostalCode;

                    if (lead.website) attributes.cWebsite = lead.website;
                }

                return attributes;
            } catch (err) {
                return {};
            }
        }

    };

});
