define('custom:views/opportunity/record/detail', [
    'views/record/detail'
], function (Dep) {

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            this.productTypeCache = this.productTypeCache || {};
            this.productRootDomainCache = this.productRootDomainCache || {};

            this.listenTo(this.model, 'change:stage', async (model, stage, options) => {
                this.manageWonSubscriptionPanels();
                if (stage === 'Closed Won') {
                    var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                    if (prodId) {
                        if (!this.model.get('cWonProductId')) {
                            this.model.set({
                                cWonProductId: prodId,
                                cWonProductName: this.model.get('cProductServiceName')
                            }, { silent: true });
                        }
                        await this.ensureProductData(prodId);
                        this.updateSubdomainValue(true);
                        if (options && options.ui && !this.model.get('cWonPlanId')) {
                            this.checkAndPromptPlans(prodId);
                        }
                    } else {
                        this.updateSubdomainValue(true);
                    }
                }
            });

            this.listenTo(this.model, 'change:accountId change:accountName', (model, val, options) => {
                if (this.model.get('stage') === 'Closed Won') {
                    this.updateSubdomainValue(options && options.ui);
                }
            });

            this.listenTo(this.model, 'change:cProductServiceId change:cWonProductId', async (model, val, options) => {
                var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                if (prodId && /^[a-z0-9]{17}$/i.test(prodId)) {
                    await this.ensureProductData(prodId);
                }
                if (this.model.get('stage') === 'Closed Won') {
                    this.updateSubdomainValue(options && options.ui);
                    if (options && options.ui && prodId && !options.fromProductService && !this.model.get('cWonPlanId')) {
                        this.checkAndPromptPlans(prodId);
                    }
                }
            });

            var initProdId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            if (initProdId) {
                this.ensureProductData(initProdId);
            }
        },

        hasSubscriptionScope: function () {
            var meta = this.getMetadata();
            if (!meta) return false;
            if (typeof meta.hasScope === 'function' && meta.hasScope('CSubscriptionPlan')) {
                return true;
            }
            if (typeof meta.has === 'function' && meta.has(['scopes', 'CSubscriptionPlan'])) {
                return true;
            }
            if (typeof meta.get === 'function') {
                return Boolean(meta.get(['scopes', 'CSubscriptionPlan']));
            }
            return false;
        },

        ensureProductData: async function (productId) {
            if (!productId) {
                productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            }
            if (!productId || !/^[a-z0-9]{17}$/i.test(productId)) return null;
            this.productRootDomainCache = this.productRootDomainCache || {};
            this.productTypeCache = this.productTypeCache || {};
            if (this.productRootDomainCache[productId] !== undefined) {
                return {
                    rootDomain: this.productRootDomainCache[productId],
                    type: this.productTypeCache[productId]
                };
            }
            if (typeof Espo !== 'undefined' && Espo.Ajax) {
                try {
                    var prod = await Espo.Ajax.getRequest('CProductService/' + encodeURIComponent(productId), {
                        select: 'id,name,type,price,priceCurrency,cRootDomain'
                    }, { returnError: true });
                    if (prod) {
                        this.productTypeCache[productId] = prod.type || null;
                        this.productRootDomainCache[productId] = prod.cRootDomain || null;
                        this.model.set('cProductServiceType', prod.type || null, { silent: true });
                        this.model.set('cProductServiceRootDomain', prod.cRootDomain || null, { silent: true });
                        return {
                            rootDomain: prod.cRootDomain || null,
                            type: prod.type || null
                        };
                    }
                } catch (e) {
                    console.warn('ensureProductData error:', e);
                }
            }
            return null;
        },

        cleanRootDomain: function (domain) {
            if (!domain) return '';
            var clean = String(domain).trim().toLowerCase();
            clean = clean.replace(/^(?:https?:\/\/)/i, '').replace(/\/.*$/, '').replace(/^\.+|\.+$/g, '');
            return clean;
        },

        getProductRootDomain: function (productId) {
            if (!productId) {
                productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            }
            if (productId && this.productRootDomainCache && this.productRootDomainCache[productId]) {
                return this.cleanRootDomain(this.productRootDomainCache[productId]);
            }
            if (this.model.get('cProductServiceRootDomain')) {
                return this.cleanRootDomain(this.model.get('cProductServiceRootDomain'));
            }
            return '';
        },

        getProductDomain: function (productName) {
            if (!productName) return 'coachsys.com';
            var clean = productName.trim().toLowerCase();
            clean = clean.replace(/^(?:https?:\/\/)/i, '').replace(/\/.*$/, '');
            if (/\.[a-z]{2,}$/i.test(clean)) {
                return clean;
            }
            var slug = clean.replace(/[^a-z0-9]/g, '');
            return (slug || 'coachsys') + '.com';
        },

        getProductType: function (productId) {
            if (!productId) {
                return this.model.get('cProductServiceType') || null;
            }
            if (this.productTypeCache && this.productTypeCache[productId]) {
                return this.productTypeCache[productId];
            }
            return this.model.get('cProductServiceType') || null;
        },

        getRootDomainPart: function () {
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            var rootDomain = this.getProductRootDomain(prodId);
            if (rootDomain) {
                return '.' + rootDomain.replace(/^\.+/, '');
            }
            var prodType = this.getProductType(prodId) || this.model.get('cProductServiceType') || 'Subscription';
            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();
            if (prodType === 'Subscription') {
                var domain = this.getProductDomain(prodName || 'CoachSys');
                return '.' + domain.replace(/^\.+/, '');
            } else {
                var prodSlug = String(prodName || 'custom-development').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
                return '.' + (prodSlug || 'custom-dev') + '.com';
            }
        },

        getClientSlug: function () {
            var clientName = (this.model.get('accountName') || this.model.get('leadName') || '').trim();
            if (!clientName) {
                var contactsNames = this.model.get('contactsNames');
                if (contactsNames && typeof contactsNames === 'object') {
                    var vals = Object.values(contactsNames).map(function (v) {
                        return v ? String(v).trim() : '';
                    }).filter(Boolean);
                    if (vals.length) {
                        clientName = vals[0];
                    }
                }
            }
            if (!clientName) {
                var oppName = (this.model.get('name') || '').trim();
                if (oppName && !oppName.endsWith(' - Opportunity') && oppName !== 'Opportunity') {
                    var parts = oppName.split('-');
                    if (parts.length > 0) {
                        clientName = parts[0].trim();
                    }
                }
            }
            var slug = String(clientName || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
            return slug || 'client';
        },

        generateSubdomainUrl: function () {
            if (this.model.get('stage') !== 'Closed Won') {
                return '';
            }

            var clientSlug = this.getClientSlug() || 'client';
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            var rootDomain = this.getProductRootDomain(prodId);

            if (rootDomain) {
                var cleanRoot = rootDomain.replace(/^\.+/, '');
                if (!cleanRoot.includes('.')) {
                    cleanRoot += '.com';
                }
                return clientSlug + '.' + cleanRoot;
            }

            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();
            var prodSlug = String(prodName || 'service').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
            return clientSlug + '.' + (prodSlug || 'service') + '.com';
        },

        getSubdomainPlaceholder: function () {
            var clientSlug = this.getClientSlug() || 'client';
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            var rootDomain = this.getProductRootDomain(prodId);

            if (rootDomain) {
                var cleanRoot = rootDomain.replace(/^\.+/, '');
                if (!cleanRoot.includes('.')) {
                    cleanRoot += '.com';
                }
                return 'e.g. ' + clientSlug + '.' + cleanRoot;
            }

            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();
            var prodSlug = String(prodName || 'service').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
            return 'e.g. ' + clientSlug + '.' + (prodSlug || 'service') + '.com';
        },

        updateSubdomainValue: function (force) {
            if (!this.hasSubscriptionScope()) {
                return;
            }
            if (this.model.get('stage') !== 'Closed Won') {
                return;
            }
            var currentVal = (this.model.get('cSubdomain') || '').trim();
            var generated = this.generateSubdomainUrl();

            if (generated && (!currentVal || force || currentVal.startsWith('.'))) {
                this.model.set('cSubdomain', generated, { ui: true, fromAutoSubdomain: true });
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('[data-name="cSubdomain"] input').val(generated);
                    this.$el.find('input[data-name="cSubdomain"]').val(generated);
                }
                var subFieldView = (typeof this.getFieldView === 'function') ? this.getFieldView('cSubdomain') : null;
                if (subFieldView && typeof subFieldView.reRender === 'function' && subFieldView.mode !== 'edit') {
                    subFieldView.reRender();
                }
            }
            this.updateSubdomainPlaceholder();
        },

        updateSubdomainPlaceholder: function () {
            var placeholder = this.getSubdomainPlaceholder();

            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="cSubdomain"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('input');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $inputElem = this.$el.find('input[data-name="cSubdomain"]');
                if ($inputElem && $inputElem.length) {
                    if (typeof $inputElem.attr === 'function') {
                        $inputElem.attr('placeholder', placeholder);
                    } else if ($inputElem[0] && typeof $inputElem[0].setAttribute === 'function') {
                        $inputElem[0].setAttribute('placeholder', placeholder);
                    }
                }
            }
        },

        syncWonPlanFieldUI: function (planId, planName) {
            if (!planId) return;
            planName = planName || '';
            var planFieldView = (typeof this.getFieldView === 'function') ? this.getFieldView('cWonPlan') : null;
            if (planFieldView) {
                if (planFieldView.$elementName && typeof planFieldView.$elementName.val === 'function') {
                    planFieldView.$elementName.val(planName);
                }
                if (planFieldView.$elementId && typeof planFieldView.$elementId.val === 'function') {
                    planFieldView.$elementId.val(planId);
                }
                if (typeof planFieldView.trigger === 'function') {
                    planFieldView.trigger('change');
                }
                if (typeof planFieldView.controlCreateButtonVisibility === 'function') {
                    planFieldView.controlCreateButtonVisibility();
                }
                if (typeof planFieldView.loadPlan === 'function') {
                    planFieldView.loadPlan();
                } else if (typeof planFieldView.reRender === 'function') {
                    planFieldView.reRender();
                }
            }
            if (this.$el && typeof this.$el.find === 'function') {
                this.$el.find('input[data-name="cWonPlanName"]').val(planName);
                this.$el.find('input[data-name="cWonPlanId"]').val(planId);
                this.$el.find('.field[data-name="cWonPlan"] input.main-element').val(planName);
                this.$el.find('.field[data-name="cWonPlan"] input[data-name="cWonPlanName"]').val(planName);
                this.$el.find('.field[data-name="cWonPlan"] input[data-name="cWonPlanId"]').val(planId);
            }
        },

        checkAndPromptPlans: async function (productId, options) {
            options = options || {};
            if (!this.hasSubscriptionScope()) {
                return;
            }
            if (!productId) {
                productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            }
            if (!productId || !/^[a-z0-9]{17}$/i.test(productId)) {
                return;
            }

            if (this.model.get('cWonPlanId') && !options.forceManual) {
                return;
            }

            try {
                var res = await Espo.Ajax.getRequest('CSubscriptionPlan', {
                    where: [
                        { type: 'equals', attribute: 'productId', value: productId },
                        { type: 'equals', attribute: 'status', value: 'Active' }
                    ],
                    maxSize: 20
                }, { returnError: true });

                if (!res) return;
                var list = res.list || [];
                var total = (typeof res.total === 'number') ? res.total : list.length;

                if (total === 1 && list.length === 1) {
                    var singlePlan = list[0];
                    var values = {
                        cWonPlanId: singlePlan.id,
                        cWonPlanName: singlePlan.name
                    };
                    if (singlePlan.monthlyPrice != null) {
                        values.cWonPlanPrice = singlePlan.monthlyPrice;
                        values.cWonPlanPriceCurrency = singlePlan.monthlyPriceCurrency;
                    }
                    if (singlePlan.billingPeriod) {
                        values.cWonPeriod = singlePlan.billingPeriod;
                    }
                    this.model.set(values, { ui: true, fromPlanAutoFill: true });
                    this.syncWonPlanFieldUI(singlePlan.id, singlePlan.name);
                } else if (total > 1 || list.length > 1) {
                    this.openPlanPicker(productId);
                }
            } catch (e) {
                console.warn('Subscription plans check failed:', e);
            }
        },

        openPlanPicker: async function (productId) {
            if (!this.hasSubscriptionScope() || !productId || !/^[a-z0-9]{17}$/i.test(productId)) return;
            if (this.hasView('wonPlanPicker') || this.isOpeningPlanPicker) return;
            this.isOpeningPlanPicker = true;

            var onPlanSelected = (record) => {
                this.isOpeningPlanPicker = false;
                if (Array.isArray(record)) record = record[0];
                if (!record) return;
                var currentProdId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                if (currentProdId !== productId) return;

                var planId = record.id || (typeof record.get === 'function' ? record.get('id') : null);
                var planName = (typeof record.get === 'function' ? record.get('name') : record.name) || '';
                var planPrice = typeof record.get === 'function' ? record.get('monthlyPrice') : record.monthlyPrice;
                var planCurrency = typeof record.get === 'function' ? record.get('monthlyPriceCurrency') : record.monthlyPriceCurrency;
                var planPeriod = typeof record.get === 'function' ? record.get('billingPeriod') : record.billingPeriod;

                var values = {
                    cWonPlanId: planId,
                    cWonPlanName: planName
                };
                if (planPrice != null) {
                    values.cWonPlanPrice = planPrice;
                    values.cWonPlanPriceCurrency = planCurrency;
                }
                if (planPeriod) {
                    values.cWonPeriod = planPeriod;
                }
                this.model.set(values, { ui: true, fromPlanPicker: true });
                this.syncWonPlanFieldUI(planId, planName);
            };

            try {
                var modal = await this.createView('wonPlanPicker', 'views/modals/select-records', {
                    scope: 'CSubscriptionPlan',
                    multiple: false,
                    createButton: false,
                    filters: {
                        product: { type: 'equals', attribute: 'productId', value: productId },
                        active: { type: 'equals', attribute: 'status', value: 'Active' }
                    },
                    onSelect: onPlanSelected
                });

                this.listenToOnce(modal, 'select', onPlanSelected);
                this.listenToOnce(modal, 'close remove', () => {
                    this.isOpeningPlanPicker = false;
                });
                await modal.render();
            } catch (e) {
                this.isOpeningPlanPicker = false;
                console.warn('Could not open plans picker:', e);
            }
        },

        manageWonSubscriptionPanels: function () {
            var hasSubScope = this.hasSubscriptionScope();
            var stage = this.model.get('stage');
            var isClosedWon = (stage === 'Closed Won');

            if (isClosedWon && hasSubScope) {
                if (typeof this.showPanel === 'function') {
                    this.showPanel('wonSubscription');
                }
                if (typeof this.showField === 'function') {
                    this.showField('cSubdomain');
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('[data-name="wonSubscription"]').show();
                    this.$el.find('.cell[data-name="cSubdomain"]').show();
                    this.$el.find('.field[data-name="cSubdomain"]').show();
                }
            } else if (!isClosedWon && hasSubScope) {
                if (typeof this.hidePanel === 'function') {
                    this.hidePanel('wonSubscription');
                }
                if (typeof this.hideField === 'function') {
                    this.hideField('cSubdomain');
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('[data-name="wonSubscription"]').hide();
                    this.$el.find('.cell[data-name="cSubdomain"]').hide();
                    this.$el.find('.field[data-name="cSubdomain"]').hide();
                }
            }
        },

        validate: function () {
            var hasError = false;
            if (Dep.prototype.validate) {
                hasError = Dep.prototype.validate.call(this);
            }

            if (this.model.get('stage') === 'Closed Won' && this.hasSubscriptionScope()) {
                var sub = (this.model.get('cSubdomain') || '').trim();
                var isInvalidSubdomain = !sub || sub.startsWith('.') || !sub.includes('.') || sub.indexOf('.') === 0 || sub.split('.')[0].trim() === '';

                if (isInvalidSubdomain) {
                    hasError = true;
                    var msg = 'Please enter the subdomain.';
                    if (typeof this.translate === 'function') {
                        msg = this.translate('Please enter the subdomain.', 'messages', 'Opportunity') || msg;
                    }
                    if (typeof Espo !== 'undefined' && Espo.Ui && typeof Espo.Ui.warning === 'function') {
                        Espo.Ui.warning(msg);
                    }
                    if (typeof this.showValidationMessage === 'function') {
                        this.showValidationMessage('cSubdomain', msg);
                    }
                }
            }

            return hasError;
        },

        beforeSave: function () {
            if (Dep.prototype.beforeSave) {
                Dep.prototype.beforeSave.call(this);
            }
            if (this.model.get('stage') === 'Closed Won' && this.hasSubscriptionScope()) {
                var sub = (this.model.get('cSubdomain') || '').trim();
                if (sub && !sub.startsWith('.') && !sub.includes('.')) {
                    var slug = String(sub).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
                    if (slug) {
                        var rootPart = this.getRootDomainPart();
                        this.model.set('cSubdomain', slug + rootPart);
                    }
                }
            }
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            if (prodId) {
                this.ensureProductData(prodId).then(() => {
                    this.manageWonSubscriptionPanels();
                    if (this.model.get('stage') === 'Closed Won') {
                        this.updateSubdomainValue(true);
                    }
                    this.updateSubdomainPlaceholder();
                });
            } else {
                this.manageWonSubscriptionPanels();
                if (this.model.get('stage') === 'Closed Won') {
                    this.updateSubdomainValue(true);
                }
                this.updateSubdomainPlaceholder();
            }
        }

    });

});
