<?php

namespace Espo\Custom\Classes\Select;

use Espo\Core\ORM\Type\FieldType;
use Espo\Core\Select\Text\ConfigProvider;
use Espo\Core\Select\Text\DefaultFilter;
use Espo\Core\Select\Text\Filter;
use Espo\Core\Select\Text\Filter\Data;
use Espo\Core\Select\Text\MetadataProvider;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Query\Part\Condition as Cond;
use Espo\ORM\Query\Part\Expression as Expr;
use Espo\ORM\Query\Part\Where\OrGroup;
use Espo\ORM\Query\Part\Where\OrGroupBuilder;
use Espo\ORM\Query\SelectBuilder;

class BaseContainsTextFilter implements Filter
{
    private const EXTRA_ATTRIBUTES = [
        'Lead' => ['addressCity'],
        'Account' => ['billingAddressCity', 'shippingAddressCity', 'website'],
        'Contact' => ['addressCity', 'account.billingAddressCity', 'account.shippingAddressCity'],
        'Opportunity' => ['name', 'account.name', 'account.billingAddressCity', 'account.shippingAddressCity', 'contacts.addressCity'],
        'Call' => ['name'],
        'Meeting' => ['name'],
    ];

    public function __construct(
        private string $entityType,
        private DefaultFilter $defaultFilter,
        private MetadataProvider $metadataProvider,
        private ConfigProvider $config,
        private EntityManager $entityManager,
    ) {}

    public function apply(SelectBuilder $queryBuilder, Data $data): void
    {
        $filter = trim($data->getFilter());
        $skipWildcards = $data->skipWildcards();

        // Require at least 3 continuous characters for anywhere-contains matching
        if (mb_strlen($filter) < 3) {
            $this->defaultFilter->apply($queryBuilder, $data);
            return;
        }

        $orGroupBuilder = OrGroup::createBuilder();

        $digits = preg_replace('/[^0-9]/', '', $filter);
        $isPhoneQuery = $digits !== '' && strlen($digits) >= 3 && preg_match('/^[0-9()\-+%\s]+$/', $filter);
        $hasPhoneField = $this->metadataProvider->getFieldType($this->entityType, 'phoneNumber') === FieldType::PHONE;

        if ($isPhoneQuery && $hasPhoneField && !$skipWildcards) {
            $tableAlias = lcfirst($this->entityType);
            $phoneSubQuery = SelectBuilder::create()
                ->select(['id'])
                ->from('EntityPhoneNumber', 'epn')
                ->join('PhoneNumber', 'pn', ['pn.id:' => 'epn.phoneNumberId'])
                ->where([
                    'epn.entityType' => $this->entityType,
                    'epn.deleted' => false,
                    'pn.deleted' => false,
                ])
                ->where(
                    Cond::equal(Expr::column('epn.entityId'), Expr::column($tableAlias . '.id'))
                )
                ->where(
                    Cond::or(
                        Cond::like(Expr::column('pn.numeric'), '%' . $digits . '%'),
                        Cond::like(Expr::column('pn.name'), '%' . addslashes($filter) . '%')
                    )
                )
                ->build();

            $orGroupBuilder->add(Cond::exists($phoneSubQuery));
        }

        $extraProductAttributes = [];
        $ormDefs = $this->entityManager->getDefs()->getEntity($this->entityType);
        if (
            $ormDefs->hasRelation('cProductServices') &&
            $ormDefs->getRelation('cProductServices')->hasForeignEntityType() &&
            $ormDefs->getRelation('cProductServices')->getForeignEntityType() === 'CProductService'
        ) {
            $extraProductAttributes[] = 'cProductServices.name';
        }
        if (
            $ormDefs->hasRelation('cProductService') &&
            $ormDefs->getRelation('cProductService')->hasForeignEntityType() &&
            $ormDefs->getRelation('cProductService')->getForeignEntityType() === 'CProductService'
        ) {
            $extraProductAttributes[] = 'cProductService.name';
        }

        $attributeList = array_values(array_unique(array_merge(
            $data->getAttributeList(),
            $this->metadataProvider->getTextFilterAttributeList($this->entityType) ?? [],
            self::EXTRA_ATTRIBUTES[$this->entityType] ?? [],
            $extraProductAttributes
        )));

        $likeExpression = $skipWildcards ? addslashes($filter) : '%' . addslashes($filter) . '%';

        foreach ($attributeList as $attribute) {
            if (
                !str_contains($attribute, '.') &&
                $this->metadataProvider->getFieldType($this->entityType, $attribute) === FieldType::PHONE
            ) {
                if ($isPhoneQuery) {
                    continue;
                }
                if (!preg_match('#[0-9()\-+% ]+$#', $filter)) {
                    continue;
                }
            }

            if (
                !str_contains($attribute, '.') &&
                $this->metadataProvider->getFieldType($this->entityType, $attribute) === FieldType::EMAIL &&
                str_contains($filter, ' ')
            ) {
                continue;
            }

            $attributeType = $this->getAttributeTypeAndApplyJoin($queryBuilder, $attribute);

            if ($attributeType === Entity::INT) {
                if (is_numeric($filter)) {
                    $orGroupBuilder->add(Cond::equal(Expr::column($attribute), intval($filter)));
                }
                continue;
            }

            $orGroupBuilder->add(Cond::like(Expr::column($attribute), $likeExpression));
        }

        if (in_array($this->entityType, ['Call', 'Meeting'], true) && $filter !== '') {
            $this->addParentCityConditions($orGroupBuilder, $likeExpression);
        }

        $orGroup = $orGroupBuilder->build();
        if ($orGroup->getItemCount() === 0) {
            $queryBuilder->where(['id' => null]);
            return;
        }

        $queryBuilder->where($orGroup);
    }

    private function addParentCityConditions(OrGroupBuilder $orGroupBuilder, string $likeExpression): void
    {
        $alias = lcfirst($this->entityType);

        $orGroupBuilder->add(Cond::and(
            Cond::equal(Expr::column('parentType'), 'Lead'),
            Cond::exists(
                SelectBuilder::create()
                    ->select(['id'])
                    ->from('Lead', 'pl')
                    ->where(['pl.deleted' => false])
                    ->where(Cond::equal(Expr::column('pl.id'), Expr::column($alias . '.parentId')))
                    ->where(Cond::like(Expr::column('pl.addressCity'), $likeExpression))
                    ->build()
            )
        ));

        $orGroupBuilder->add(Cond::and(
            Cond::equal(Expr::column('parentType'), 'Account'),
            Cond::exists(
                SelectBuilder::create()
                    ->select(['id'])
                    ->from('Account', 'pa')
                    ->where(['pa.deleted' => false])
                    ->where(Cond::equal(Expr::column('pa.id'), Expr::column($alias . '.parentId')))
                    ->where(Cond::or(
                        Cond::like(Expr::column('pa.billingAddressCity'), $likeExpression),
                        Cond::like(Expr::column('pa.shippingAddressCity'), $likeExpression)
                    ))
                    ->build()
            )
        ));

        $orGroupBuilder->add(Cond::and(
            Cond::equal(Expr::column('parentType'), 'Contact'),
            Cond::exists(
                SelectBuilder::create()
                    ->select(['id'])
                    ->from('Contact', 'pc')
                    ->where(['pc.deleted' => false])
                    ->where(Cond::equal(Expr::column('pc.id'), Expr::column($alias . '.parentId')))
                    ->where(Cond::like(Expr::column('pc.addressCity'), $likeExpression))
                    ->build()
            )
        ));

        $orGroupBuilder->add(Cond::and(
            Cond::equal(Expr::column('parentType'), 'Opportunity'),
            Cond::exists(
                SelectBuilder::create()
                    ->select(['id'])
                    ->from('Opportunity', 'po')
                    ->join('Account', 'poa', ['poa.id:' => 'po.accountId'])
                    ->where(['po.deleted' => false, 'poa.deleted' => false])
                    ->where(Cond::equal(Expr::column('po.id'), Expr::column($alias . '.parentId')))
                    ->where(Cond::or(
                        Cond::like(Expr::column('poa.billingAddressCity'), $likeExpression),
                        Cond::like(Expr::column('poa.shippingAddressCity'), $likeExpression)
                    ))
                    ->build()
            )
        ));
    }

    private function getAttributeTypeAndApplyJoin(SelectBuilder $queryBuilder, string $attribute): string
    {
        if (str_contains($attribute, '.')) {
            [$link, $foreignField] = explode('.', $attribute);
            $foreignEntityType = $this->metadataProvider->getRelationEntityType($this->entityType, $link);

            if ($foreignEntityType) {
                if ($this->metadataProvider->getRelationType($this->entityType, $link) === Entity::HAS_MANY) {
                    $queryBuilder->distinct();
                }
                $queryBuilder->leftJoin($link);
                return $this->metadataProvider->getAttributeType($foreignEntityType, $foreignField);
            }
        }

        $attributeType = $this->metadataProvider->getAttributeType($this->entityType, $attribute);

        if ($attributeType === Entity::FOREIGN) {
            $link = $this->metadataProvider->getAttributeRelationParam($this->entityType, $attribute);
            if ($link) {
                $queryBuilder->leftJoin($link);
            }
        }

        return $attributeType;
    }
}
