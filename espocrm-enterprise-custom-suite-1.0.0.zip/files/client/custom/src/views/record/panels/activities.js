define('custom:views/record/panels/activities', ['crm:views/record/panels/activities'], function (Dep) {

    return Dep.extend({

        setup: function () {
            this.listLayout = {
                'Email': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true }
                    ], [
                        { name: 'dateSent', soft: true },
                        { name: 'from' },
                        { name: 'hasAttachment', view: 'views/email/fields/has-attachment' }
                    ]]
                },
                'Call': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'description' }
                    ]]
                },
                'Meeting': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'description' }
                    ]]
                }
            };

            this.resolveParentScope();

            Dep.prototype.setup.call(this);

            this.applyParentScopeUrl();
            this.applyProductServiceFilter();
            this.setupCollectionFilter();
            this.setupAutoRefresh();
            this.setupParentChangeListener();
        },

        resolveParentScope: function () {
            var entityType = this.model.entityType || this.model.name;
            this.isActivityRecord = (entityType === 'Call' || entityType === 'Meeting');

            if (this.isActivityRecord) {
                this.parentType = this.model.get('parentType');
                this.parentId = this.model.get('parentId');
            } else {
                this.parentType = null;
                this.parentId = null;
            }
        },

        applyParentScopeUrl: function () {
            if (!this.collection) {
                return;
            }

            if (this.isActivityRecord) {
                if (this.parentType && this.parentId) {
                    this.url = 'Activities/' + this.parentType + '/' + this.parentId + '/activities';
                    this.collection.url = this.url;
                } else {
                    this.url = 'Activities/EmptyParent/' + (this.model.id || 'none') + '/activities';
                    this.collection.url = this.url;
                }
            }
        },

        setupParentChangeListener: function () {
            if (!this.isActivityRecord) {
                return;
            }

            this.listenTo(this.model, 'change:parentType change:parentId', function () {
                this.resolveParentScope();
                this.applyParentScopeUrl();
                if (this.collection) {
                    this.collection.fetch();
                }
            }.bind(this));
        },

        /**
         * Ensure Activities panel displays only Planned records and no duplicates.
         */
        setupCollectionFilter: function () {
            var collection = this.collection;
            if (!collection) return;

            var prepareAttributes = collection.prepareAttributes;
            collection.prepareAttributes = function (response, options) {
                if (response && Array.isArray(response.list)) {
                    var seen = {};
                    response.list = response.list.filter(function (attrs) {
                        if (!attrs || !attrs.id) return false;
                        if (attrs.status && attrs.status !== 'Planned') return false;
                        if (seen[attrs.id]) return false;
                        seen[attrs.id] = true;
                        return true;
                    });
                }
                return prepareAttributes.call(this, response, options);
            };
        },

        applyProductServiceFilter: function () {
            if (!this.collection) {
                return;
            }

            var idList = this.model.get('cProductServicesIds');

            if (!idList && this.model.get('cProductServiceId')) {
                idList = [this.model.get('cProductServiceId')];
            }

            if (Array.isArray(idList) && idList.length) {
                this.collection.data.productServiceIds = idList.join(',');
            } else {
                delete this.collection.data.productServiceIds;
            }
        },

        setupAutoRefresh: function () {
            this.listenTo(this.model, 'after:save', function () {
                if (this.activitiesRefreshTimer) {
                    clearTimeout(this.activitiesRefreshTimer);
                }

                this.activitiesRefreshTimer = setTimeout(function () {
                    this.activitiesRefreshTimer = null;

                    if (!this.collection) {
                        return;
                    }

                    this.applyProductServiceFilter();
                    this.collection.fetch();
                }.bind(this), 150);
            }.bind(this));
        },

        onRemove: function () {
            if (this.activitiesRefreshTimer) {
                clearTimeout(this.activitiesRefreshTimer);
                this.activitiesRefreshTimer = null;
            }

            if (Dep.prototype.onRemove) {
                Dep.prototype.onRemove.call(this);
            }
        },

        afterRender: function () {
            if (Dep.prototype.afterRender) {
                Dep.prototype.afterRender.call(this);
            }

            // If viewing a Converted Lead, prevent creating new activities via the UI
            var isConvertedLead = (this.model.entityType === 'Lead' && this.model.get('status') === 'Converted');
            if (isConvertedLead) {
                this.$el.find('.action[data-action="createActivity"], .btn[data-action="createActivity"], [data-action="createRelated"]').hide().remove();
            }
        },

        getCreateActivityAttributes: function (scope, data, callback) {
            Dep.prototype.getCreateActivityAttributes.call(this, scope, data, function (attributes) {
                var modelType = this.model ? (this.model.entityType || this.model.name) : null;
                if (modelType === 'Contact' && (scope === 'Call' || scope === 'Meeting') && this.model.id) {
                    attributes.parentType = 'Contact';
                    attributes.parentId = this.model.id;
                    attributes.parentName = this.model.get('name');
                }
                if (typeof callback === 'function') {
                    callback.call(this, attributes);
                }
            }.bind(this));
        }
    });

});
