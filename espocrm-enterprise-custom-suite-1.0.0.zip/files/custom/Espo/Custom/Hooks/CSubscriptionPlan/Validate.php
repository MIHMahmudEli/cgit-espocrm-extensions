<?php
namespace Espo\Custom\Hooks\CSubscriptionPlan;
use Espo\Core\Exceptions\BadRequest;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\SaveOptions;
class Validate implements \Espo\Core\Hook\Hook\BeforeSave, \Espo\Core\Di\EntityManagerAware
{
    public static int $order = 5;
    private ?EntityManager $entityManager = null;
    public function setEntityManager(EntityManager $entityManager): void { $this->entityManager = $entityManager; }
    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        $product = $entity->get('productId') ? $this->entityManager->getEntityById('CProductService', $entity->get('productId')) : null;
        if (!$product || $product->get('type') !== 'Subscription') {
            throw new BadRequest('Subscription plans require a subscription product.');
        }
        if (!$entity->isNew() && $entity->isAttributeChanged('productId')) {
            throw new BadRequest('A plan cannot move to a different product. Create a new plan instead.');
        }
        $price = $entity->get('monthlyPrice');
        if ($price === null || !is_numeric($price) || !is_finite((float) $price) || $price < 0 || !$entity->get('monthlyPriceCurrency')) {
            throw new BadRequest('A price per billing period and currency are required.');
        }
        $period=$entity->get('billingPeriod')??'Monthly';
        if(!in_array($period,['Monthly','Quarterly','Semiannual','Annual'],true))throw new BadRequest('Select a valid billing period.');
        $entity->set('billingPeriod',$period);
    }
}
