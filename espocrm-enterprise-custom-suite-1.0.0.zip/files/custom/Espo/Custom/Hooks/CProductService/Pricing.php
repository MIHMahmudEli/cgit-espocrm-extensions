<?php
namespace Espo\Custom\Hooks\CProductService;
use Espo\Core\Exceptions\BadRequest;
use Espo\ORM\Entity;
use Espo\ORM\Repository\Option\SaveOptions;
class Pricing implements \Espo\Core\Hook\Hook\BeforeSave, \Espo\Core\Di\EntityManagerAware
{
    private ?\Espo\ORM\EntityManager $entityManager = null;
    public function setEntityManager(\Espo\ORM\EntityManager $entityManager): void { $this->entityManager = $entityManager; }
    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        if (!$entity->isNew() && $entity->isAttributeChanged('type') && $entity->getFetched('type') === 'Subscription' &&
            $this->entityManager->getRDBRepository('CSubscriptionPlan')->where(['productId' => $entity->getId()])->findOne()) {
            throw new BadRequest('A subscription product with plans cannot change its type.');
        }
        $price = $entity->get('price');
        if (!in_array($entity->get('type'), ['Subscription', 'Custom Development'], true) && $price === null) {
            throw new BadRequest('A price is required for this product type.');
        }
        if ($price !== null && (!is_numeric($price) || !is_finite((float) $price) || $price < 0)) {
            throw new BadRequest('Price must be zero or greater.');
        }
    }
}
