define('custom:views/c-subscription-plan/record/edit', ['views/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    var TARGET_PLACEHOLDER_FIELDS = [
        'name',
        'description'
    ];

    return Dep.extend({

        getAuthorizedUser: function () {
            if (typeof this.getUser === 'function' && this.getUser()) {
                return this.getUser();
            }
            if (this._helper && this._helper.user) {
                return this._helper.user;
            }
            if (typeof this.getHelper === 'function' && this.getHelper() && this.getHelper().user) {
                return this.getHelper().user;
            }
            if (typeof Espo !== 'undefined' && Espo.user) {
                return Espo.user;
            }
            return null;
        },

        setup: function () {
            if (this.model.isNew() && !this.model.get('assignedUserId')) {
                var user = this.getAuthorizedUser();
                if (user && user.id && user.id !== 'system') {
                    var userName = typeof user.get === 'function' ? user.get('name') : (user.name || '');
                    this.model.set({
                        assignedUserId: user.id,
                        assignedUserName: userName
                    });
                }
            }

            Dep.prototype.setup.call(this);

            this.listenTo(this.model, 'change:productId change:productName change:billingPeriod', function () {
                this.updateNamePlaceholder();
            });
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            this.updateAllPlaceholders();
            this.hookFieldViewRenderListeners();
            this.enforceProductFilter();
            this.syncAssignedUserField();
        },

        syncAssignedUserField: function () {
            if (this.model.isNew() && !this.model.get('assignedUserId')) {
                var user = this.getAuthorizedUser();
                if (user && user.id && user.id !== 'system') {
                    var userName = typeof user.get === 'function' ? user.get('name') : (user.name || '');
                    this.model.set({
                        assignedUserId: user.id,
                        assignedUserName: userName
                    });
                }
            }

            var userId = this.model.get('assignedUserId');
            var userName = this.model.get('assignedUserName');
            if (userId) {
                var assignedView = this.getFieldView('assignedUser');
                if (assignedView) {
                    if (typeof assignedView.setValue === 'function') {
                        assignedView.setValue(userId, userName);
                    } else if (typeof assignedView.render === 'function' && !assignedView.isRendered()) {
                        assignedView.render();
                    }
                }
            }
        },

        getNamePlaceholder: function () {
            var productName = (this.model.get('productName') || '').trim();
            var billingPeriod = (this.model.get('billingPeriod') || '').trim();

            if (productName) {
                if (billingPeriod && billingPeriod !== 'Monthly') {
                    return 'e.g. ' + productName + ' - ' + billingPeriod + ' Tier, Enterprise ' + billingPeriod + '...';
                }
                return 'e.g. ' + productName + ' - Professional Tier, Enterprise Annual, Basic Starter...';
            }

            return 'e.g. Professional Tier, Enterprise Annual, Basic Starter, Growth Plan...';
        },

        getDescriptionPlaceholder: function () {
            return 'e.g. Tier feature breakdown, user seat limits, API usage quotas, included support SLA, or renewal terms...';
        },

        getFieldPlaceholders: function () {
            return {
                name: this.getNamePlaceholder(),
                description: this.getDescriptionPlaceholder()
            };
        },

        applyFieldPlaceholder: function (fieldName, placeholder) {
            if (!placeholder) {
                var placeholders = this.getFieldPlaceholders();
                placeholder = placeholders[fieldName];
            }
            if (!placeholder) return;

            // 1. Direct DOM search by data-name or cell/field container
            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="' + fieldName + '"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('input, textarea');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="' + fieldName + '"], .field[data-name="' + fieldName + '"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('input, textarea');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            // 2. Field view update
            var fieldView = this.getFieldView(fieldName);
            if (fieldView) {
                fieldView.placeholder = placeholder;
                if (fieldView.params) {
                    fieldView.params.placeholder = placeholder;
                }
                if (fieldView.$element) {
                    if (typeof fieldView.$element.attr === 'function') {
                        fieldView.$element.attr('placeholder', placeholder);
                    } else if (fieldView.$element[0] && typeof fieldView.$element[0].setAttribute === 'function') {
                        fieldView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (fieldView.$el && typeof fieldView.$el.find === 'function') {
                    var $inputs = fieldView.$el.find('input, textarea');
                    if ($inputs.length) {
                        if (typeof $inputs.attr === 'function') {
                            $inputs.attr('placeholder', placeholder);
                        } else if ($inputs[0] && typeof $inputs[0].setAttribute === 'function') {
                            $inputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        },

        updateNamePlaceholder: function () {
            this.applyFieldPlaceholder('name', this.getNamePlaceholder());
        },

        updateAllPlaceholders: function () {
            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                this.applyFieldPlaceholder(fieldName);
            }, this);
        },

        hookFieldViewRenderListeners: function () {
            this._hookedFieldViews = this._hookedFieldViews || {};

            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                if (this._hookedFieldViews[fieldName]) return;
                var fieldView = this.getFieldView(fieldName);
                if (fieldView) {
                    this._hookedFieldViews[fieldName] = true;
                    this.listenTo(fieldView, 'after:render', function () {
                        this.applyFieldPlaceholder(fieldName);
                    }.bind(this));
                }
            }, this);
        },

        enforceProductFilter: function () {
            var productView = this.getFieldView('product');
            if (productView) {
                var origFilters = typeof productView.getSelectFilters === 'function' ?
                    productView.getSelectFilters.bind(productView) : null;

                productView.getSelectFilters = function () {
                    var filters = Object.assign({}, (origFilters ? origFilters() : {}) || {});
                    filters.subscription = {
                        type: 'equals',
                        attribute: 'type',
                        value: 'Subscription'
                    };
                    filters.active = {
                        type: 'equals',
                        attribute: 'status',
                        value: 'Active'
                    };
                    return filters;
                };
            }
        }

    });

});
