<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);


            if (class_exists(\Espo\Custom\WebPush\VapidKeys::class)) {
                (new \Espo\Custom\WebPush\VapidKeys())->isConfigured();
            }
            $customClientJson = 'custom/Espo/Custom/Resources/metadata/app/client.json';
            if (is_file($customClientJson)) {
                $cd = json_decode((string) file_get_contents($customClientJson), true);
                if (is_array($cd) && isset($cd['scriptList']) && is_array($cd['scriptList'])) {
                    $filtered = array_values(array_filter($cd['scriptList'], fn ($s) => $s !== 'client/custom/src/web-push.js'));
                    if (count($filtered) !== count($cd['scriptList'])) {
                        if ($filtered === []) {
                            unset($cd['scriptList']);
                        } else {
                            $cd['scriptList'] = $filtered;
                        }
                        unset($cd['developerModeScriptList']);
                        file_put_contents($customClientJson, json_encode($cd, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                    }
                }
            }
            if (!$container->has('user')) {
                $appUser = $container->getByClass(\Espo\Core\ApplicationUser::class);
                if ($appUser) {
                    $appUser->setupSystemUser();
                }
            }
            $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
            foreach ([
                'CallRouteReminders' => 'Call Route Reminders',
                'MeetingReminders' => 'Meeting Reminders',
                'PopupRemindersPush' => 'Popup Reminders Web Push',
            ] as $jobKey => $jobName) {
                $existingJob = $em->getRDBRepository('ScheduledJob')->where(['job' => $jobKey, 'deleted' => false])->findOne();
                if (!$existingJob) {
                    $sj = $em->getNewEntity('ScheduledJob');
                    $sj->set([
                        'name' => $jobName,
                        'job' => $jobKey,
                        'status' => 'Active',
                        'scheduling' => '* * * * *',
                    ]);
                    $em->saveEntity($sj, ['silent' => true]);
                }
            }

        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
