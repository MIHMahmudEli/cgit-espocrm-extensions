<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM — Open Source CRM application.
 * Copyright (C) 2014-2026 EspoCRM, Inc.
 * Website: https://www.espocrm.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 ************************************************************************/

namespace Espo\Custom\WebPush;

use Espo\Core\Name\Field;
use Espo\Core\ORM\EntityManager;
use Espo\Core\Utils\Config;
use Espo\Core\Utils\Language;
use Espo\Core\Utils\Language\LanguageFactory;
use Espo\Core\Utils\Log;
use Espo\Core\Utils\Metadata;
use Espo\Entities\Note;
use Espo\Entities\Notification;
use Espo\Entities\Preferences;
use Throwable;

/**
 * Translates any EspoCRM Notification entity into a formatted Web Push payload
 * that mirrors the in-app notification panel and delivers it via PushNotificationService.
 */
class NotificationDispatcher
{
    private const DEFAULT_TTL = 3600;

    private ?SubscriptionStore $store = null;

    /** @var array<string, bool> */
    private array $dispatchedIds = [];

    /** @var array<string, Language> */
    private array $languageCache = [];

    /** @var array<string, string> */
    private array $entityNameCache = [];

    public function __construct(
        private EntityManager $entityManager,
        private Config $config,
        private Language $defaultLanguage,
        private LanguageFactory $languageFactory,
        private Metadata $metadata,
        private PushNotificationService $pushNotificationService,
        private Log $log,
    ) {}

    public function markDispatched(?string $notificationId): void
    {
        if ($notificationId !== null && $notificationId !== '') {
            $this->dispatchedIds[$notificationId] = true;
        }
    }

    public function dispatchNotification(Notification $notification, ?Note $note = null): void
    {
        if ($this->config->get('webPushEnabled') === false) {
            return;
        }

        $notificationId = (string) ($notification->getId() ?? '');
        if ($notificationId !== '' && isset($this->dispatchedIds[$notificationId])) {
            return;
        }

        $userId = (string) ($notification->getUserId() ?? '');
        if ($userId === '' || $userId === 'anonymous') {
            return;
        }

        // MentionInPost notifications are created inside Note::beforeSave() before the Note exists in DB.
        // Defer dispatch until Note::afterSave() (which passes the saved $note) unless the Note is already persisted.
        if ($note === null && $notification->getType() === Notification::TYPE_MENTION_IN_POST) {
            $data = $notification->getData();
            $related = $notification->getRelated();
            $noteId = (string) ($data->noteId ?? ($related?->getEntityType() === Note::ENTITY_TYPE ? $related->getId() : ''));
            if ($noteId !== '') {
                $loaded = $this->entityManager->getEntityById(Note::ENTITY_TYPE, $noteId);
                if ($loaded instanceof Note) {
                    $note = $loaded;
                } else {
                    return;
                }
            }
        }

        if ($notificationId !== '') {
            $this->dispatchedIds[$notificationId] = true;
        }

        try {
            if ($this->getStore()->listForUser($userId) === []) {
                return;
            }

            $lang = $this->resolveUserLanguage($userId);
            $built = $this->buildFromNotification($notification, $note, $lang);

            $this->pushNotificationService->sendToUser(
                $userId,
                $built['payload'],
                [
                    'category' => $built['category'],
                    'ttl' => self::DEFAULT_TTL,
                    'urgency' => $built['urgency'],
                ]
            );
        } catch (Throwable $e) {
            $this->log->warning('WebPush NotificationDispatcher failed: ' . $e->getMessage());
        }
    }

    /**
     * @return array{payload:array<string,mixed>,category:string,urgency:string}
     */
    private function buildFromNotification(Notification $notification, ?Note $note, Language $lang): array
    {
        $type = (string) ($notification->getType() ?? Notification::TYPE_MESSAGE);
        $data = $notification->getData() ?: (object) [];
        $related = $notification->getRelated();
        $relatedParent = $notification->getRelatedParent();

        $title = 'EspoCRM';
        $body = '';
        $category = PushPreferences::CATEGORY_DEFAULT;
        $urgency = 'normal';
        $entityType = '';
        $entityId = '';
        $url = '';
        $tag = '';

        switch ($type) {
            case Notification::TYPE_MENTION_IN_POST:
            case Notification::TYPE_NOTE:
                return $this->buildFromNoteNotification($notification, $note, $lang);

            case Notification::TYPE_ASSIGN:
                $entityType = (string) ($data->entityType ?? $related?->getEntityType() ?? '');
                $entityId = (string) ($data->entityId ?? $related?->getId() ?? '');
                $entityName = trim((string) ($data->entityName ?? $this->resolveEntityName($entityType, $entityId)));
                $entityLabel = $this->translateEntityType($entityType, $lang);
                $actor = trim((string) ($data->userName ?? ''));

                $title = $entityLabel !== '' ? "{$entityLabel} Assigned" : 'Record Assigned';
                $msg = $this->renderTemplate(
                    $lang->translate('assign', 'notificationMessages', 'Global'),
                    [
                        '{entityType}' => $entityLabel !== '' ? $entityLabel : $entityType,
                        '{entity}' => $entityName,
                    ]
                );
                if ($msg === '' || $msg === 'assign') {
                    $msg = trim("{$entityLabel} {$entityName} has been assigned to you");
                }
                if ($actor !== '' && !str_contains($msg, $actor)) {
                    $msg .= " by {$actor}";
                }
                $body = $msg;
                $category = 'assignment';
                $urgency = 'high';
                break;

            case 'EventAttendee':
                $entityType = (string) ($data->entityType ?? $related?->getEntityType() ?? '');
                $entityId = (string) ($data->entityId ?? $related?->getId() ?? '');
                $entityName = trim((string) ($data->entityName ?? $this->resolveEntityName($entityType, $entityId)));
                $entityLabel = $this->translateEntityType($entityType, $lang);
                $actor = trim((string) ($data->userName ?? ''));

                $title = $entityLabel !== '' ? "{$entityLabel} Invitation" : 'Event Invitation';
                $body = $actor !== ''
                    ? trim("{$actor} added you to {$entityLabel} {$entityName}")
                    : trim("You were added to {$entityLabel} {$entityName}");
                $category = 'calendar';
                $urgency = 'high';
                break;

            case Notification::TYPE_COLLABORATING:
                $entityType = (string) ($related?->getEntityType() ?? $relatedParent?->getEntityType() ?? '');
                $entityId = (string) ($related?->getId() ?? $relatedParent?->getId() ?? '');
                $entityName = trim((string) ($data->relatedName ?? $this->resolveEntityName($entityType, $entityId)));
                $entityLabel = $this->translateEntityType($entityType, $lang);
                $actor = trim((string) ($data->createdByName ?? ''));

                $title = 'Added as Collaborator';
                $body = $actor !== ''
                    ? trim("{$actor} added you as a collaborator to {$entityLabel} {$entityName}")
                    : trim("Added as collaborator to {$entityLabel} {$entityName}");
                $category = 'assignment';
                break;

            case Notification::TYPE_EMAIL_RECEIVED:
                $entityType = 'Email';
                $entityId = (string) ($data->emailId ?? $related?->getId() ?? '');
                $emailSubject = trim((string) ($data->emailName ?? $this->resolveEntityName('Email', $entityId)));
                $from = trim((string) ($data->personEntityName ?? $data->fromString ?? ''));

                $title = $from !== '' ? "Email from {$from}" : 'New Email Received';
                $body = $emailSubject !== '' ? $emailSubject : 'New email received';
                $category = 'message';
                break;

            case 'EmailInbox':
                $entityType = 'Email';
                $entityId = (string) ($related?->getId() ?? ($data->emailId ?? ''));
                $emailName = trim((string) ($data->emailName ?? $data->entityName ?? $this->resolveEntityName('Email', $entityId)));
                $actor = trim((string) ($data->userName ?? ''));

                $title = 'Email Added to Inbox';
                $body = trim(($actor !== '' ? "{$actor} added " : '') . ($emailName !== '' ? $emailName : 'email') . ' to your inbox');
                $category = 'message';
                break;

            case Notification::TYPE_USER_REACTION:
                $actor = trim((string) ($data->userName ?? 'Someone'));
                $entityType = (string) ($relatedParent?->getEntityType() ?? '');
                $entityId = (string) ($relatedParent?->getId() ?? '');
                $parentName = trim((string) ($data->entityName ?? $this->resolveEntityName($entityType, $entityId)));
                $parentLabel = $this->translateEntityType($entityType, $lang);
                $reaction = trim((string) ($data->type ?? 'Like'));

                $title = 'New Reaction';
                $body = "{$actor} reacted ({$reaction}) to your post"
                    . ($parentName !== '' ? ' in ' . trim("{$parentLabel} {$parentName}") : '');
                $category = 'message';
                break;

            case Notification::TYPE_ENTITY_REMOVED:
                $removedType = (string) ($data->entityType ?? '');
                $removedName = trim((string) ($data->entityName ?? ''));
                $removedLabel = $this->translateEntityType($removedType, $lang);
                $actor = trim((string) ($data->userName ?? ''));

                $title = ($removedLabel !== '' ? $removedLabel : 'Record') . ' Removed';
                $body = trim(($actor !== '' ? "{$actor} removed " : 'Removed ') . trim("{$removedLabel} {$removedName}"));
                $category = 'systemAlert';
                $url = '#Notification';
                break;

            case Notification::TYPE_SYSTEM:
            case Notification::TYPE_MESSAGE:
            default:
                $entityType = (string) ($data->entityType ?? $related?->getEntityType() ?? $relatedParent?->getEntityType() ?? '');
                $entityId = (string) ($data->entityId ?? $related?->getId() ?? $relatedParent?->getId() ?? '');
                $rawMsg = (string) ($notification->get('message') ?? ($data->message ?? ''));
                $cleanMsg = $this->cleanText($rawMsg);
                $entityLabel = $this->translateEntityType($entityType, $lang);

                if ($type === Notification::TYPE_SYSTEM) {
                    $title = 'System Notification';
                    $category = 'systemAlert';
                } else {
                    $title = $entityLabel !== '' ? "{$entityLabel} Notification" : 'EspoCRM';
                    $category = 'message';
                }
                $body = $cleanMsg !== '' ? $cleanMsg : 'You have a new notification.';
                break;
        }

        if ($url === '') {
            if ($entityType !== '' && $entityId !== '') {
                $url = '#' . $entityType . '/view/' . $entityId;
            } else {
                $url = '#Notification';
            }
        }

        if ($tag === '' && $notification->getId()) {
            $tag = 'notif-' . $notification->getId();
        }

        $payload = PushNotificationService::buildPayload([
            'notificationId' => (string) ($notification->getId() ?? ''),
            'type' => strtolower($type),
            'title' => $this->truncate($title, 150),
            'body' => $this->truncate($body, 300),
            'entityType' => $entityType,
            'entityId' => $entityId,
            'url' => $url,
            'category' => $category,
            'tag' => $tag,
        ]);

        return [
            'payload' => $payload,
            'category' => $category,
            'urgency' => $urgency,
        ];
    }

    /**
     * @return array{payload:array<string,mixed>,category:string,urgency:string}
     */
    private function buildFromNoteNotification(Notification $notification, ?Note $note, Language $lang): array
    {
        $type = (string) $notification->getType();
        $data = $notification->getData() ?: (object) [];
        $related = $notification->getRelated();
        $relatedParent = $notification->getRelatedParent();

        if ($note === null) {
            $noteId = (string) ($data->noteId ?? ($related?->getEntityType() === Note::ENTITY_TYPE ? $related->getId() : ''));
            if ($noteId !== '') {
                $loaded = $this->entityManager->getEntityById(Note::ENTITY_TYPE, $noteId);
                if ($loaded instanceof Note) {
                    $note = $loaded;
                }
            }
        }

        $parentType = (string) ($note?->getParentType() ?? $relatedParent?->getEntityType() ?? '');
        $parentId = (string) ($note?->getParentId() ?? $relatedParent?->getId() ?? '');
        $parentName = $this->resolveEntityName($parentType, $parentId);
        $parentLabel = $this->translateEntityType($parentType, $lang);

        $author = '';
        if ($note !== null) {
            $author = trim((string) ($note->get('createdByName') ?? ''));
            if ($author === '' && $note->getCreatedById()) {
                $author = $this->resolveEntityName('User', $note->getCreatedById());
            }
        }
        if ($author === '') {
            $author = 'Someone';
        }

        $userId = (string) ($notification->getUserId() ?? '');
        $noteType = (string) ($note?->getType() ?? Note::TYPE_POST);
        $noteData = $note?->getData() ?: (object) [];
        $postSnippet = $this->truncate($this->cleanText((string) ($note?->getPost() ?? '')), 180);

        $title = 'EspoCRM';
        $body = '';
        $category = 'recordUpdate';
        $urgency = 'normal';

        if ($type === Notification::TYPE_MENTION_IN_POST) {
            $title = "{$author} mentioned you";
            $context = ($parentLabel !== '' && $parentName !== '')
                ? "In {$parentLabel} {$parentName}"
                : 'In a post';
            $body = $postSnippet !== '' ? "{$context}: {$postSnippet}" : $context;
            $category = 'mention';
            $urgency = 'high';
        } else {
            switch ($noteType) {
                case Note::TYPE_ASSIGN:
                    $isAssignedToMe = $this->isNoteAssignedToUser($noteData, $userId, (bool) $notification->get('isFeatured'));
                    $title = ($parentLabel !== '' ? $parentLabel : 'Record') . ' Assigned';
                    if ($isAssignedToMe) {
                        $body = trim("{$author} assigned {$parentLabel} {$parentName} to you");
                        $urgency = 'high';
                    } else {
                        $assignee = trim((string) ($noteData->assignedUserName ?? ''));
                        $body = trim("{$author} assigned {$parentLabel} {$parentName}" . ($assignee !== '' ? " to {$assignee}" : ''));
                    }
                    $category = 'assignment';
                    break;

                case Note::TYPE_CREATE:
                    $isAssignedToMe = $this->isNoteAssignedToUser($noteData, $userId, (bool) $notification->get('isFeatured'));
                    $title = $isAssignedToMe
                        ? trim("New {$parentLabel} Assigned")
                        : trim("New {$parentLabel}");
                    $body = $isAssignedToMe
                        ? trim("{$author} created {$parentLabel} {$parentName} assigned to you")
                        : trim("{$author} created {$parentLabel} {$parentName}");
                    $category = $isAssignedToMe ? 'assignment' : 'recordUpdate';
                    if ($isAssignedToMe) {
                        $urgency = 'high';
                    }
                    break;

                case Note::TYPE_POST:
                    if ($parentLabel !== '' && $parentName !== '') {
                        $title = "{$author} commented on {$parentLabel}";
                        $body = $postSnippet !== '' ? "{$parentName}: {$postSnippet}" : $parentName;
                    } else {
                        $title = "{$author} posted a message";
                        $body = $postSnippet !== '' ? $postSnippet : "New message from {$author}";
                    }
                    $category = 'message';
                    break;

                case Note::TYPE_STATUS:
                case Note::TYPE_UPDATE:
                    $title = ($parentLabel !== '' ? $parentLabel : 'Record') . ' Updated';
                    $changeDetail = $this->describeStatusOrUpdate($noteData, $parentType, $lang);
                    $body = trim("{$author} updated " . trim("{$parentLabel} {$parentName}") . ($changeDetail !== '' ? " ({$changeDetail})" : ''));
                    $category = 'recordUpdate';
                    break;

                case Note::TYPE_EMAIL_RECEIVED:
                    $from = trim((string) ($noteData->personEntityName ?? $noteData->fromString ?? ''));
                    $subject = trim((string) ($noteData->emailName ?? ''));
                    $title = $from !== '' ? "Email from {$from}" : 'Email Received';
                    $body = trim(($subject !== '' ? $subject : 'Email received')
                        . ($parentName !== '' ? ' — ' . trim("{$parentLabel} {$parentName}") : ''));
                    $category = 'message';
                    break;

                case Note::TYPE_EMAIL_SENT:
                    $subject = trim((string) ($noteData->emailName ?? ''));
                    $title = 'Email Sent';
                    $body = trim("{$author} sent email"
                        . ($subject !== '' ? ": {$subject}" : '')
                        . ($parentName !== '' ? ' — ' . trim("{$parentLabel} {$parentName}") : ''));
                    $category = 'recordUpdate';
                    break;

                case Note::TYPE_CREATE_RELATED:
                case Note::TYPE_RELATE:
                case Note::TYPE_UNRELATE:
                    $relType = (string) ($note->getRelatedType() ?? '');
                    $relId = (string) ($note->getRelatedId() ?? '');
                    $relLabel = $this->translateEntityType($relType, $lang);
                    $relName = $this->resolveEntityName($relType, $relId);
                    $verb = match ($noteType) {
                        Note::TYPE_CREATE_RELATED => 'added',
                        Note::TYPE_RELATE => 'linked',
                        Note::TYPE_UNRELATE => 'unlinked',
                        default => 'updated',
                    };
                    $title = ($parentLabel !== '' ? $parentLabel : 'Record') . ' Updated';
                    $body = trim("{$author} {$verb} {$relLabel} {$relName}" . ($parentName !== '' ? " on {$parentLabel} {$parentName}" : ''));
                    $category = 'recordUpdate';
                    break;

                default:
                    $title = ($parentLabel !== '' ? $parentLabel : 'EspoCRM') . ' Activity';
                    $body = $postSnippet !== ''
                        ? $postSnippet
                        : trim("{$author} updated " . trim("{$parentLabel} {$parentName}"));
                    $category = 'recordUpdate';
                    break;
            }
        }

        $targetType = $parentType;
        $targetId = $parentId;
        if ($targetType !== '' && $targetId !== '') {
            $url = "#{$targetType}/view/{$targetId}";
        } elseif ($note !== null && $note->getId()) {
            $url = "#Note/view/{$note->getId()}";
            $targetType = Note::ENTITY_TYPE;
            $targetId = $note->getId();
        } else {
            $url = '#Notification';
        }

        $tag = $notification->getId()
            ? 'notif-' . $notification->getId()
            : ($note && $note->getId() ? 'note-' . $note->getId() . '-' . $userId : '');

        $payload = PushNotificationService::buildPayload([
            'notificationId' => (string) ($notification->getId() ?? ''),
            'type' => $type === Notification::TYPE_MENTION_IN_POST ? 'mention' : 'note-' . strtolower($noteType),
            'title' => $this->truncate($title, 150),
            'body' => $this->truncate($body !== '' ? $body : 'New activity in EspoCRM.', 300),
            'entityType' => $targetType,
            'entityId' => $targetId,
            'url' => $url,
            'category' => $category,
            'tag' => $tag,
        ]);

        return [
            'payload' => $payload,
            'category' => $category,
            'urgency' => $urgency,
        ];
    }

    private function isNoteAssignedToUser(object $noteData, string $userId, bool $isFeatured): bool
    {
        if ($isFeatured) {
            return true;
        }
        if (($noteData->assignedUserId ?? null) === $userId) {
            return true;
        }
        $list = $noteData->addedAssignedUsers ?? $noteData->assignedUsers ?? null;
        if (is_array($list)) {
            foreach ($list as $item) {
                if (is_object($item) && ($item->id ?? null) === $userId) {
                    return true;
                }
            }
        }
        return false;
    }

    private function describeStatusOrUpdate(object $noteData, string $parentType, Language $lang): string
    {
        $field = $noteData->statusField ?? $noteData->field ?? null;
        if ((!is_string($field) || $field === '') && $parentType !== '') {
            $statusField = $this->metadata->get(['scopes', $parentType, 'statusField']);
            if (is_string($statusField) && $statusField !== '') {
                $field = $statusField;
            }
        }
        $value = $noteData->statusValue ?? $noteData->value ?? null;

        if (is_string($field) && $field !== '' && $value !== null && $value !== '') {
            $fieldLabel = $parentType !== '' ? $lang->translateLabel($field, 'fields', $parentType) : $field;
            $valLabel = $parentType !== '' ? $lang->translateOption((string) $value, $field, $parentType) : (string) $value;
            return "{$fieldLabel}: {$valLabel}";
        }

        if (isset($noteData->fields) && is_array($noteData->fields) && count($noteData->fields) > 0) {
            $labels = [];
            foreach (array_slice($noteData->fields, 0, 3) as $f) {
                if (!is_string($f) || $f === '') {
                    continue;
                }
                $labels[] = $parentType !== '' ? $lang->translateLabel($f, 'fields', $parentType) : $f;
            }
            if ($labels !== []) {
                return implode(', ', $labels);
            }
        }

        return '';
    }

    private function resolveUserLanguage(string $userId): Language
    {
        try {
            $preferences = $this->entityManager
                ->getRepositoryByClass(Preferences::class)
                ->getById($userId);

            $langCode = Language::detectLanguage($this->config, $preferences);
            if (!$langCode || $langCode === $this->defaultLanguage->getLanguage()) {
                return $this->defaultLanguage;
            }

            if (!isset($this->languageCache[$langCode])) {
                $this->languageCache[$langCode] = $this->languageFactory->create($langCode);
            }

            return $this->languageCache[$langCode];
        } catch (Throwable) {
            return $this->defaultLanguage;
        }
    }

    private function resolveEntityName(?string $entityType, ?string $entityId): string
    {
        if (!$entityType || !$entityId || !$this->entityManager->hasRepository($entityType)) {
            return '';
        }

        $key = $entityType . ':' . $entityId;
        if (array_key_exists($key, $this->entityNameCache)) {
            return $this->entityNameCache[$key];
        }

        try {
            $entity = $this->entityManager->getEntityById($entityType, $entityId);
            $name = '';
            if ($entity) {
                $name = trim((string) ($entity->get(Field::NAME) ?? ''));
            }
            $this->entityNameCache[$key] = $name;
            return $name;
        } catch (Throwable) {
            return '';
        }
    }

    private function translateEntityType(?string $entityType, Language $lang): string
    {
        if (!$entityType) {
            return '';
        }
        try {
            $translated = $lang->translateLabel($entityType, 'scopeNames');
            return is_string($translated) && $translated !== '' ? $translated : $entityType;
        } catch (Throwable) {
            return $entityType;
        }
    }

    /**
     * @param array<string, string> $vars
     */
    private function renderTemplate(?string $tpl, array $vars): string
    {
        if (!is_string($tpl) || $tpl === '') {
            return '';
        }
        return trim(str_replace(array_keys($vars), array_values($vars), $tpl));
    }

    private function cleanText(string $text): string
    {
        $text = strip_tags($text);
        $text = preg_replace('/\[([^\]]+)\]\([^\)]+\)/', '$1', $text) ?? $text;
        $text = preg_replace('/(\*\*|__|\*|_|`)/', '', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    private function truncate(string $text, int $max): string
    {
        $text = trim($text);
        if (mb_strlen($text, 'UTF-8') <= $max) {
            return $text;
        }
        return rtrim(mb_substr($text, 0, $max - 3, 'UTF-8')) . '...';
    }

    private function getStore(): SubscriptionStore
    {
        return $this->store ??= new SubscriptionStore($this->entityManager);
    }
}
