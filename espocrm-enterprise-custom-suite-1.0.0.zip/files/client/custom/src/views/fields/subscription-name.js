﻿define('custom:views/fields/subscription-name', ['views/fields/varchar'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            this.nameRequest = 0;
            if (!this.model.isNew()) { return; }

            this.listenTo(this.model, 'change:planId change:planName change:productId change:productName change:clientId change:clientName change:billingPeriod', function () {
                this.fillSubscriptionName();
            });

            if (this.model.isNew() && (this.model.get('planId') || this.model.get('clientId') || this.model.get('productId'))) {
                this.fillSubscriptionName();
            }
        },

        generateName: function () {
            var clientName = (this.model.get('clientName') || '').trim();
            var planName = (this.model.get('planName') || '').trim();
            var productName = (this.model.get('productName') || '').trim();

            if (clientName && planName) {
                if (productName && planName.toLowerCase().indexOf(productName.toLowerCase()) === -1) {
                    return clientName + ' - ' + productName + ' (' + planName + ')';
                }
                return clientName + ' - ' + planName;
            }

            if (clientName && productName) {
                return clientName + ' - ' + productName + ' Subscription';
            }

            if (clientName) {
                return clientName + ' - Subscription';
            }

            if (productName && planName) {
                if (planName.toLowerCase().indexOf(productName.toLowerCase()) === -1) {
                    return productName + ' - ' + planName;
                }
                return planName;
            }

            if (planName) {
                return planName;
            }

            return '';
        },

        fillSubscriptionName: async function () {
            var current = (this.model.get('name') || '').trim();
            if (current && current !== this._lastAutoName) {
                return;
            }

            var name = this.generateName();
            if (!name && this.model.get('planId')) {
                var planId = this.model.get('planId');
                var request = ++this.nameRequest;
                try {
                    var plan = await Espo.Ajax.getRequest('CSubscriptionPlan/' + encodeURIComponent(planId));
                    if (request !== this.nameRequest || this.model.get('planId') !== planId) { return; }
                    if (plan && plan.name) {
                        this.model.set('planName', plan.name);
                        if (!this.model.get('productName') && plan.productName) {
                            this.model.set('productName', plan.productName);
                        }
                        name = this.generateName();
                    }
                } catch (e) {}
            }

            if (name) {
                this._lastAutoName = name;
                this.model.set('name', name);
            }
        }

    });

});
