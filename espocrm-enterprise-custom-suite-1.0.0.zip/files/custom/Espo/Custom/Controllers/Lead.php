<?php
namespace Espo\Custom\Controllers;

use Espo\Core\Api\Request;
use Espo\Core\Acl;
use Espo\Core\InjectableFactory;
use Espo\Core\Record\CreateParamsFetcher;
use Espo\Core\Record\DeleteParamsFetcher;
use Espo\Core\Record\FindParamsFetcher;
use Espo\Core\Record\ReadParamsFetcher;
use Espo\Core\Record\SearchParamsFetcher;
use Espo\Core\Record\ServiceContainer as RecordServiceContainer;
use Espo\Core\Record\UpdateParamsFetcher;
use Espo\Core\Utils\Config;
use Espo\Entities\User;
use Espo\ORM\EntityManager;
use stdClass;

class Lead extends \Espo\Modules\Crm\Controllers\Lead
{
    public function __construct(
        private EntityManager $entityManager,
        SearchParamsFetcher $searchParamsFetcher,
        CreateParamsFetcher $createParamsFetcher,
        ReadParamsFetcher $readParamsFetcher,
        UpdateParamsFetcher $updateParamsFetcher,
        DeleteParamsFetcher $deleteParamsFetcher,
        RecordServiceContainer $recordServiceContainer,
        FindParamsFetcher $findParamsFetcher,
        Config $config,
        User $user,
        Acl $acl,
        InjectableFactory $injectableFactory
    ) {
        parent::__construct(
            $searchParamsFetcher,
            $createParamsFetcher,
            $readParamsFetcher,
            $updateParamsFetcher,
            $deleteParamsFetcher,
            $recordServiceContainer,
            $findParamsFetcher,
            $config,
            $user,
            $acl,
            $injectableFactory
        );
    }

    public function postActionConvert(Request $request): stdClass
    {
        $data = $request->getParsedBody();
        $id = $data->id ?? null;
        $em = $this->entityManager;

        $existingCalls = [];
        $existingMeetings = [];
        if ($id && $em) {
            $existingCalls = $em->getRDBRepository('Call')
                ->where(['parentId' => $id, 'parentType' => 'Lead'])
                ->find();
            $existingMeetings = $em->getRDBRepository('Meeting')
                ->where(['parentId' => $id, 'parentType' => 'Lead'])
                ->find();
        }

        $result = parent::postActionConvert($request);

        // Preserve original Lead parent relationships on all pre-existing Calls and Meetings
        // Unresolved planned activities are explicitly preserved in their planned state without reassignment
        if ($id && $em) {
            foreach ($existingCalls as $call) {
                $c = $em->getEntityById('Call', $call->getId());
                if ($c) {
                    $c->set('parentId', $id);
                    $c->set('parentType', 'Lead');
                    $em->saveEntity($c);
                }
            }
            foreach ($existingMeetings as $meeting) {
                $m = $em->getEntityById('Meeting', $meeting->getId());
                if ($m) {
                    $m->set('parentId', $id);
                    $m->set('parentType', 'Lead');
                    $em->saveEntity($m);
                }
            }

            // Establish bidirectional relation between source Lead and generated Opportunity
            $oppId = $result->createdOpportunityId ?? ($em->getEntityById('Lead', $id)?->get('createdOpportunityId'));
            if ($oppId) {
                $opp = $em->getEntityById('Opportunity', $oppId);
                if ($opp && (!$opp->has('originalLeadId') || !$opp->get('originalLeadId'))) {
                    $opp->set('originalLeadId', $id);
                    $em->saveEntity($opp);
                }
            }
        }

        return $result;
    }

    public function postActionGetConvertAttributes(Request $request): stdClass
    {
        $values = parent::postActionGetConvertAttributes($request);

        foreach (['Account', 'Contact'] as $type) {
            if (isset($values->$type)) {
                unset($values->$type->cSubscriptionsIds, $values->$type->cSubscriptionsNames, $values->$type->cSubscriptionsColumns);
            }
        }

        $leadId = $request->getParsedBody()->id ?? null;
        if ($leadId) {
            $lead = $this->getRecordService()->getEntity($leadId);
            if ($lead) {
                $ids = [];
                $names = (object)[];
                if ($lead->hasLinkMultipleField('cProductServices')) {
                    try {
                        $lead->loadLinkMultipleField('cProductServices');
                    } catch (\Throwable $e) {}
                }
                $ids = $lead->getLinkMultipleIdList('cProductServices') ?: ($lead->get('cProductServicesIds') ?: []);
                $names = $lead->get('cProductServicesNames') ?: (object)[];

                $currentUser = $this->user ?? null;
                $currentUserId = $currentUser ? $currentUser->getId() : null;
                $currentUserName = $currentUser ? $currentUser->get('name') : null;

                $leadPersonName = (string) ($lead->get('name') ?: '');
                $leadAccountName = (string) ($lead->get('accountName') ?: '');
                $leadDisplayName = $leadAccountName ?: $leadPersonName;

                // Ensure Account attributes are prefilled from Lead
                if (isset($values->Account)) {
                    if (empty($values->Account->name)) {
                        $values->Account->name = $leadDisplayName;
                    }
                    if (empty($values->Account->website) && $lead->get('website')) {
                        $values->Account->website = $lead->get('website');
                    }
                    if (empty($values->Account->phoneNumber) && $lead->get('phoneNumber')) {
                        $values->Account->phoneNumber = $lead->get('phoneNumber');
                        $values->Account->phoneNumberData = $lead->get('phoneNumberData');
                    }
                    if (empty($values->Account->emailAddress) && $lead->get('emailAddress')) {
                        $values->Account->emailAddress = $lead->get('emailAddress');
                        $values->Account->emailAddressData = $lead->get('emailAddressData');
                    }
                    if (empty($values->Account->billingAddressStreet) && $lead->get('addressStreet')) {
                        $values->Account->billingAddressStreet = $lead->get('addressStreet');
                        $values->Account->billingAddressCity = $lead->get('addressCity');
                        $values->Account->billingAddressState = $lead->get('addressState');
                        $values->Account->billingAddressCountry = $lead->get('addressCountry');
                        $values->Account->billingAddressPostalCode = $lead->get('addressPostalCode');
                    }
                    if (empty($values->Account->cLeadSource) && $lead->get('source')) {
                        $values->Account->cLeadSource = $lead->get('source');
                    }
                    if (empty($values->Account->description) && $lead->get('description')) {
                        $values->Account->description = $lead->get('description');
                    }
                    $values->Account->assignedUserId = $currentUserId ?: ($lead->get('assignedUserId') ?? null);
                    $values->Account->assignedUserName = $currentUserName ?: ($lead->get('assignedUserName') ?? null);
                    if (empty($values->Account->teamsIds) && $lead->get('teamsIds')) {
                        $values->Account->teamsIds = $lead->get('teamsIds');
                        $values->Account->teamsNames = $lead->get('teamsNames');
                    }
                    if (!empty($ids)) {
                        $values->Account->cProductServicesIds = $ids;
                        $values->Account->cProductServicesNames = $names;
                    }
                }

                // Ensure Contact attributes are prefilled from Lead
                if (isset($values->Contact)) {
                    if (empty($values->Contact->firstName) && $lead->get('firstName')) {
                        $values->Contact->firstName = $lead->get('firstName');
                    }
                    if (empty($values->Contact->lastName)) {
                        $values->Contact->lastName = $lead->get('lastName') ?: ($lead->get('name') ?: 'Contact');
                    }
                    if (empty($values->Contact->name)) {
                        $values->Contact->name = $lead->get('name');
                    }
                    if (empty($values->Contact->title) && $lead->get('title')) {
                        $values->Contact->title = $lead->get('title');
                    }
                    if (empty($values->Contact->emailAddress) && $lead->get('emailAddress')) {
                        $values->Contact->emailAddress = $lead->get('emailAddress');
                        $values->Contact->emailAddressData = $lead->get('emailAddressData');
                    }
                    if (empty($values->Contact->phoneNumber) && $lead->get('phoneNumber')) {
                        $values->Contact->phoneNumber = $lead->get('phoneNumber');
                        $values->Contact->phoneNumberData = $lead->get('phoneNumberData');
                    }
                    if (empty($values->Contact->addressStreet) && $lead->get('addressStreet')) {
                        $values->Contact->addressStreet = $lead->get('addressStreet');
                        $values->Contact->addressCity = $lead->get('addressCity');
                        $values->Contact->addressState = $lead->get('addressState');
                        $values->Contact->addressCountry = $lead->get('addressCountry');
                        $values->Contact->addressPostalCode = $lead->get('addressPostalCode');
                    }
                    if (empty($values->Contact->cLeadSource) && $lead->get('source')) {
                        $values->Contact->cLeadSource = $lead->get('source');
                    }
                    if (empty($values->Contact->cWebsite) && $lead->get('website')) {
                        $values->Contact->cWebsite = $lead->get('website');
                    }
                    if (empty($values->Contact->description) && $lead->get('description')) {
                        $values->Contact->description = $lead->get('description');
                    }
                    $values->Contact->assignedUserId = $currentUserId ?: ($lead->get('assignedUserId') ?? null);
                    $values->Contact->assignedUserName = $currentUserName ?: ($lead->get('assignedUserName') ?? null);
                    if (empty($values->Contact->teamsIds) && $lead->get('teamsIds')) {
                        $values->Contact->teamsIds = $lead->get('teamsIds');
                        $values->Contact->teamsNames = $lead->get('teamsNames');
                    }
                    if (!empty($ids)) {
                        $values->Contact->cProductServicesIds = $ids;
                        $values->Contact->cProductServicesNames = $names;
                    }
                }

                // Ensure Opportunity attributes are prefilled from Lead
                if (isset($values->Opportunity)) {
                    $selectedProdName = '';
                    if (!empty($ids)) {
                        $pId = $ids[0];
                        $pName = is_object($names) ? ($names->$pId ?? '') : ($names[$pId] ?? '');
                        $values->Opportunity->cProductServiceId = $pId;
                        $values->Opportunity->cProductServiceName = $pName;
                        $values->Opportunity->cWonProductId = $pId;
                        $values->Opportunity->cWonProductName = $pName;

                        try {
                            $prod = $this->getRecordService('CProductService')->getEntity($pId);
                            if ($prod) {
                                if (!$pName) {
                                    $values->Opportunity->cProductServiceName = $prod->get('name');
                                    $values->Opportunity->cWonProductName = $prod->get('name');
                                }
                                $selectedProdName = (string) $values->Opportunity->cProductServiceName;
                                $values->Opportunity->cProductServiceType = $prod->get('type');
                                if ($prod->get('price') !== null) {
                                    $values->Opportunity->cWonOriginalAmount = (float)$prod->get('price');
                                }
                                if (empty($values->Opportunity->amount)) {
                                    if ($lead->has('opportunityAmount') && $lead->get('opportunityAmount') !== null && $lead->get('opportunityAmount') !== '') {
                                        $values->Opportunity->amount = (float)$lead->get('opportunityAmount');
                                        if ($lead->has('opportunityAmountCurrency') && $lead->get('opportunityAmountCurrency')) {
                                            $values->Opportunity->amountCurrency = $lead->get('opportunityAmountCurrency');
                                        }
                                    } else if ($prod->get('price') !== null) {
                                        $values->Opportunity->amount = (float)$prod->get('price');
                                        if ($prod->get('priceCurrency')) {
                                            $values->Opportunity->amountCurrency = $prod->get('priceCurrency');
                                        }
                                    }
                                }
                            }
                        } catch (\Throwable $e) {}
                    } else {
                        $values->Opportunity->cProductServiceId = null;
                        $values->Opportunity->cProductServiceName = null;
                        $values->Opportunity->cProductServiceType = null;
                        $values->Opportunity->cWonProductId = null;
                        $values->Opportunity->cWonProductName = null;
                        $values->Opportunity->cWonOriginalAmount = null;
                        if (empty($values->Opportunity->amount) && $lead->has('opportunityAmount') && $lead->get('opportunityAmount') !== null && $lead->get('opportunityAmount') !== '') {
                            $values->Opportunity->amount = (float)$lead->get('opportunityAmount');
                            if ($lead->has('opportunityAmountCurrency') && $lead->get('opportunityAmountCurrency')) {
                                $values->Opportunity->amountCurrency = $lead->get('opportunityAmountCurrency');
                            }
                        }
                    }

                    // Format: Lead Name + Account Name + Product/Service Name + deal -> "LeadName - AccountName - ProductName - deal"
                    $values->Opportunity->name = $this->buildOpportunityName($leadPersonName, $leadAccountName, $selectedProdName);

                    if (empty($values->Opportunity->leadSource) && $lead->get('source')) {
                        $values->Opportunity->leadSource = $lead->get('source');
                    }
                    if (empty($values->Opportunity->description) && $lead->get('description')) {
                        $values->Opportunity->description = $lead->get('description');
                    }
                    if (empty($values->Opportunity->closeDate)) {
                        $values->Opportunity->closeDate = date('Y-m-d');
                    }
                    $values->Opportunity->assignedUserId = $currentUserId ?: ($lead->get('assignedUserId') ?? null);
                    $values->Opportunity->assignedUserName = $currentUserName ?: ($lead->get('assignedUserName') ?? null);
                    if (empty($values->Opportunity->teamsIds) && $lead->get('teamsIds')) {
                        $values->Opportunity->teamsIds = $lead->get('teamsIds');
                        $values->Opportunity->teamsNames = $lead->get('teamsNames');
                    }
                }
            }
        }

        return $values;
    }

    private function buildOpportunityName(?string $leadName, ?string $accountName = null, ?string $productName = null): string
    {
        $leadName = trim((string) $leadName);
        $accountName = trim((string) $accountName);
        $productName = trim((string) $productName);

        $parts = [];
        if ($leadName !== '') {
            $parts[] = $leadName;
        }
        if ($accountName !== '' && strcasecmp($accountName, $leadName) !== 0) {
            $parts[] = $accountName;
        }
        if ($productName !== '') {
            $parts[] = $productName;
        }

        if (!empty($parts)) {
            return implode(' - ', $parts) . ' - deal';
        }

        return 'Opportunity - deal';
    }
}
