<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["ActivityMonitor","CProductService","CSubscriptionPlan","CClientSubscription"];
            $tabList = $config->get('tabList') ?? [];
            $modified = false;
            foreach ($tabs as $tab) {
                if (!in_array($tab, $tabList)) {
                    $tabList[] = $tab;
                    $modified = true;
                }
            }
            if ($modified) {
                $configWriter->set('tabList', $tabList);
                $configWriter->save();
            }


            $scopes = [
                'Account' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Contact' => ['panel' => 'cSubscriptions', 'index' => 10],
                'Lead' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Opportunity' => ['panel' => 'cWonSubscriptions', 'index' => 110]
            ];
            foreach ($scopes as $scope => $info) {
                $file = "custom/Espo/Custom/Resources/layouts/{$scope}/bottomPanelsDetail.json";
                $panelName = $info['panel'];
                $data = [];
                if (file_exists($file)) {
                    $json = @json_decode(file_get_contents($file), true);
                    if (is_array($json)) $data = $json;
                }
                if (!isset($data[$panelName]) || !empty($data[$panelName]['disabled'])) {
                    $data[$panelName] = ['disabled' => false, 'index' => $info['index']];
                    if (!is_dir(dirname($file))) @mkdir(dirname($file), 0777, true);
                    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                }
            }
            try {
                $dataManager = $container->getByClass(\Espo\Core\DataManager::class) ?? $container->get('dataManager');
                if ($dataManager && method_exists($dataManager, 'clearCache')) {
                    $dataManager->clearCache();
                }
            } catch (\Throwable $e) {}
        

            if (class_exists(\Espo\Custom\WebPush\VapidKeys::class)) {
                (new \Espo\Custom\WebPush\VapidKeys())->isConfigured();
            }
            $customClientJson = 'custom/Espo/Custom/Resources/metadata/app/client.json';
            if (is_file($customClientJson)) {
                $cd = json_decode((string) file_get_contents($customClientJson), true);
                if (is_array($cd) && isset($cd['scriptList']) && is_array($cd['scriptList'])) {
                    $filtered = array_values(array_filter($cd['scriptList'], fn ($s) => $s !== 'client/custom/src/web-push.js'));
                    if (count($filtered) !== count($cd['scriptList'])) {
                        if ($filtered === []) {
                            unset($cd['scriptList']);
                        } else {
                            $cd['scriptList'] = $filtered;
                        }
                        unset($cd['developerModeScriptList']);
                        file_put_contents($customClientJson, json_encode($cd, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                    }
                }
            }
            if (!$container->has('user')) {
                $appUser = $container->getByClass(\Espo\Core\ApplicationUser::class);
                if ($appUser) {
                    $appUser->setupSystemUser();
                }
            }
            $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
            foreach ([
                'CallRouteReminders' => 'Call Route Reminders',
                'MeetingReminders' => 'Meeting Reminders',
                'PopupRemindersPush' => 'Popup Reminders Web Push',
            ] as $jobKey => $jobName) {
                $existingJob = $em->getRDBRepository('ScheduledJob')->where(['job' => $jobKey, 'deleted' => false])->findOne();
                if (!$existingJob) {
                    $sj = $em->getNewEntity('ScheduledJob');
                    $sj->set([
                        'name' => $jobName,
                        'job' => $jobKey,
                        'status' => 'Active',
                        'scheduling' => '* * * * *',
                    ]);
                    $em->saveEntity($sj, ['silent' => true]);
                }
            }


            $brandChanged = false;
            $currentAppName = (string) ($config->get('applicationName') ?? '');
            if ($currentAppName === '' || $currentAppName === 'EspoCRM') {
                $configWriter->set('applicationName', 'CGIT CRM');
                $brandChanged = true;
            }
            $currentAppDesc = (string) ($config->get('applicationDescription') ?? '');
            if ($currentAppDesc === '' || str_starts_with($currentAppDesc, 'EspoCRM')) {
                $configWriter->set('applicationDescription', 'CGIT CRM — Business & Customer Management Platform.');
                $brandChanged = true;
            }
            $currentFromName = (string) ($config->get('outboundEmailFromName') ?? '');
            if ($currentFromName === '' || $currentFromName === 'EspoCRM') {
                $configWriter->set('outboundEmailFromName', 'CGIT CRM');
                $brandChanged = true;
            }
            if ($brandChanged) {
                $configWriter->save();
            }

        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
