define('custom:handlers/sales-defaults-preparator', ['handlers/model/defaults-preparator'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return class extends Dep {

        prepare(model) {
            try {
                if (!model || typeof model.hasField !== 'function' || !model.hasField('assignedUser')) {
                    return {};
                }

                if (model.get('assignedUserId')) {
                    return {};
                }

                var viewHelper = this.viewHelper;
                if (!viewHelper) {
                    return {};
                }

                var user = typeof viewHelper.getUser === 'function' ?
                    viewHelper.getUser() : viewHelper.user;

                if (!user || !user.id || typeof user.get !== 'function') {
                    return {};
                }

                return {
                    assignedUserId: user.id,
                    assignedUserName: user.get('name')
                };
            } catch (e) {
                return {};
            }
        }

    };

});
