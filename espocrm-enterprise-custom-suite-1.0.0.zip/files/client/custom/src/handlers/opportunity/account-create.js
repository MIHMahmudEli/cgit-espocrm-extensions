define('custom:handlers/opportunity/account-create', ['handlers/create-related'], function (Dep) {

    var BaseClass = (Dep && Dep.default) || Dep || class {};

    return class extends BaseClass {

        constructor(viewHelper, options) {
            super(viewHelper);
            this.options = options || {};
        }

        async fetchLead(model) {
            try {
                if (!model) return null;
                var leadId = typeof model.get === 'function' ? model.get('originalLeadId') : model.originalLeadId;
                if (!leadId && model.id && typeof Espo !== 'undefined' && Espo.Ajax) {
                    var res = await Espo.Ajax.getRequest('Lead', {
                        where: [
                            {
                                type: 'equals',
                                attribute: 'createdOpportunityId',
                                value: model.id
                            }
                        ],
                        maxSize: 1
                    });
                    if (res && res.list && res.list.length > 0 && res.list[0].id) {
                        leadId = res.list[0].id;
                    }
                }
                if (leadId && typeof Espo !== 'undefined' && Espo.Ajax) {
                    return await Espo.Ajax.getRequest('Lead/' + encodeURIComponent(leadId));
                }
            } catch (e) {}
            return null;
        }

        async getAttributes(model, link) {
            try {
                var attributes = {};
                if (!model) return attributes;

                var lead = await this.fetchLead(model);

                // 1. Account Name
                if (lead && lead.accountName) {
                    attributes.name = lead.accountName;
                } else if (typeof model.get === 'function' && model.get('accountName')) {
                    attributes.name = model.get('accountName');
                } else if (typeof model.get === 'function' && model.get('name')) {
                    var oppName = model.get('name');
                    if (oppName.endsWith(' - Opportunity')) {
                        attributes.name = oppName.slice(0, -' - Opportunity'.length);
                    } else {
                        attributes.name = oppName;
                    }
                } else if (lead && lead.name) {
                    attributes.name = lead.name;
                }

                // 2. Product Services
                var prodId = typeof model.get === 'function' ? (model.get('cProductServiceId') || model.get('cWonProductId')) : null;
                var prodName = typeof model.get === 'function' ? (model.get('cProductServiceName') || model.get('cWonProductName')) : null;
                if (prodId) {
                    attributes.cProductServicesIds = [prodId];
                    if (prodName) {
                        attributes.cProductServicesNames = {};
                        attributes.cProductServicesNames[prodId] = prodName;
                    }
                } else if (lead && Array.isArray(lead.cProductServicesIds) && lead.cProductServicesIds.length) {
                    attributes.cProductServicesIds = lead.cProductServicesIds.slice();
                    if (lead.cProductServicesNames && typeof lead.cProductServicesNames === 'object') {
                        attributes.cProductServicesNames = Object.assign({}, lead.cProductServicesNames);
                    }
                }

                // 3. Lead Source
                var leadSource = (typeof model.get === 'function' ? model.get('leadSource') : null) || (lead && lead.source);
                if (leadSource) {
                    attributes.cLeadSource = leadSource;
                }

                // 4. Assigned User
                var assignedUserId = (typeof model.get === 'function' ? model.get('assignedUserId') : null) || (lead && lead.assignedUserId);
                var assignedUserName = (typeof model.get === 'function' ? model.get('assignedUserName') : null) || (lead && lead.assignedUserName);
                if (assignedUserId) {
                    attributes.assignedUserId = assignedUserId;
                    if (assignedUserName) {
                        attributes.assignedUserName = assignedUserName;
                    }
                }

                // 5. Teams
                var teamsIds = (typeof model.get === 'function' ? model.get('teamsIds') : null) || (lead && lead.teamsIds);
                var teamsNames = (typeof model.get === 'function' ? model.get('teamsNames') : null) || (lead && lead.teamsNames);
                if (Array.isArray(teamsIds) && teamsIds.length) {
                    attributes.teamsIds = teamsIds.slice();
                    if (teamsNames && typeof teamsNames === 'object') {
                        attributes.teamsNames = Object.assign({}, teamsNames);
                    }
                }

                // 6. Description
                var description = (lead && lead.description) || (typeof model.get === 'function' ? model.get('description') : null);
                if (description) {
                    attributes.description = description;
                }

                // 7. Lead Account Info
                if (lead) {
                    if (lead.emailAddress) {
                        attributes.emailAddress = lead.emailAddress;
                        if (lead.emailAddressData) {
                            attributes.emailAddressData = lead.emailAddressData;
                        }
                    }
                    if (lead.phoneNumber) {
                        attributes.phoneNumber = lead.phoneNumber;
                        if (lead.phoneNumberData) {
                            attributes.phoneNumberData = lead.phoneNumberData;
                        }
                    }
                    if (lead.addressStreet) attributes.billingAddressStreet = lead.addressStreet;
                    if (lead.addressCity) attributes.billingAddressCity = lead.addressCity;
                    if (lead.addressState) attributes.billingAddressState = lead.addressState;
                    if (lead.addressCountry) attributes.billingAddressCountry = lead.addressCountry;
                    if (lead.addressPostalCode) attributes.billingAddressPostalCode = lead.addressPostalCode;

                    if (lead.website) attributes.website = lead.website;
                    if (lead.industry) attributes.industry = lead.industry;
                }

                return attributes;
            } catch (err) {
                return {};
            }
        }

    };

});
