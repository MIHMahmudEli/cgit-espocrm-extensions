define('custom:views/fields/subscription-change-reason', ['views/fields/enum'], function (Dep) {

    return Dep.extend({

        setup: function () {
            if (this.isSearchMode()) {
                Dep.prototype.setup.call(this);
                return;
            }

            this.originalReason = this.model.get(this.name);
            this.originalPlan = this.model.get('planId');

            if (this.model.isNew()) {
                if (!this.model.get(this.name)) {
                    this.model.set(this.name, 'Initial');
                }
                if (this.isEditMode() && !this.options.auditData) {
                    this.readOnly = true;
                }
            } else {
                this.required = true;
            }

            Dep.prototype.setup.call(this);

            if (!this.model.isNew() && this.params) {
                this.params.required = true;
            }

            this.validations = this.validations.concat(['transition']);

            this.listenTo(this.model, 'sync', function () {
                this.originalReason = this.model.get(this.name);
                this.originalPlan = this.model.get('planId');
            });

            this.listenTo(this.model, 'change:planId', function (model, value, options) {
                if (this.model.isNew() || !options || !options.ui) return;
                this.model.set(this.name, this.model.get('planId') === this.originalPlan ? this.originalReason : null);
            });
        },

        data: function () {
            const data = Dep.prototype.data.call(this);
            if (this.isEditMode() && !this.model.isNew()) {
                if (data.value === 'Initial' || !['Upgrade', 'Downgrade'].includes(data.value)) {
                    data.value = '';
                }
            }
            return data;
        },

        setupOptions: function () {
            if (this.isSearchMode()) return;

            if (this.options.auditData) {
                this.params.options = ['Initial', 'Upgrade', 'Downgrade', 'Change', 'Legacy import'];
                return;
            }

            if (this.model.isNew()) {
                this.params.options = ['Initial'];
            } else {
                // For any existing subscription update/edit, Initial is strictly excluded
                this.params.options = ['Upgrade', 'Downgrade'];
            }
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            if (this.isEditMode()) {
                if (this.model.isNew()) {
                    if (this.$element) {
                        this.$element.find('option:not([value="Initial"])').remove();
                        this.$element.val('Initial');
                    }
                } else {
                    if (this.$element) {
                        this.$element.find('option[value="Initial"], option[value="Change"], option[value="Legacy import"]').remove();
                    }
                }
            }
        },

        fetch: function () {
            if (this.isEditMode() && this.model.isNew()) {
                return { [this.name]: 'Initial' };
            }

            const result = Dep.prototype.fetch.call(this);
            if (!result[this.name] && this.model.get('planId') === this.originalPlan && !this.model.isNew() && ['Upgrade', 'Downgrade'].includes(this.originalReason)) {
                result[this.name] = this.originalReason;
            }
            return result;
        },

        validateTransition: function () {
            if (this.isEditMode() && !this.model.isNew()) {
                var currentVal = this.model.get(this.name);
                if (!['Upgrade', 'Downgrade'].includes(currentVal)) {
                    this.showValidationMessage('Choose Upgrade or Downgrade.');
                    return true;
                }
            }
            return false;
        }

    });

});
