define('custom:views/record/panels/activities', ['crm:views/record/panels/activities'], function (Dep) {

    return Dep.extend({

        setup: function () {
            this.listLayout = {
                'Email': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true }
                    ], [
                        { name: 'dateSent', soft: true },
                        { name: 'from' },
                        { name: 'hasAttachment', view: 'views/email/fields/has-attachment' }
                    ]]
                },
                'Call': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'description' }
                    ]]
                },
                'Meeting': {
                    rows: [[
                        { name: 'ico', view: 'crm:views/fields/ico' },
                        { name: 'name', link: true, view: 'views/event/fields/name-for-history' }
                    ], [
                        { name: 'dateStart', soft: true },
                        { name: 'assignedUser' },
                        { name: 'status', soft: true }
                    ], [
                        { name: 'description' }
                    ]]
                }
            };

            Dep.prototype.setup.call(this);

            this.applyProductServiceFilter();
            this.setupAutoRefresh();
        },

        /**
         * Narrow the activities list down to the product service(s) of the record
         * this panel is shown on. Records without a product-service field keep
         * the unfiltered activities.
         */
        applyProductServiceFilter: function () {
            if (!this.collection) {
                return;
            }

            var idList = this.model.get('cProductServicesIds');

            if (!idList && this.model.get('cProductServiceId')) {
                idList = [this.model.get('cProductServiceId')];
            }

            if (Array.isArray(idList) && idList.length) {
                this.collection.data.productServiceIds = idList.join(',');
            } else {
                delete this.collection.data.productServiceIds;
            }
        },

        /**
         * Auto-refresh activities panel when the model is saved.
         */
        setupAutoRefresh: function () {
            this.listenTo(this.model, 'after:save', function () {
                if (this.activitiesRefreshTimer) {
                    clearTimeout(this.activitiesRefreshTimer);
                }

                this.activitiesRefreshTimer = setTimeout(function () {
                    this.activitiesRefreshTimer = null;

                    if (!this.collection) {
                        return;
                    }

                    this.applyProductServiceFilter();
                    this.collection.fetch();
                }.bind(this), 150);
            }.bind(this));
        },

        onRemove: function () {
            if (this.activitiesRefreshTimer) {
                clearTimeout(this.activitiesRefreshTimer);
                this.activitiesRefreshTimer = null;
            }

            if (Dep.prototype.onRemove) {
                Dep.prototype.onRemove.call(this);
            }
        }

    });

});
