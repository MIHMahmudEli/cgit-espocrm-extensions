<div class="header page-header">{{{header}}}</div>

<div class="convert-lead-container">
    <div class="panel panel-default opportunity-convert-panel">
        <div class="panel-heading" style="background: #f8f9fa; border-bottom: 1px solid #e9ecef; padding: 12px 15px;">
            <h4 class="panel-title" style="font-weight: 600; font-size: 16px; margin: 0; display: flex; align-items: center;">
                <span class="fas fa-bullseye text-primary" style="margin-right: 8px;"></span>
                <span>{{translate 'Opportunity' category='scopeNames'}}</span>
            </h4>
        </div>
        <div class="panel-body" style="padding: 15px;">
            <!-- Opportunity Edit Form -->
            <div class="edit-container-opportunity">
                {{{var 'Opportunity' this}}}
            </div>

            <!-- Client Information: Account & Contact (inside Opportunity section, shown only on Closed Won) -->
            <div class="opportunity-client-convert-container margin-top {{#unless isClosedWon}}hide{{/unless}}" style="margin-top: 25px; border-top: 2px dashed #cbd5e1; padding-top: 20px;">
                <div class="alert alert-info" style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 20px;">
                    <span class="fas fa-info-circle fa-lg" style="margin-top: 2px;"></span>
                    <div>
                        <strong>Client Information (Account & Contact)</strong>: 
                        {{clientHelpText}}
                    </div>
                </div>

                <!-- Account Subsection -->
                <div class="client-scope-box panel panel-default" style="border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <div class="panel-heading" style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 10px 15px;">
                        <label style="user-select: none; cursor: default; margin-bottom: 0; display: flex; align-items: center; gap: 8px;" class="text-large text-bold">
                            <input
                                type="checkbox"
                                class="check-client-scope form-checkbox"
                                data-scope="Account"
                                checked
                                disabled
                            >
                            <span class="fas fa-building text-primary"></span>
                            <span>{{translate 'Account' category='scopeNames'}} (Company / Organization)</span>
                            <span class="label label-danger text-bold" style="font-size: 11px; margin-left: 5px;">Required</span>
                        </label>
                    </div>
                    <div class="panel-body edit-container-account" style="padding: 15px;">
                        {{{var 'Account' this}}}
                    </div>
                </div>

                <!-- Contact Subsection -->
                <div class="client-scope-box panel panel-default" style="border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <div class="panel-heading" style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 10px 15px;">
                        <label style="user-select: none; cursor: default; margin-bottom: 0; display: flex; align-items: center; gap: 8px;" class="text-large text-bold">
                            <input
                                type="checkbox"
                                class="check-client-scope form-checkbox"
                                data-scope="Contact"
                                checked
                                disabled
                            >
                            <span class="fas fa-user text-primary"></span>
                            <span>{{translate 'Contact' category='scopeNames'}} (Primary Contact Person)</span>
                            <span class="label label-danger text-bold" style="font-size: 11px; margin-left: 5px;">Required</span>
                        </label>
                    </div>
                    <div class="panel-body edit-container-contact" style="padding: 15px;">
                        {{{var 'Contact' this}}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="button-container margin-top">
    <div class="btn-group">
        <button class="btn btn-primary" data-action="convert" style="min-width: 120px;">{{translate 'Convert' scope='Lead'}}</button>
        <button class="btn btn-default" data-action="cancel">{{translate 'Cancel'}}</button>
    </div>
</div>
