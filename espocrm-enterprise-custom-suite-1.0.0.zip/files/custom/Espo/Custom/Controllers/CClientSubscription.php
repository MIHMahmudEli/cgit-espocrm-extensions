<?php
namespace Espo\Custom\Controllers;
class CClientSubscription extends \Espo\Core\Templates\Controllers\Base {}
