define('custom:views/opportunity/record/edit', ['crm:views/opportunity/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            this.productTypeCache = this.productTypeCache || {};
            this.isSubdomainManuallyEdited = false;
            this.initialStage = this.model ? this.model.get('stage') : null;

            if (this.model.isNew()) {
                var initialName = this.model.get('name');
                if (initialName && (
                    initialName.endsWith(' - Opportunity') ||
                    initialName === 'Opportunity' ||
                    initialName === this.model.get('accountName')
                )) {
                    this.model.set('name', '');
                }
            }

            this.listenTo(this.model, 'change:accountName change:accountId change:contactsNames change:leadName', function () {
                this.updateNamePlaceholder();
                if (this.model.get('stage') === 'Closed Won') {
                    this.updateSubdomainValue(true);
                }
            });

            this.listenTo(this.model, 'change:cProductServiceName change:cProductServiceId change:cWonProductName change:cWonProductId', async function (model, val, options) {
                this.updateNamePlaceholder();
                var pId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                if (pId && /^[a-z0-9]{17}$/i.test(pId)) {
                    await this.ensureProductData(pId);
                }
                if (this.model.get('stage') === 'Closed Won') {
                    this.manageWonSubscriptionPanels();
                    this.updateSubdomainValue(true);
                    if (pId && (!options || !options.fromProductService) && (this.model.isNew() || (options && options.ui)) && !this.model.get('cWonPlanId') && this.getProductType(pId) === 'Subscription') {
                        this.checkAndPromptPlans(pId);
                    }
                }
            });

            this.listenTo(this.model, 'change:stage', async function (model, stage) {
                this.updateNamePlaceholder();
                this.manageWonSubscriptionPanels();
                if (stage === 'Closed Won') {
                    await this.handleClosedWonStage();
                    var pId2 = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                    if (pId2) {
                        await this.ensureProductData(pId2);
                        this.manageWonSubscriptionPanels();
                        this.updateSubdomainValue(true);
                        if (!this.model.get('cWonPlanId') && this.getProductType(pId2) === 'Subscription') {
                            this.checkAndPromptPlans(pId2);
                        }
                    } else {
                        this.updateSubdomainValue(true);
                    }
                } else {
                    if (this.model.get('cWonHasDiscount')) {
                        var orig = parseFloat(this.model.get('cWonOriginalAmount'));
                        if (!isNaN(orig) && orig > 0) {
                            this.model.set('amount', orig);
                        }
                        this.model.set('cWonHasDiscount', false);
                    }
                    if (this.productTypeCache && this.productTypeCache[this.model.get('cProductServiceId')] !== 'Subscription') {
                        this.isAmountLockedByProduct = false;
                        this.unlockAmountField();
                    }
                }
            });

            this.listenTo(this.model, 'change:cWonHasDiscount change:cWonDiscountType change:cWonDiscountPercent change:cWonDiscountAmount', function () {
                this.recalculateDiscount();
            });

            this.listenTo(this.model, 'change:cSubdomain', function (model, val, options) {
                if (options && options.fromAutoSubdomain) {
                    return;
                }
                if (options && options.ui) {
                    this.isSubdomainManuallyEdited = true;
                }
            });

            this.listenTo(this.model, 'change:accountId change:accountName', function () {
                this.updateSubdomainValue(true);
            });

            this.listenTo(this.model, 'change:cProductServiceId', function (model, id, options) {
                if (options && options.fromProductAmount) {
                    return;
                }
                this.handleProductAmount(id);
            });

            this.listenTo(this.model, 'change:cWonProductId', function (model, id, options) {
                if (id && (!options || !options.fromProductAmount)) {
                    this.handleProductAmount(id);
                }
            });

            var initialProductId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            if (initialProductId) {
                this.handleProductAmount(initialProductId, { initial: true });
            }
        },

        handleClosedWonStage: async function () {
            this.updateSubdomainValue();

            if (!this.model.isNew() && this.initialStage === 'Closed Won') {
                this.isAmountLockedByProduct = true;
                this.lockAmountField();
            }

            // Auto-fill Account and Contact if empty when stage is Closed Won
            var leadId = this.model.get('leadId') || this.model.get('originalLeadId');
            if (leadId && typeof Espo !== 'undefined' && Espo.Ajax) {
                try {
                    var lead = await Espo.Ajax.getRequest('Lead/' + encodeURIComponent(leadId));
                    if (lead) {
                        if (!this.model.get('accountId') && lead.accountId) {
                            this.model.set({
                                accountId: lead.accountId,
                                accountName: lead.accountName
                            });
                        } else if (!this.model.get('accountId') && (lead.accountName || lead.name)) {
                            this.model.set('accountName', lead.accountName || lead.name);
                        }
                        if (!this.model.get('contactId') && lead.contactId) {
                            var cIds = this.model.get('contactsIds') || [];
                            var cNames = this.model.get('contactsNames') || {};
                            if (!cIds.includes(lead.contactId)) {
                                cIds = cIds.concat([lead.contactId]);
                                cNames[lead.contactId] = lead.contactName || lead.name;
                            }
                            this.model.set({
                                contactId: lead.contactId,
                                contactName: lead.contactName || lead.name,
                                contactsIds: cIds,
                                contactsNames: cNames
                            });
                        }
                    }
                } catch (e) {}
            }

            if (this.model.get('accountId') && (!this.model.get('contactId') || !this.model.get('contactsIds') || this.model.get('contactsIds').length === 0) && typeof Espo !== 'undefined' && Espo.Ajax) {
                try {
                    var contRes = await Espo.Ajax.getRequest('Contact', {
                        where: [{ type: 'equals', attribute: 'accountId', value: this.model.get('accountId') }],
                        maxSize: 1
                    });
                    if (contRes && contRes.list && contRes.list.length > 0) {
                        var c = contRes.list[0];
                        var cIds2 = this.model.get('contactsIds') || [];
                        var cNames2 = this.model.get('contactsNames') || {};
                        if (!cIds2.includes(c.id)) {
                            cIds2 = cIds2.concat([c.id]);
                            cNames2[c.id] = c.name;
                        }
                        this.model.set({
                            contactId: c.id,
                            contactName: c.name,
                            contactsIds: cIds2,
                            contactsNames: cNames2
                        });
                    }
                } catch (e) {}
            } else if (this.model.get('contactId') && !this.model.get('accountId') && typeof Espo !== 'undefined' && Espo.Ajax) {
                try {
                    var cObj = await Espo.Ajax.getRequest('Contact/' + encodeURIComponent(this.model.get('contactId')));
                    if (cObj && cObj.accountId) {
                        this.model.set({
                            accountId: cObj.accountId,
                            accountName: cObj.accountName
                        });
                    }
                } catch (e) {}
            }
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            this.updateNamePlaceholder();
            this.updateDescriptionPlaceholder();
            this.updateSubdomainPlaceholder();

            this.$el.on('input.oppName keyup.oppName', 'input[data-name="name"]', function () {
                this.isNameManuallyEdited = true;
            }.bind(this));

            this.setupDiscountLiveCalculation();

            var nameView = this.getFieldView('name');
            if (nameView) {
                this.listenTo(nameView, 'after:render', this.updateNamePlaceholder.bind(this));
            }

            var descView = this.getFieldView('description');
            if (descView) {
                this.listenTo(descView, 'after:render', this.updateDescriptionPlaceholder.bind(this));
            }

            var subdomainView = this.getFieldView('cSubdomain');
            if (subdomainView) {
                this.listenTo(subdomainView, 'after:render', this.updateSubdomainPlaceholder.bind(this));
            }

            var amountView = this.getFieldView('amount');
            if (amountView) {
                this.listenTo(amountView, 'after:render', function () {
                    if (this.isAmountLockedByProduct) {
                        this.lockAmountField();
                    }
                }.bind(this));
            }

            if (!this.model.isNew() && this.initialStage === 'Closed Won') {
                this.isAmountLockedByProduct = true;
                this.lockAmountField();
            } else if (this.isAmountLockedByProduct) {
                this.lockAmountField();
            }

            this.manageWonSubscriptionPanels();

            if (this.model.get('stage') === 'Closed Won') {
                this.handleClosedWonStage();
                var prodIdInit = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                if (prodIdInit) {
                    this.ensureProductData(prodIdInit).then(() => {
                        this.updateSubdomainValue(true);
                        if (!this.model.get('cWonPlanId') && this.model.get('stage') === 'Closed Won') {
                            this.checkAndPromptPlans(prodIdInit);
                        }
                    });
                } else {
                    this.updateSubdomainValue(true);
                }
            }
        },

        validate: function () {
            var name = (this.model.get('name') || '').trim();
            if (!name) {
                var autoName = (typeof this.getNamePlaceholder === 'function')
                    ? this.getNamePlaceholder().replace(/^e\.g\.\s*/i, '').replace(/\.\.\.$/, '').trim()
                    : '';
                if (autoName) {
                    this.model.set('name', autoName);
                }
            }

            var hasError = false;
            if (Dep.prototype.validate) {
                hasError = Dep.prototype.validate.call(this);
            }

            if (this.model.get('stage') === 'Closed Won' && this.hasSubscriptionScope() && this.getProductType() === 'Subscription') {
                var sub = (this.model.get('cSubdomain') || '').trim();
                var rootPart = this.getRootDomainPart();
                var isInvalidSubdomain = !sub || sub === rootPart || sub.startsWith('.') || !sub.includes('.') || sub.indexOf('.') === 0 || sub.split('.')[0].trim() === '';

                if (isInvalidSubdomain) {
                    hasError = true;
                    var msg = 'Please enter the subdomain.';
                    if (typeof this.translate === 'function') {
                        msg = this.translate('Please enter the subdomain.', 'messages', 'Opportunity') || msg;
                    }
                    if (typeof Espo !== 'undefined' && Espo.Ui && typeof Espo.Ui.warning === 'function') {
                        Espo.Ui.warning(msg);
                    }
                    if (typeof this.showValidationMessage === 'function') {
                        this.showValidationMessage('cSubdomain', msg);
                    }
                }
            }

            if (this.model.get('stage') === 'Closed Won' && this.model.get('cWonHasDiscount')) {
                var type = this.model.get('cWonDiscountType') || 'Percentage';
                var origAmt = this.parseNumeric(this.model.get('cWonOriginalAmount'));
                if (isNaN(origAmt) || origAmt <= 0) {
                    origAmt = this.parseNumeric(this.model.get('cProductServicePrice'));
                }
                if (isNaN(origAmt) || origAmt <= 0) {
                    origAmt = this.parseNumeric(this.model.get('amount'));
                }
                if (isNaN(origAmt)) {
                    origAmt = 0.0;
                }

                if (type === 'Percentage') {
                    var pctRaw = this.$el ? this.$el.find('input[data-name="cWonDiscountPercent"]').val() : null;
                    var pct = (pctRaw !== undefined && pctRaw !== null && pctRaw !== '')
                        ? this.parseNumeric(pctRaw)
                        : this.parseNumeric(this.model.get('cWonDiscountPercent'));
                    if (isNaN(pct)) {
                        pct = 0.0;
                    }
                    if (pct < 0 || pct > 100) {
                        var pctMsg = 'Percentage discount must be between 0% and 100%.';
                        this.showDiscountValidationWarning(pctMsg, 'cWonDiscountPercent');
                        hasError = true;
                    }
                } else if (type === 'Amount') {
                    var amtRaw = this.$el ? this.$el.find('input[data-name="cWonDiscountAmount"]').val() : null;
                    var amt = (amtRaw !== undefined && amtRaw !== null && amtRaw !== '')
                        ? this.parseNumeric(amtRaw)
                        : this.parseNumeric(this.model.get('cWonDiscountAmount'));
                    if (isNaN(amt)) {
                        amt = 0.0;
                    }
                    if (amt < 0) {
                        this.showDiscountValidationWarning('Discount amount cannot be negative.', 'cWonDiscountAmount');
                        hasError = true;
                    } else if (amt > origAmt) {
                        this.showDiscountValidationWarning('Fixed discount cannot exceed the original amount.', 'cWonDiscountAmount');
                        hasError = true;
                    }
                }
            }

            return hasError;
        },

        beforeSave: function () {
            if (Dep.prototype.beforeSave) {
                Dep.prototype.beforeSave.call(this);
            }
            var name = (this.model.get('name') || '').trim();
            if (!name) {
                var autoName = (typeof this.getNamePlaceholder === 'function')
                    ? this.getNamePlaceholder().replace(/^e\.g\.\s*/i, '').replace(/\.\.\.$/, '').trim()
                    : '';
                if (autoName) {
                    this.model.set('name', autoName);
                }
            }

            if (this.model.get('stage') === 'Closed Won' && this.hasSubscriptionScope() && this.getProductType() === 'Subscription') {
                var sub = (this.model.get('cSubdomain') || '').trim();
                var rootPart = this.getRootDomainPart();
                if (sub && !sub.startsWith('.') && !sub.includes('.')) {
                    var slug = this.slugify(sub);
                    if (slug) {
                        this.model.set('cSubdomain', slug + rootPart);
                    }
                }
            }
        },

        hasSubscriptionScope: function () {
            var meta = this.getMetadata();
            if (!meta) return false;
            if (typeof meta.has === 'function' && meta.has(['scopes', 'CSubscriptionPlan'])) {
                return true;
            }
            if (typeof meta.get === 'function') {
                return Boolean(meta.get(['scopes', 'CSubscriptionPlan']));
            }
            return false;
        },

        cleanRootDomain: function (domain) {
            if (!domain) return '';
            var clean = String(domain).trim().toLowerCase();
            clean = clean.replace(/^(?:https?:\/\/)/i, '').replace(/\/.*$/, '').replace(/^\.+|\.+$/g, '');
            return clean;
        },

        getProductRootDomain: function (productId) {
            if (!productId) {
                productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            }
            if (productId && this.productRootDomainCache && this.productRootDomainCache[productId]) {
                return this.cleanRootDomain(this.productRootDomainCache[productId]);
            }
            if (this.model.get('cProductServiceRootDomain')) {
                return this.cleanRootDomain(this.model.get('cProductServiceRootDomain'));
            }
            return '';
        },

        handleProductAmount: async function (productId, options) {
            options = options || {};

            if (!productId) {
                if (this.isAmountLockedByProduct) {
                    this.isAmountLockedByProduct = false;
                    this.unlockAmountField();
                }
                return;
            }

            try {
                var product = null;
                if (typeof Espo !== 'undefined' && Espo.Ajax) {
                    product = await Espo.Ajax.getRequest('CProductService/' + productId, {
                        select: 'id,name,type,price,priceCurrency,cRootDomain'
                    });
                }

                if (product) {
                    this.productTypeCache = this.productTypeCache || {};
                    this.productTypeCache[productId] = product.type;
                    this.productRootDomainCache = this.productRootDomainCache || {};
                    this.productRootDomainCache[productId] = product.cRootDomain || null;
                    this.model.set('cProductServiceType', product.type);
                    this.model.set('cProductServiceRootDomain', product.cRootDomain || null);
                    this.model.set('cProductServicePrice', product.price !== null && product.price !== undefined ? parseFloat(product.price) : null, { silent: true });
                    if (product.type === 'Custom Development' && this.model.get('cWonHasDiscount')) {
                        this.model.set('cWonHasDiscount', false);
                    }
                    this.updateSubdomainValue(true);
                }

                var hasSubPlanScope = this.hasSubscriptionScope();

                if (hasSubPlanScope && this.model.get('stage') === 'Closed Won') {
                    this.updateSubdomainValue();
                }

                if (hasSubPlanScope && this.model.get('stage') === 'Closed Won' && this.model.get('cWonPlanId')) {
                    return;
                }

                var hasSubscriptions = false;
                if (hasSubPlanScope) {
                    if (product && product.type === 'Subscription') {
                        hasSubscriptions = true;
                    } else if (typeof Espo !== 'undefined' && Espo.Ajax) {
                        try {
                            var plansRes = await Espo.Ajax.getRequest('CSubscriptionPlan', {
                                where: [
                                    { type: 'equals', attribute: 'productId', value: productId },
                                    { type: 'equals', attribute: 'status', value: 'Active' }
                                ],
                                maxSize: 1
                            });
                            if (plansRes && (plansRes.total > 0 || (plansRes.list && plansRes.list.length > 0))) {
                                hasSubscriptions = true;
                            }
                        } catch (planErr) {
                            hasSubscriptions = false;
                        }
                    }
                }

                if (hasSubscriptions) {
                    var attrs = { amount: 0.0 };
                    if (product && product.priceCurrency) {
                        attrs.amountCurrency = product.priceCurrency;
                    }
                    this.model.set(attrs, { fromProductAmount: true });
                    var amountSubView = this.getFieldView('amount');
                    if (amountSubView && typeof amountSubView.reRender === 'function') {
                        amountSubView.reRender();
                    }
                    this.isAmountLockedByProduct = true;
                    this.lockAmountField();
                } else {
                    var price = 0.0;
                    if (product && product.price !== null && product.price !== undefined) {
                        price = parseFloat(product.price) || 0.0;
                    }
                    var currentAmount = parseFloat(this.model.get('amount'));

                    if (price <= 0.0) {
                        // No registered price on Product/Service: keep user-entered amount or default to 0
                        if (options.initial && !this.model.isNew()) {
                            if (!isNaN(currentAmount) && currentAmount > 0) {
                                this.model.set('cWonOriginalAmount', currentAmount, { silent: true });
                            }
                        } else {
                            if (!isNaN(currentAmount) && currentAmount > 0) {
                                this.model.set('cWonOriginalAmount', currentAmount, { silent: true });
                            } else {
                                var pDevAttrs = { amount: 0.0 };
                                if (product && product.priceCurrency) {
                                    pDevAttrs.amountCurrency = product.priceCurrency;
                                }
                                this.model.set(pDevAttrs, { fromProductAmount: true });
                                var amountDevView = this.getFieldView('amount');
                                if (amountDevView && typeof amountDevView.reRender === 'function') {
                                    amountDevView.reRender();
                                }
                            }
                        }
                        this.isAmountLockedByProduct = false;
                        this.unlockAmountField();
                    } else {
                        // Product/Service has a registered price (including Custom Development): fill amount from price
                        if (options.initial && !this.model.isNew()) {
                            if (!this.model.get('cWonOriginalAmount') && !isNaN(currentAmount) && currentAmount > 0) {
                                this.model.set('cWonOriginalAmount', currentAmount, { silent: true });
                            }
                        } else if (this.model.get('cWonHasDiscount')) {
                            this.model.set('cWonOriginalAmount', price, { silent: true });
                            if (product && product.priceCurrency) {
                                this.model.set('amountCurrency', product.priceCurrency, { silent: true });
                            }
                        } else {
                            var pAttrs = {
                                amount: price,
                                cWonOriginalAmount: price
                            };
                            if (product && product.priceCurrency) {
                                pAttrs.amountCurrency = product.priceCurrency;
                            }
                            this.model.set(pAttrs, { fromProductAmount: true });
                            var amountProdView = this.getFieldView('amount');
                            if (amountProdView && typeof amountProdView.reRender === 'function') {
                                amountProdView.reRender();
                            }
                        }
                        this.isAmountLockedByProduct = false;
                        this.unlockAmountField();
                        if (this.model.get('cWonHasDiscount')) {
                            this.recalculateDiscount();
                        }
                    }
                }
            } catch (e) {
                console.warn('Could not fetch product for Opportunity amount:', e);
                this.isAmountLockedByProduct = false;
                this.unlockAmountField();
            }
        },

        parseNumeric: function (val) {
            if (val === null || val === undefined || val === '') {
                return NaN;
            }
            if (typeof val === 'number') {
                return val;
            }
            var cleaned = String(val).replace(/,/g, '').replace(/[^0-9.\-]/g, '');
            if (cleaned === '' || cleaned === '-' || cleaned === '.') {
                return NaN;
            }
            return parseFloat(cleaned);
        },

        recalculateDiscount: function () {
            this.handleDiscountLiveUpdate();
        },

        setupDiscountLiveCalculation: function () {
            var update = this.handleDiscountLiveUpdate.bind(this);

            this.$el.off('.discountCalc');
            this.$el.on('input.discountCalc keyup.discountCalc change.discountCalc', [
                'input[data-name="cWonHasDiscount"]',
                'select[data-name="cWonDiscountType"]',
                'input[data-name="cWonDiscountPercent"]',
                'input[data-name="cWonDiscountAmount"]',
                'input[data-name="cWonOriginalAmount"]'
            ].join(','), update);

            this.$el.on('input.discountCalc change.discountCalc', 'input[data-name="amount"]', function (e) {
                if (this._isUpdatingDiscount) {
                    return;
                }
                var $hasDisc = this.$el.find('input[data-name="cWonHasDiscount"]');
                var hasDisc = $hasDisc.length ? $hasDisc.is(':checked') : Boolean(this.model.get('cWonHasDiscount'));
                if (!hasDisc) {
                    var val = this.parseNumeric($(e.currentTarget).val());
                    if (!isNaN(val) && val >= 0) {
                        this.model.set('cWonOriginalAmount', val, { silent: true });
                    }
                }
            }.bind(this));

            this.stopListening(this.model, 'change:cWonHasDiscount change:cWonDiscountType change:cWonDiscountPercent change:cWonDiscountAmount change:cWonOriginalAmount');
            this.listenTo(this.model, 'change:cWonHasDiscount change:cWonDiscountType change:cWonDiscountPercent change:cWonDiscountAmount change:cWonOriginalAmount', function (model, val, options) {
                if (this._isUpdatingDiscount || (options && options.fromDiscountCalc)) {
                    return;
                }
                this.handleDiscountLiveUpdate();
            }.bind(this));

            this.handleDiscountLiveUpdate();
        },

        handleDiscountLiveUpdate: function (event) {
            if (this._isUpdatingDiscount) {
                return;
            }

            var stage = this.model.get('stage');
            if (stage !== 'Closed Won') {
                this.clearDiscountValidationWarning();
                this.setSaveButtonDisabled(false);
                return;
            }

            var prodType = this.model.get('cProductServiceType');
            if (prodType === 'Custom Development') {
                this.clearDiscountValidationWarning();
                this.setSaveButtonDisabled(false);
                return;
            }

            var $hasDisc = this.$el.find('input[data-name="cWonHasDiscount"]');
            var hasDiscount = $hasDisc.length ? $hasDisc.is(':checked') : Boolean(this.model.get('cWonHasDiscount'));

            var $discType = this.$el.find('select[data-name="cWonDiscountType"]');
            var type = ($discType.length && $discType.val()) ? $discType.val() : (this.model.get('cWonDiscountType') || 'Percentage');

            var targetName = (event && event.currentTarget && event.currentTarget.dataset)
                ? event.currentTarget.dataset.name
                : null;

            // Resolve Original Amount cleanly without comma truncation
            var originalAmount = NaN;
            if (targetName === 'cWonOriginalAmount') {
                originalAmount = this.parseNumeric($(event.currentTarget).val());
            }
            if (isNaN(originalAmount) || originalAmount <= 0) {
                var modelOrig = this.parseNumeric(this.model.get('cWonOriginalAmount'));
                if (!isNaN(modelOrig) && modelOrig > 0) {
                    originalAmount = modelOrig;
                }
            }
            if (isNaN(originalAmount) || originalAmount <= 0) {
                var $origDom = this.$el.find('input[data-name="cWonOriginalAmount"]');
                if ($origDom.length) {
                    var domOrig = this.parseNumeric($origDom.val());
                    if (!isNaN(domOrig) && domOrig > 0) {
                        originalAmount = domOrig;
                    }
                }
            }
            if (isNaN(originalAmount) || originalAmount <= 0) {
                var pPrice = this.parseNumeric(this.model.get('cProductServicePrice'));
                if (!isNaN(pPrice) && pPrice > 0) {
                    originalAmount = pPrice;
                }
            }
            if (isNaN(originalAmount) || originalAmount <= 0) {
                var modelAmt = this.parseNumeric(this.model.get('amount'));
                if (!isNaN(modelAmt) && modelAmt > 0) {
                    originalAmount = modelAmt;
                }
            }
            if (isNaN(originalAmount) || originalAmount < 0) {
                originalAmount = 0.0;
            }

            this._isUpdatingDiscount = true;
            try {
                if (!hasDiscount) {
                    this.clearDiscountValidationWarning();
                    this.setSaveButtonDisabled(false);

                    var prevTotal = this.parseNumeric(this.model.get('cWonDiscountTotal'));
                    var currentModelAmt = this.parseNumeric(this.model.get('amount'));
                    var restoreAmt = originalAmount > 0 ? originalAmount : (!isNaN(currentModelAmt) ? currentModelAmt : 0.0);

                    if (Boolean(this.model.get('cWonHasDiscount')) || (!isNaN(prevTotal) && prevTotal !== 0) || currentModelAmt !== restoreAmt) {
                        this.model.set({
                            cWonHasDiscount: false,
                            cWonDiscountTotal: 0.0,
                            amount: restoreAmt,
                            cWonOriginalAmount: restoreAmt
                        }, { fromDiscountCalc: true });
                        this.updateDiscountUiDisplays(restoreAmt, 0.0, restoreAmt, true);
                    }
                    return;
                }

                var $pctInput = this.$el.find('input[data-name="cWonDiscountPercent"]');
                var $amtInput = this.$el.find('input[data-name="cWonDiscountAmount"]');

                var pctRaw = $pctInput.length ? $pctInput.val() : this.model.get('cWonDiscountPercent');
                var amtRaw = $amtInput.length ? $amtInput.val() : this.model.get('cWonDiscountAmount');

                var errorMessage = null;
                var errorField = (type === 'Amount') ? 'cWonDiscountAmount' : 'cWonDiscountPercent';
                var discount = 0.0;

                if (type === 'Percentage') {
                    var pct = this.parseNumeric(pctRaw);
                    if (isNaN(pct)) {
                        pct = 0.0;
                    }
                    if (pct < 0) {
                        errorMessage = 'Percentage discount cannot be negative.';
                    } else if (pct > 100) {
                        errorMessage = 'Percentage discount must be between 0% and 100%.';
                    } else {
                        discount = Math.round(originalAmount * (pct / 100) * 100) / 100;
                    }
                } else if (type === 'Amount') {
                    var amt = this.parseNumeric(amtRaw);
                    if (isNaN(amt)) {
                        amt = 0.0;
                    }
                    if (amt < 0) {
                        errorMessage = 'Discount amount cannot be negative.';
                    } else if (amt > originalAmount) {
                        errorMessage = 'Fixed discount cannot exceed the original amount.';
                    } else {
                        discount = Math.round(amt * 100) / 100;
                    }
                }

                if (errorMessage) {
                    this.showDiscountValidationWarning(errorMessage, errorField);
                    this.setSaveButtonDisabled(true);
                    return;
                }

                this.clearDiscountValidationWarning();
                this.setSaveButtonDisabled(false);

                var finalAmount = Math.max(0.0, Math.round((originalAmount - discount) * 100) / 100);
                var amtCurrency = this.model.get('amountCurrency') || this.getConfig().get('defaultCurrency') || 'USD';

                this.model.set({
                    cWonHasDiscount: true,
                    cWonDiscountType: type,
                    cWonOriginalAmount: originalAmount,
                    cWonOriginalAmountCurrency: amtCurrency,
                    cWonDiscountTotal: discount,
                    cWonDiscountTotalCurrency: amtCurrency,
                    amount: finalAmount
                }, { fromDiscountCalc: true });

                this.updateDiscountUiDisplays(originalAmount, discount, finalAmount, false);
            } finally {
                this._isUpdatingDiscount = false;
            }
        },

        updateDiscountUiDisplays: function (orig, disc, finalAmt, isNoDiscount) {
            var amountView = this.getFieldView('amount');
            if (amountView) {
                var $amtInput = this.$el.find('input[data-name="amount"]');
                if (!$amtInput.length || !$amtInput.is(':focus')) {
                    if (typeof amountView.reRender === 'function') {
                        amountView.reRender();
                    }
                }
            }

            var discTotalView = this.getFieldView('cWonDiscountTotal');
            if (discTotalView && typeof discTotalView.reRender === 'function') {
                discTotalView.reRender();
            }

            var origAmtView = this.getFieldView('cWonOriginalAmount');
            if (origAmtView) {
                var $origInput = this.$el.find('input[data-name="cWonOriginalAmount"]');
                if (!$origInput.length || !$origInput.is(':focus')) {
                    if (typeof origAmtView.reRender === 'function') {
                        origAmtView.reRender();
                    }
                }
            }
        },

        showDiscountValidationWarning: function (msg, fieldName) {
            fieldName = fieldName || ((this.model.get('cWonDiscountType') === 'Amount') ? 'cWonDiscountAmount' : 'cWonDiscountPercent');
            if (typeof this.showValidationMessage === 'function') {
                this.showValidationMessage(fieldName, msg);
            }
            this.$el.find('.discount-validation-inline-warning').remove();
            var $field = this.$el.find('.field[data-name="' + fieldName + '"]').first();
            if (!$field.length) {
                $field = this.$el.find('.field[data-name="amount"]').first();
            }
            if ($field.length) {
                var $warn = $('<div class="discount-validation-inline-warning text-danger" style="margin-top: 6px; font-size: 12px; font-weight: 600; display: flex; align-items: center; gap: 5px;"></div>');
                $warn.html('<i class="fas fa-exclamation-triangle"></i> ' + msg);
                $field.append($warn);
            }
        },

        clearDiscountValidationWarning: function () {
            this.$el.find('.discount-validation-inline-warning').remove();
        },

        setSaveButtonDisabled: function (disabled) {
            var $saveBtn = this.$el.closest('.modal-content, .record, #main, body').find('button[data-name="save"], button[data-action="save"], button[data-action="convert"]');
            if ($saveBtn.length) {
                $saveBtn.prop('disabled', disabled);
                if (disabled) {
                    $saveBtn.addClass('disabled');
                } else {
                    $saveBtn.removeClass('disabled');
                }
            }
        },

        lockAmountField: function () {
            if (typeof this.setFieldReadOnly === 'function') {
                this.setFieldReadOnly('amount');
            }
            var amountView = this.getFieldView('amount');
            if (amountView) {
                if (typeof amountView.setReadOnly === 'function') {
                    amountView.setReadOnly();
                }
                if (amountView.$element) {
                    if (typeof amountView.$element.prop === 'function') {
                        amountView.$element.prop('readonly', true);
                        amountView.$element.prop('disabled', true);
                    }
                    if (typeof amountView.$element.attr === 'function') {
                        amountView.$element.attr('readonly', 'readonly');
                        amountView.$element.attr('disabled', 'disabled');
                    }
                }
                var $input = this.$el && typeof this.$el.find === 'function' ? this.$el.find('input[data-name="amount"]') : null;
                if ($input && $input.length) {
                    if (typeof $input.prop === 'function') {
                        $input.prop('readonly', true);
                        $input.prop('disabled', true);
                    }
                    if (typeof $input.attr === 'function') {
                        $input.attr('readonly', 'readonly');
                        $input.attr('disabled', 'disabled');
                    }
                }
            }
        },

        unlockAmountField: function () {
            if (!this.model.isNew() && this.initialStage === 'Closed Won') {
                return;
            }
            if (this.model.get('stage') === 'Closed Won' && this.model.get('cWonPlanId')) {
                return;
            }
            if (typeof this.setFieldNotReadOnly === 'function') {
                this.setFieldNotReadOnly('amount');
            }
            var amountView = this.getFieldView('amount');
            if (amountView) {
                if (typeof amountView.setNotReadOnly === 'function') {
                    amountView.setNotReadOnly();
                }
                if (amountView.$element) {
                    if (typeof amountView.$element.prop === 'function') {
                        amountView.$element.prop('readonly', false);
                        amountView.$element.prop('disabled', false);
                    }
                    if (typeof amountView.$element.removeAttr === 'function') {
                        amountView.$element.removeAttr('readonly');
                        amountView.$element.removeAttr('disabled');
                    }
                }
                var $input = this.$el && typeof this.$el.find === 'function' ? this.$el.find('input[data-name="amount"]') : null;
                if ($input && $input.length) {
                    if (typeof $input.prop === 'function') {
                        $input.prop('readonly', false);
                        $input.prop('disabled', false);
                    }
                    if (typeof $input.removeAttr === 'function') {
                        $input.removeAttr('readonly');
                        $input.removeAttr('disabled');
                    }
                }
            }
        },

        generateOpportunityName: function (leadName, accountName, productName) {
            if (arguments.length === 2) {
                productName = accountName;
                accountName = '';
            }

            leadName = (leadName || '').trim();
            accountName = (accountName || '').trim();
            productName = (productName || '').trim();

            var parts = [];

            if (leadName) {
                parts.push(leadName);
            }

            if (accountName && accountName.toLowerCase() !== leadName.toLowerCase()) {
                parts.push(accountName);
            }

            if (productName) {
                parts.push(productName);
            }

            if (parts.length) {
                return parts.join(' - ') + ' - deal';
            }

            return 'deal';
        },

        getNamePlaceholder: function () {
            var leadName = (this.model.get('leadName') || '').trim();
            var accountName = (this.model.get('accountName') || '').trim();

            if (!leadName && typeof this.getParentView === 'function') {
                var parentView = this.getParentView();
                if (parentView && parentView.model && (parentView.model.name === 'Lead' || parentView.model.entityType === 'Lead')) {
                    leadName = (parentView.model.get('name') || '').trim();
                    if (!accountName) {
                        accountName = (parentView.model.get('accountName') || '').trim();
                    }
                }
            }

            if (!accountName && !leadName) {
                var contactsNames = this.model.get('contactsNames');
                if (contactsNames && typeof contactsNames === 'object') {
                    var vals = Object.values(contactsNames).map(function (v) {
                        return v ? String(v).trim() : '';
                    }).filter(Boolean);
                    if (vals.length) {
                        leadName = vals[0];
                    }
                }
            }

            if (!accountName && typeof this.getParentView === 'function') {
                var pvLead = this.getParentView();
                if (pvLead && pvLead.model) {
                    accountName = (pvLead.model.get('accountName') || '').trim();
                }
            }

            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();

            if (!prodName && typeof this.getParentView === 'function') {
                var pv = this.getParentView();
                if (pv && pv.model) {
                    var namesMap = pv.model.get('cProductServicesNames');
                    if (namesMap && typeof namesMap === 'object') {
                        var pVals = Object.values(namesMap).map(function (v) {
                            return v ? String(v).trim() : '';
                        }).filter(Boolean);
                        if (pVals.length) {
                            prodName = pVals[0];
                        }
                    }
                }
            }

            if (leadName || accountName || prodName) {
                return 'e.g. ' + this.generateOpportunityName(leadName, accountName, prodName);
            }

            return 'e.g. SpaceX - CoachSys - deal';
        },

        updateNamePlaceholder: function () {
            var leadName = (this.model.get('leadName') || '').trim();
            var accountName = (this.model.get('accountName') || '').trim();

            if (!leadName && typeof this.getParentView === 'function') {
                var parentView = this.getParentView();
                if (parentView && parentView.model && (parentView.model.name === 'Lead' || parentView.model.entityType === 'Lead')) {
                    leadName = (parentView.model.get('name') || '').trim();
                    if (!accountName) {
                        accountName = (parentView.model.get('accountName') || '').trim();
                    }
                }
            }

            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();

            if (this.model.isNew() || this.model.isConvertMode) {
                var name = this.model.get('name');
                if (!name || name.endsWith(' - Opportunity') || name === 'Opportunity' || (leadName && name === leadName) || (accountName && name === accountName)) {
                    var autoName = this.generateOpportunityName(leadName, accountName, prodName);
                    if (autoName && autoName !== 'deal') {
                        this.model.set('name', autoName);
                    } else {
                        this.model.set('name', '');
                    }
                } else if (!this.isNameManuallyEdited && (leadName || accountName || prodName)) {
                    this.model.set('name', this.generateOpportunityName(leadName, accountName, prodName));
                }
            }

            var placeholder = this.getNamePlaceholder();

            var $input = this.$el && typeof this.$el.find === 'function' ? this.$el.find('input[data-name="name"]') : null;
            if ($input && $input.length) {
                if (typeof $input.attr === 'function') {
                    $input.attr('placeholder', placeholder);
                } else if ($input[0] && typeof $input[0].setAttribute === 'function') {
                    $input[0].setAttribute('placeholder', placeholder);
                }
            }

            var nameView = this.getFieldView('name');
            if (nameView) {
                nameView.placeholder = placeholder;
                if (nameView.params) {
                    nameView.params.placeholder = placeholder;
                }
                if (nameView.$element) {
                    if (typeof nameView.$element.attr === 'function') {
                        nameView.$element.attr('placeholder', placeholder);
                    } else if (nameView.$element[0] && typeof nameView.$element[0].setAttribute === 'function') {
                        nameView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                var $nameInput = nameView.$el && typeof nameView.$el.find === 'function' ? nameView.$el.find('input') : null;
                if ($nameInput && $nameInput.length) {
                    if (typeof $nameInput.attr === 'function') {
                        $nameInput.attr('placeholder', placeholder);
                    } else if ($nameInput[0] && typeof $nameInput[0].setAttribute === 'function') {
                        $nameInput[0].setAttribute('placeholder', placeholder);
                    }
                }
            }
        },

        getDescriptionPlaceholder: function () {
            return 'e.g. Deal background, customer pain points, budget & authority, decision criteria, competitors, and key next milestones...';
        },

        updateDescriptionPlaceholder: function () {
            var placeholder = this.getDescriptionPlaceholder();

            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="description"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('textarea, input');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $textElem = this.$el.find('textarea[data-name="description"]');
                if ($textElem && $textElem.length) {
                    if (typeof $textElem.attr === 'function') {
                        $textElem.attr('placeholder', placeholder);
                    } else if ($textElem[0] && typeof $textElem[0].setAttribute === 'function') {
                        $textElem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="description"], .field[data-name="description"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('textarea, input');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            var descView = this.getFieldView('description');
            if (descView) {
                descView.placeholder = placeholder;
                if (descView.params) {
                    descView.params.placeholder = placeholder;
                }
                if (descView.$element) {
                    if (typeof descView.$element.attr === 'function') {
                        descView.$element.attr('placeholder', placeholder);
                    } else if (descView.$element[0] && typeof descView.$element[0].setAttribute === 'function') {
                        descView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (descView.$el && typeof descView.$el.find === 'function') {
                    var $descInputs = descView.$el.find('textarea');
                    if ($descInputs && $descInputs.length) {
                        if (typeof $descInputs.attr === 'function') {
                            $descInputs.attr('placeholder', placeholder);
                        } else if ($descInputs[0] && typeof $descInputs[0].setAttribute === 'function') {
                            $descInputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        },

        slugify: function (text) {
            if (!text) return '';
            return String(text)
                .trim()
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
        },

        getClientSlug: function () {
            var clientName = (this.model.get('accountName') || this.model.get('leadName') || '').trim();

            if (!clientName) {
                var contactsNames = this.model.get('contactsNames');
                if (contactsNames && typeof contactsNames === 'object') {
                    var vals = Object.values(contactsNames).map(function (v) {
                        return v ? String(v).trim() : '';
                    }).filter(Boolean);
                    if (vals.length) {
                        clientName = vals[0];
                    }
                }
            }

            if (!clientName && typeof this.getParentView === 'function') {
                var parentView = this.getParentView();
                if (parentView && parentView.model) {
                    clientName = (parentView.model.get('accountName') || parentView.model.get('name') || '').trim();
                }
            }

            if (!clientName) {
                var oppName = (this.model.get('name') || '').trim();
                if (oppName && !oppName.endsWith(' - Opportunity') && oppName !== 'Opportunity') {
                    var parts = oppName.split('-');
                    if (parts.length > 1) {
                        clientName = parts[0].trim();
                    }
                }
            }

            var slug = this.slugify(clientName);
            return slug || 'client';
        },

        getProductDomain: function (productName) {
            if (!productName) return 'coachsys.com';
            var clean = productName.trim().toLowerCase();
            clean = clean.replace(/^(?:https?:\/\/)/i, '').replace(/\/.*$/, '');
            if (/\.[a-z]{2,}$/i.test(clean)) {
                return clean;
            }
            var slug = clean.replace(/[^a-z0-9]/g, '');
            return (slug || 'coachsys') + '.com';
        },

        getProductType: function (productId) {
            if (!productId) {
                return this.model.get('cProductServiceType') || null;
            }
            if (this.productTypeCache && this.productTypeCache[productId]) {
                return this.productTypeCache[productId];
            }
            return this.model.get('cProductServiceType') || null;
        },

        getRootDomainPart: function () {
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            var rootDomain = this.getProductRootDomain(prodId);
            if (rootDomain) {
                return '.' + rootDomain.replace(/^\.+/, '');
            }
            var prodType = this.getProductType(prodId) || this.model.get('cProductServiceType') || 'Subscription';
            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();
            if (prodType === 'Subscription') {
                var domain = this.getProductDomain(prodName || 'CoachSys');
                return '.' + domain.replace(/^\.+/, '');
            } else {
                var prodSlug = this.slugify(prodName || 'custom-development');
                return '.' + (prodSlug || 'custom-dev') + '.com';
            }
        },

        generateSubdomainUrl: function () {
            if (this.model.get('stage') !== 'Closed Won') {
                return '';
            }

            var clientSlug = this.getClientSlug() || 'client';
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            var rootDomain = this.getProductRootDomain(prodId);

            if (rootDomain) {
                var cleanRoot = rootDomain.replace(/^\.+/, '');
                if (!cleanRoot.includes('.')) {
                    cleanRoot += '.com';
                }
                return clientSlug + '.' + cleanRoot;
            }

            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();
            var prodSlug = this.slugify(prodName) || 'service';
            return clientSlug + '.' + prodSlug + '.com';
        },

        getSubdomainPlaceholder: function () {
            var clientSlug = this.getClientSlug() || 'client';
            var prodId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            var rootDomain = this.getProductRootDomain(prodId);

            if (rootDomain) {
                var cleanRoot = rootDomain.replace(/^\.+/, '');
                if (!cleanRoot.includes('.')) {
                    cleanRoot += '.com';
                }
                return 'e.g. ' + clientSlug + '.' + cleanRoot;
            }

            var prodName = (this.model.get('cProductServiceName') || this.model.get('cWonProductName') || '').trim();
            var prodSlug = this.slugify(prodName) || 'service';
            return 'e.g. ' + clientSlug + '.' + prodSlug + '.com';
        },

        ensureProductData: async function (productId) {
            if (!productId) {
                productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            }
            if (!productId || !/^[a-z0-9]{17}$/i.test(productId)) return null;
            this.productRootDomainCache = this.productRootDomainCache || {};
            this.productTypeCache = this.productTypeCache || {};
            if (this.productRootDomainCache[productId] !== undefined) {
                return {
                    rootDomain: this.productRootDomainCache[productId],
                    type: this.productTypeCache[productId]
                };
            }
            if (typeof Espo !== 'undefined' && Espo.Ajax) {
                try {
                    var prod = await Espo.Ajax.getRequest('CProductService/' + encodeURIComponent(productId), {
                        select: 'id,name,type,price,priceCurrency,cRootDomain'
                    }, { returnError: true });
                    if (prod) {
                        this.productTypeCache[productId] = prod.type || null;
                        this.productRootDomainCache[productId] = prod.cRootDomain || null;
                        this.model.set('cProductServiceType', prod.type || null, { silent: true });
                        this.model.set('cProductServiceRootDomain', prod.cRootDomain || null, { silent: true });
                        return {
                            rootDomain: prod.cRootDomain || null,
                            type: prod.type || null
                        };
                    }
                } catch (e) {
                    console.warn('ensureProductData error:', e);
                }
            }
            return null;
        },

        manageWonSubscriptionPanels: function () {
            var hasSubScope = this.hasSubscriptionScope();
            var stage = this.model.get('stage');
            var isClosedWon = (stage === 'Closed Won');
            var isSubscription = (this.getProductType() === 'Subscription');

            if (isClosedWon && hasSubScope && isSubscription) {
                if (typeof this.showPanel === 'function') {
                    this.showPanel('wonSubscription');
                }
                if (typeof this.showField === 'function') {
                    this.showField('cSubdomain');
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('[data-name="wonSubscription"]').show();
                    this.$el.find('.cell[data-name="cSubdomain"]').show();
                    this.$el.find('.field[data-name="cSubdomain"]').show();
                }
            } else if (hasSubScope) {
                if (typeof this.hidePanel === 'function') {
                    this.hidePanel('wonSubscription');
                }
                if (typeof this.hideField === 'function') {
                    this.hideField('cSubdomain');
                }
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('[data-name="wonSubscription"]').hide();
                    this.$el.find('.cell[data-name="cSubdomain"]').hide();
                    this.$el.find('.field[data-name="cSubdomain"]').hide();
                }
            }
        },

        updateSubdomainValue: function (force) {
            var hasSubScope = this.hasSubscriptionScope();
            if (!hasSubScope) {
                return;
            }
            if (this.model.get('stage') !== 'Closed Won') {
                return;
            }
            var currentVal = (this.model.get('cSubdomain') || '').trim();
            var generated = this.generateSubdomainUrl();

            if (generated && (!currentVal || force || currentVal.startsWith('.') || !this.isSubdomainManuallyEdited)) {
                this.model.set('cSubdomain', generated, { ui: true, fromAutoSubdomain: true });
                if (this.$el && typeof this.$el.find === 'function') {
                    this.$el.find('[data-name="cSubdomain"] input').val(generated);
                    this.$el.find('input[data-name="cSubdomain"]').val(generated);
                }
                var subFieldView = (typeof this.getFieldView === 'function') ? this.getFieldView('cSubdomain') : null;
                if (subFieldView && typeof subFieldView.reRender === 'function' && subFieldView.mode !== 'edit') {
                    subFieldView.reRender();
                }
            }
            this.updateSubdomainPlaceholder();
        },

        syncWonPlanFieldUI: function (planId, planName) {
            if (!planId) return;
            planName = planName || '';
            var planFieldView = (typeof this.getFieldView === 'function') ? this.getFieldView('cWonPlan') : null;
            if (planFieldView) {
                if (planFieldView.$elementName && typeof planFieldView.$elementName.val === 'function') {
                    planFieldView.$elementName.val(planName);
                }
                if (planFieldView.$elementId && typeof planFieldView.$elementId.val === 'function') {
                    planFieldView.$elementId.val(planId);
                }
                if (typeof planFieldView.trigger === 'function') {
                    planFieldView.trigger('change');
                }
                if (typeof planFieldView.controlCreateButtonVisibility === 'function') {
                    planFieldView.controlCreateButtonVisibility();
                }
                if (typeof planFieldView.loadPlan === 'function') {
                    planFieldView.loadPlan();
                } else if (typeof planFieldView.reRender === 'function') {
                    planFieldView.reRender();
                }
            }
            if (this.$el && typeof this.$el.find === 'function') {
                this.$el.find('input[data-name="cWonPlanName"]').val(planName);
                this.$el.find('input[data-name="cWonPlanId"]').val(planId);
                this.$el.find('.field[data-name="cWonPlan"] input.main-element').val(planName);
                this.$el.find('.field[data-name="cWonPlan"] input[data-name="cWonPlanName"]').val(planName);
                this.$el.find('.field[data-name="cWonPlan"] input[data-name="cWonPlanId"]').val(planId);
            }
        },

        checkAndPromptPlans: async function (productId, options) {
            options = options || {};
            if (!this.hasSubscriptionScope()) {
                return;
            }
            if (!productId) {
                productId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
            }
            if (!productId || !/^[a-z0-9]{17}$/i.test(productId)) {
                return;
            }

            if (this.model.get('cWonPlanId') && !options.forceManual) {
                return;
            }

            try {
                var res = await Espo.Ajax.getRequest('CSubscriptionPlan', {
                    where: [
                        { type: 'equals', attribute: 'productId', value: productId },
                        { type: 'equals', attribute: 'status', value: 'Active' }
                    ],
                    maxSize: 20
                }, { returnError: true });

                if (!res) return;
                var list = res.list || [];
                var total = (typeof res.total === 'number') ? res.total : list.length;

                if (total === 1 && list.length === 1) {
                    var singlePlan = list[0];
                    var values = {
                        cWonPlanId: singlePlan.id,
                        cWonPlanName: singlePlan.name
                    };
                    if (singlePlan.monthlyPrice != null) {
                        values.cWonPlanPrice = singlePlan.monthlyPrice;
                        values.cWonPlanPriceCurrency = singlePlan.monthlyPriceCurrency;
                    }
                    if (singlePlan.billingPeriod) {
                        values.cWonPeriod = singlePlan.billingPeriod;
                    }
                    this.model.set(values, { ui: true, fromPlanAutoFill: true });
                    this.syncWonPlanFieldUI(singlePlan.id, singlePlan.name);
                } else if (total > 1 || list.length > 1) {
                    this.openPlanPicker(productId);
                }
            } catch (e) {
                console.warn('Subscription plans check failed:', e);
            }
        },

        openPlanPicker: async function (productId) {
            if (!this.hasSubscriptionScope() || !productId || !/^[a-z0-9]{17}$/i.test(productId)) return;
            if (this.hasView('wonPlanPicker') || this.isOpeningPlanPicker) return;
            this.isOpeningPlanPicker = true;

            var onPlanSelected = (record) => {
                this.isOpeningPlanPicker = false;
                if (Array.isArray(record)) record = record[0];
                if (!record) return;
                var currentProdId = this.model.get('cProductServiceId') || this.model.get('cWonProductId');
                if (currentProdId !== productId) return;

                var planId = record.id || (typeof record.get === 'function' ? record.get('id') : null);
                var planName = (typeof record.get === 'function' ? record.get('name') : record.name) || '';
                var planPrice = typeof record.get === 'function' ? record.get('monthlyPrice') : record.monthlyPrice;
                var planCurrency = typeof record.get === 'function' ? record.get('monthlyPriceCurrency') : record.monthlyPriceCurrency;
                var planPeriod = typeof record.get === 'function' ? record.get('billingPeriod') : record.billingPeriod;

                var values = {
                    cWonPlanId: planId,
                    cWonPlanName: planName,
                    stage: 'Closed Won',
                    probability: 100
                };
                if (planPrice != null) {
                    values.cWonPlanPrice = planPrice;
                    values.cWonPlanPriceCurrency = planCurrency;
                }
                if (planPeriod) {
                    values.cWonPeriod = planPeriod;
                }
                this.model.set(values, { ui: true, fromPlanPicker: true });
                var stageView = (typeof this.getFieldView === 'function') ? this.getFieldView('stage') : null;
                if (stageView && typeof stageView.reRender === 'function') {
                    stageView.reRender();
                }
                this.manageWonSubscriptionPanels();
                this.syncWonPlanFieldUI(planId, planName);
            };

            try {
                var modal = await this.createView('wonPlanPicker', 'views/modals/select-records', {
                    scope: 'CSubscriptionPlan',
                    multiple: false,
                    createButton: false,
                    filters: {
                        product: { type: 'equals', attribute: 'productId', value: productId },
                        active: { type: 'equals', attribute: 'status', value: 'Active' }
                    },
                    onSelect: onPlanSelected
                });

                this.listenToOnce(modal, 'select', onPlanSelected);
                this.listenToOnce(modal, 'close remove', () => {
                    this.isOpeningPlanPicker = false;
                });
                await modal.render();
            } catch (e) {
                this.isOpeningPlanPicker = false;
                console.warn('Could not open plans picker:', e);
            }
        },

        updateSubdomainPlaceholder: function () {
            var placeholder = this.getSubdomainPlaceholder();

            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="cSubdomain"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('input');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $inputElem = this.$el.find('input[data-name="cSubdomain"]');
                if ($inputElem && $inputElem.length) {
                    if (typeof $inputElem.attr === 'function') {
                        $inputElem.attr('placeholder', placeholder);
                    } else if ($inputElem[0] && typeof $inputElem[0].setAttribute === 'function') {
                        $inputElem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="cSubdomain"], .field[data-name="cSubdomain"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('input');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            var subdomainView = this.getFieldView('cSubdomain');
            if (subdomainView) {
                subdomainView.placeholder = placeholder;
                if (subdomainView.params) {
                    subdomainView.params.placeholder = placeholder;
                }
                if (subdomainView.$element) {
                    if (typeof subdomainView.$element.attr === 'function') {
                        subdomainView.$element.attr('placeholder', placeholder);
                    } else if (subdomainView.$element[0] && typeof subdomainView.$element[0].setAttribute === 'function') {
                        subdomainView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (subdomainView.$el && typeof subdomainView.$el.find === 'function') {
                    var $subInputs = subdomainView.$el.find('input');
                    if ($subInputs && $subInputs.length) {
                        if (typeof $subInputs.attr === 'function') {
                            $subInputs.attr('placeholder', placeholder);
                        } else if ($subInputs[0] && typeof $subInputs[0].setAttribute === 'function') {
                            $subInputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        }

    });

});
