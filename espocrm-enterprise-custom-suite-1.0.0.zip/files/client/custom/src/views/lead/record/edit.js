define('custom:views/lead/record/edit', ['views/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    var TARGET_PLACEHOLDER_FIELDS = [
        'name',
        'accountName',
        'emailAddress',
        'website',
        'cWebsite',
        'description',
        'phoneNumber',
        'title',
        'address'
    ];

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            this.productPriceMap = {};
            this.opportunityAmountCalcId = 0;

            this.listenTo(this.model, 'change:cProductServicesIds', function (m, v, o) {
                if (!o || !o.ui) {
                    return;
                }

                this.recalculateOpportunityAmount();
            });
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            this.updateAllPlaceholders();
            this.hookFieldViewRenderListeners();
        },

        getFieldPlaceholder: function (fieldName) {
            switch (fieldName) {
                case 'accountName':
                    return 'e.g. Acme Corporation, Wayne Enterprises Ltd...';
                case 'emailAddress':
                    return 'e.g. alex.mercer@company.com';
                case 'website':
                case 'cWebsite':
                    return 'e.g. https://www.company.com';
                case 'description':
                    return 'e.g. Lead background, prospect inquiry details, project scope, requirements, or qualification notes...';
                case 'phoneNumber':
                    return 'e.g. +1 555-0199';
                case 'title':
                    return 'e.g. VP of Technology, Procurement Director...';
                default:
                    return '';
            }
        },

        applyFieldPlaceholder: function (fieldName, placeholder) {
            if (!fieldName) return;

            // Handle composite address fields
            if (fieldName === 'address') {
                var addressMap = {
                    'addressStreet': 'e.g. 100 Main Street, Suite 400',
                    'addressCity': 'e.g. New York',
                    'addressState': 'e.g. NY',
                    'addressPostalCode': 'e.g. 10001',
                    'addressCountry': 'e.g. United States'
                };
                Object.keys(addressMap).forEach(function (subName) {
                    var subPlaceholder = addressMap[subName];
                    if (this.$el && typeof this.$el.find === 'function') {
                        var $subElem = this.$el.find('[data-name="' + subName + '"]');
                        if ($subElem && $subElem.length) {
                            if (typeof $subElem.attr === 'function') {
                                $subElem.attr('placeholder', subPlaceholder);
                            } else if ($subElem[0] && typeof $subElem[0].setAttribute === 'function') {
                                $subElem[0].setAttribute('placeholder', subPlaceholder);
                            }
                        }
                    }
                }, this);
                var addressView = this.getFieldView('address');
                if (addressView && addressView.$el && typeof addressView.$el.find === 'function') {
                    Object.keys(addressMap).forEach(function (subName) {
                        var $sub = addressView.$el.find('[data-name="' + subName + '"]');
                        if ($sub && $sub.length && typeof $sub.attr === 'function') {
                            $sub.attr('placeholder', addressMap[subName]);
                        }
                    });
                }
                return;
            }

            // Handle composite person name fields
            if (fieldName === 'name') {
                var nameMap = {
                    'firstName': 'e.g. Jane',
                    'lastName': 'e.g. Doe'
                };
                Object.keys(nameMap).forEach(function (subName) {
                    var subPlaceholder = nameMap[subName];
                    if (this.$el && typeof this.$el.find === 'function') {
                        var $subElem = this.$el.find('[data-name="' + subName + '"]');
                        if ($subElem && $subElem.length) {
                            if (typeof $subElem.attr === 'function') {
                                $subElem.attr('placeholder', subPlaceholder);
                            } else if ($subElem[0] && typeof $subElem[0].setAttribute === 'function') {
                                $subElem[0].setAttribute('placeholder', subPlaceholder);
                            }
                        }
                    }
                }, this);
                var nameView = this.getFieldView('name');
                if (nameView && nameView.$el && typeof nameView.$el.find === 'function') {
                    Object.keys(nameMap).forEach(function (subName) {
                        var $sub = nameView.$el.find('[data-name="' + subName + '"]');
                        if ($sub && $sub.length && typeof $sub.attr === 'function') {
                            $sub.attr('placeholder', nameMap[subName]);
                        }
                    });
                }
                return;
            }

            placeholder = placeholder || this.getFieldPlaceholder(fieldName);
            if (!placeholder) return;

            // Direct DOM search
            if (this.$el && typeof this.$el.find === 'function') {
                var $elem = this.$el.find('[data-name="' + fieldName + '"]');
                if ($elem && $elem.length) {
                    if (typeof $elem.attr === 'function') {
                        $elem.attr('placeholder', placeholder);
                        if (typeof $elem.find === 'function') {
                            var $sub = $elem.find('input, textarea');
                            if ($sub && $sub.length && typeof $sub.attr === 'function') {
                                $sub.attr('placeholder', placeholder);
                            }
                        }
                    } else if ($elem[0] && typeof $elem[0].setAttribute === 'function') {
                        $elem[0].setAttribute('placeholder', placeholder);
                    }
                }

                var $cellElem = this.$el.find('.cell[data-name="' + fieldName + '"], .field[data-name="' + fieldName + '"]');
                if ($cellElem && $cellElem.length && typeof $cellElem.find === 'function') {
                    var $inner = $cellElem.find('input, textarea');
                    if ($inner && $inner.length) {
                        if (typeof $inner.attr === 'function') {
                            $inner.attr('placeholder', placeholder);
                        } else if ($inner[0] && typeof $inner[0].setAttribute === 'function') {
                            $inner[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }

            // Field view update
            var fieldView = this.getFieldView(fieldName);
            if (fieldView) {
                fieldView.placeholder = placeholder;
                if (fieldView.params) {
                    fieldView.params.placeholder = placeholder;
                }
                if (fieldView.$element) {
                    if (typeof fieldView.$element.attr === 'function') {
                        fieldView.$element.attr('placeholder', placeholder);
                    } else if (fieldView.$element[0] && typeof fieldView.$element[0].setAttribute === 'function') {
                        fieldView.$element[0].setAttribute('placeholder', placeholder);
                    }
                }
                if (fieldView.$el && typeof fieldView.$el.find === 'function') {
                    var $inputs = fieldView.$el.find('input, textarea');
                    if ($inputs && $inputs.length) {
                        if (typeof $inputs.attr === 'function') {
                            $inputs.attr('placeholder', placeholder);
                        } else if ($inputs[0] && typeof $inputs[0].setAttribute === 'function') {
                            $inputs[0].setAttribute('placeholder', placeholder);
                        }
                    }
                }
            }
        },

        updateAllPlaceholders: function () {
            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                this.applyFieldPlaceholder(fieldName);
            }, this);
        },

        hookFieldViewRenderListeners: function () {
            this._hookedFieldViews = this._hookedFieldViews || {};

            TARGET_PLACEHOLDER_FIELDS.forEach(function (fieldName) {
                if (this._hookedFieldViews[fieldName]) return;
                var fieldView = this.getFieldView(fieldName);
                if (fieldView) {
                    this._hookedFieldViews[fieldName] = true;
                    this.listenTo(fieldView, 'after:render', function () {
                        this.applyFieldPlaceholder(fieldName);
                    }.bind(this));
                }
            }, this);
        },

        /**
         * Sum the prices of the selected Product Services into `opportunityAmount`.
         * Runs only when the selection changes, so a manually typed amount is kept
         * until the selection is touched again.
         */
        recalculateOpportunityAmount: function () {
            var idList = this.model.get('cProductServicesIds') || [];

            var calcId = ++this.opportunityAmountCalcId;

            if (!idList.length) {
                this.model.set('opportunityAmount', null);

                return;
            }

            var unknownIdList = idList.filter(function (id) {
                return !Object.prototype.hasOwnProperty.call(this.productPriceMap, id);
            }, this);

            if (unknownIdList.length) {
                Espo.Ajax.getRequest('CProductService', {
                    select: 'id,price',
                    where: [{
                        attribute: 'id',
                        type: 'in',
                        value: unknownIdList
                    }],
                    maxSize: 100
                }).then(function (response) {
                    var list = (response || {}).list || [];

                    list.forEach(function (item) {
                        this.productPriceMap[item.id] = item.price;
                    }, this);

                    unknownIdList.forEach(function (id) {
                        if (!Object.prototype.hasOwnProperty.call(this.productPriceMap, id)) {
                            this.productPriceMap[id] = null;
                        }
                    }, this);

                    if (calcId === this.opportunityAmountCalcId) {
                        this.applyOpportunityAmount(idList);
                    }
                }.bind(this), function () {});

                return;
            }

            this.applyOpportunityAmount(idList);
        },

        applyOpportunityAmount: function (idList) {
            var amount = 0;

            idList.forEach(function (id) {
                var price = Number(this.productPriceMap[id]);

                if (!isNaN(price)) {
                    amount += price;
                }
            }, this);

            amount = Math.round(amount);

            if (this.model.get('opportunityAmount') !== amount) {
                this.model.set('opportunityAmount', amount);
            }
        }

    });

});
