/**
 * CGIT CRM White-Label Personalization Bootstrap.
 *
 * Ensures consistent CGIT branding across:
 *   - Browser favicons & apple-touch-icon
 *   - Login & 2FA login routes
 *   - Navbar & Portal logo positions
 *   - In-app popup notifications (#popup-notifications-container) & Notification API icons
 *   - Footer & page title / dark-theme contrast
 *
 * Loaded via custom/Espo/Modules/Personalization/Resources/metadata/app/client.json.
 */
(function () {
    'use strict';

    if (typeof window === 'undefined' || typeof document === 'undefined') {
        return;
    }

    var DEFAULT_BRAND_NAME = 'CGIT CRM';
    var LOGO_PATH = 'client/custom/img/cgit-logo.png';
    var POPUP_LOGO_PATH = 'client/custom/img/cgit-popup-logo.png';
    var FAVICON_PNG_PATH = 'client/custom/img/cgit-favicon.png';
    var FAVICON_ICO_PATH = 'client/custom/img/cgit-favicon.ico';

    var currentScript = document.currentScript;
    var basePath = '';

    try {
        var loaderNode = document.querySelector('script[data-name="loader-params"]');
        if (loaderNode && loaderNode.textContent) {
            var parsedLoader = JSON.parse(loaderNode.textContent);
            if (parsedLoader && typeof parsedLoader.basePath === 'string') {
                basePath = parsedLoader.basePath;
            }
        }
    } catch (e) {}

    if (!basePath && currentScript && typeof currentScript.getAttribute === 'function') {
        basePath = currentScript.getAttribute('data-base-path') || '';
    }

    var appInstance = null;
    var hookedRequire = false;
    var patchedApp = false;
    var patchedViews = false;
    var observerAttached = false;

    function getBasePath() {
        if (appInstance && typeof appInstance.getBasePath === 'function') {
            var bp = appInstance.getBasePath();
            if (typeof bp === 'string') {
                return bp;
            }
        }
        return basePath || '';
    }

    function assetUrl(relPath) {
        return getBasePath() + relPath;
    }

    function absoluteAssetUrl(relPath) {
        try {
            return new URL(assetUrl(relPath), window.location.href).href;
        } catch (e) {
            return assetUrl(relPath);
        }
    }

    function getBrandName() {
        try {
            if (appInstance && appInstance.settings) {
                var configured = appInstance.settings.get('applicationName');
                if (configured && String(configured).trim() !== '' && configured !== 'EspoCRM') {
                    return String(configured).trim();
                }
            }
        } catch (e) {}

        var titleText = (document.title || '').trim();
        if (titleText && titleText !== 'EspoCRM' && titleText.indexOf('EspoCRM') === -1) {
            var sep = titleText.indexOf(' - ');
            return sep > 0 ? titleText.slice(0, sep).trim() : DEFAULT_BRAND_NAME;
        }
        return DEFAULT_BRAND_NAME;
    }

    function isCoreDefaultLogo(src) {
        if (!src) {
            return true;
        }
        return /client\/img\/logo[^/]*\.(svg|png)$/i.test(src);
    }

    function getEffectiveLogoUrl(view) {
        try {
            var config = view && typeof view.getConfig === 'function' ? view.getConfig() : (appInstance && appInstance.settings);
            if (config && typeof config.get === 'function') {
                var companyLogoId = config.get('companyLogoId');
                if (companyLogoId) {
                    return getBasePath() + '?entryPoint=LogoImage&id=' + encodeURIComponent(companyLogoId);
                }
            }
        } catch (e) {}

        return assetUrl(LOGO_PATH);
    }

    function ensureFaviconLinks() {
        var head = document.head || document.getElementsByTagName('head')[0];
        if (!head) {
            return;
        }

        var iconLink = head.querySelector('link[rel="icon"]');
        if (!iconLink) {
            iconLink = document.createElement('link');
            iconLink.rel = 'icon';
            head.appendChild(iconLink);
        }
        if ((iconLink.getAttribute('href') || '').indexOf('cgit-favicon') === -1) {
            iconLink.href = assetUrl(FAVICON_PNG_PATH);
            iconLink.type = 'image/png';
        }

        var altLink = head.querySelector('link[rel="alternate icon"]');
        if (!altLink) {
            altLink = document.createElement('link');
            altLink.rel = 'alternate icon';
            head.appendChild(altLink);
        }
        if ((altLink.getAttribute('href') || '').indexOf('cgit-favicon') === -1) {
            altLink.href = assetUrl(FAVICON_ICO_PATH);
            altLink.type = 'image/x-icon';
        }

        if (!head.querySelector('link[rel="apple-touch-icon"]')) {
            var touchLink = document.createElement('link');
            touchLink.rel = 'apple-touch-icon';
            touchLink.href = assetUrl(POPUP_LOGO_PATH);
            head.appendChild(touchLink);
        }
    }

    function syncDarkThemeClass() {
        var isDark = false;
        try {
            if (appInstance && appInstance.themeManager && typeof appInstance.themeManager.isDark === 'function') {
                isDark = !!appInstance.themeManager.isDark();
            }
        } catch (e) {}

        if (!isDark) {
            var ss = document.getElementById('main-stylesheet');
            var href = ss ? (ss.getAttribute('href') || '') : '';
            if (/\/(dark|glass)\.css/i.test(href)) {
                isDark = true;
            }
        }

        if (document.documentElement) {
            document.documentElement.classList.toggle('cgit-dark-theme', isDark);
        }
    }

    function brandFooterElement(footerEl) {
        if (!footerEl) {
            return;
        }
        var brand = getBrandName();
        var year = new Date().getFullYear();
        var credit = footerEl.querySelector('p.credit') || footerEl;
        if (!credit) {
            return;
        }
        var existing = credit.getAttribute('data-cgit-footer');
        if (existing === brand) {
            return;
        }
        credit.textContent = '\u00A9 ' + year + ' ';
        var span = document.createElement('span');
        span.className = 'cgit-footer-brand';
        span.textContent = brand;
        credit.appendChild(span);
        credit.setAttribute('data-cgit-footer', brand);
    }

    function brandPopupNotificationEl(el) {
        if (!el || el.nodeType !== 1 || !el.classList || !el.classList.contains('popup-notification')) {
            return;
        }
        if (el.querySelector('.cgit-popup-brand')) {
            return;
        }

        var brand = getBrandName();
        var wrap = document.createElement('div');
        wrap.className = 'cgit-popup-brand';

        var img = document.createElement('img');
        img.className = 'cgit-popup-logo';
        img.src = assetUrl(POPUP_LOGO_PATH);
        img.alt = brand;

        var label = document.createElement('span');
        label.className = 'cgit-popup-brand-name';
        label.textContent = brand;

        wrap.appendChild(img);
        wrap.appendChild(label);

        var h4 = el.querySelector('h4');
        if (h4 && h4.parentNode) {
            h4.parentNode.insertBefore(wrap, h4);
        } else {
            var afterControls = null;
            var children = el.children;
            for (var i = 0; i < children.length; i++) {
                if (children[i].matches && children[i].matches('a.close, a[data-action="collapse"]')) {
                    afterControls = children[i];
                }
            }
            if (afterControls && afterControls.nextSibling) {
                el.insertBefore(wrap, afterControls.nextSibling);
            } else if (afterControls) {
                el.appendChild(wrap);
            } else {
                el.insertBefore(wrap, el.firstChild);
            }
        }
    }

    function scanVisibleBranding() {
        ensureFaviconLinks();
        syncDarkThemeClass();

        var brand = getBrandName();
        if (document.title === 'EspoCRM') {
            document.title = brand;
        }

        var imgs = document.querySelectorAll('#navbar img.logo, #login img.logo');
        for (var i = 0; i < imgs.length; i++) {
            var img = imgs[i];
            if (isCoreDefaultLogo(img.getAttribute('src'))) {
                img.src = getEffectiveLogoUrl(null);
            }
            img.alt = brand;
            if (img.parentElement && img.parentElement.matches('a.navbar-brand')) {
                img.parentElement.setAttribute('title', brand);
                img.parentElement.setAttribute('aria-label', brand);
            }
        }

        var footer = document.querySelector('body > footer');
        if (footer && (footer.querySelector('p.credit') || /EspoCRM/i.test(footer.textContent || ''))) {
            brandFooterElement(footer);
        }

        var popups = document.querySelectorAll('#popup-notifications-container .popup-notification');
        for (var j = 0; j < popups.length; j++) {
            brandPopupNotificationEl(popups[j]);
        }
    }

    function attachObserver() {
        if (observerAttached || typeof MutationObserver !== 'function') {
            return;
        }
        var target = document.body || document.documentElement;
        if (!target) {
            return;
        }
        observerAttached = true;

        var observer = new MutationObserver(function (mutations) {
            for (var i = 0; i < mutations.length; i++) {
                var added = mutations[i].addedNodes;
                for (var j = 0; j < added.length; j++) {
                    var node = added[j];
                    if (node.nodeType !== 1) {
                        continue;
                    }
                    if (node.classList && node.classList.contains('popup-notification')) {
                        brandPopupNotificationEl(node);
                    } else if (node.querySelectorAll) {
                        var inner = node.querySelectorAll('.popup-notification');
                        for (var k = 0; k < inner.length; k++) {
                            brandPopupNotificationEl(inner[k]);
                        }
                    }
                    if (node.tagName === 'FOOTER' || (node.id === 'login') || (node.id === 'navbar')) {
                        scanVisibleBranding();
                    }
                }
            }
        });

        observer.observe(target, { childList: true, subtree: true });
    }

    function wrapBrowserNotification() {
        if (typeof window.Notification !== 'function' || window.Notification.__cgitWrapped) {
            return;
        }

        var NativeNotification = window.Notification;
        var WrappedNotification = function (title, options) {
            var nextOptions = {};
            if (options && typeof options === 'object') {
                for (var key in options) {
                    if (Object.prototype.hasOwnProperty.call(options, key)) {
                        nextOptions[key] = options[key];
                    }
                }
            }
            if (!nextOptions.icon || isCoreDefaultLogo(nextOptions.icon)) {
                nextOptions.icon = absoluteAssetUrl(POPUP_LOGO_PATH);
            }
            if (!nextOptions.badge || isCoreDefaultLogo(nextOptions.badge)) {
                nextOptions.badge = absoluteAssetUrl(POPUP_LOGO_PATH);
            }
            var finalTitle = title === 'EspoCRM' ? getBrandName() : title;
            return new NativeNotification(finalTitle, nextOptions);
        };

        WrappedNotification.prototype = NativeNotification.prototype;
        try {
            Object.setPrototypeOf(WrappedNotification, NativeNotification);
        } catch (e) {}

        Object.defineProperty(WrappedNotification, 'permission', {
            get: function () {
                return NativeNotification.permission;
            },
            configurable: true
        });
        if (typeof NativeNotification.requestPermission === 'function') {
            WrappedNotification.requestPermission = function () {
                return NativeNotification.requestPermission.apply(NativeNotification, arguments);
            };
        }
        WrappedNotification.__cgitWrapped = true;
        window.Notification = WrappedNotification;
    }

    function patchCoreViews() {
        if (patchedViews || typeof window.require !== 'function') {
            return;
        }
        patchedViews = true;

        var viewIds = [
            'views/login',
            'views/login-second-step',
            'views/site/navbar',
            'views/site-portal/navbar',
            'views/site/footer',
            'views/site/header',
            'views/popup-notification'
        ];

        window.require(viewIds, function (
            LoginView,
            LoginSecondStepView,
            NavbarView,
            PortalNavbarView,
            FooterView,
            HeaderView,
            PopupNotificationView
        ) {
            if (LoginView && LoginView.prototype && !LoginView.prototype.__cgitPatched) {
                var origLoginGetLogoSrc = LoginView.prototype.getLogoSrc;
                LoginView.prototype.getLogoSrc = function () {
                    var src = typeof origLoginGetLogoSrc === 'function' ? origLoginGetLogoSrc.apply(this, arguments) : '';
                    return isCoreDefaultLogo(src) ? getEffectiveLogoUrl(this) : src;
                };
                var origLoginAfterRender = LoginView.prototype.afterRender;
                LoginView.prototype.afterRender = function () {
                    var res = typeof origLoginAfterRender === 'function' ? origLoginAfterRender.apply(this, arguments) : undefined;
                    scanVisibleBranding();
                    return res;
                };
                LoginView.prototype.__cgitPatched = true;
            }

            if (LoginSecondStepView && LoginSecondStepView.prototype && !LoginSecondStepView.prototype.__cgitPatched) {
                var origSecondAfterRender = LoginSecondStepView.prototype.afterRender;
                LoginSecondStepView.prototype.afterRender = function () {
                    var res = typeof origSecondAfterRender === 'function' ? origSecondAfterRender.apply(this, arguments) : undefined;
                    var panel = (this.element && this.element.id === 'login')
                        ? this.element
                        : ((this.element && this.element.querySelector('#login')) || document.getElementById('login'));
                    if (panel && !panel.querySelector('.panel-heading .logo-container')) {
                        panel.classList.add('cgit-second-step-branded');
                        var heading = document.createElement('div');
                        heading.className = 'panel-heading';
                        var box = document.createElement('div');
                        box.className = 'logo-container';
                        var img = document.createElement('img');
                        img.className = 'logo';
                        img.src = getEffectiveLogoUrl(this);
                        img.alt = getBrandName();
                        box.appendChild(img);
                        heading.appendChild(box);
                        panel.insertBefore(heading, panel.firstChild);
                    }
                    scanVisibleBranding();
                    return res;
                };
                LoginSecondStepView.prototype.__cgitPatched = true;
            }

            [NavbarView, PortalNavbarView].forEach(function (NavCls) {
                if (!NavCls || !NavCls.prototype || NavCls.prototype.__cgitPatched) {
                    return;
                }
                var origNavGetLogoSrc = NavCls.prototype.getLogoSrc;
                NavCls.prototype.getLogoSrc = function () {
                    var src = typeof origNavGetLogoSrc === 'function' ? origNavGetLogoSrc.apply(this, arguments) : '';
                    return isCoreDefaultLogo(src) ? getEffectiveLogoUrl(this) : src;
                };
                var origNavAfterRender = NavCls.prototype.afterRender;
                NavCls.prototype.afterRender = function () {
                    var res = typeof origNavAfterRender === 'function' ? origNavAfterRender.apply(this, arguments) : undefined;
                    scanVisibleBranding();
                    return res;
                };
                NavCls.prototype.__cgitPatched = true;
            });

            if (HeaderView && HeaderView.prototype && !HeaderView.prototype.__cgitPatched) {
                var origHeaderSetup = HeaderView.prototype.setup;
                HeaderView.prototype.setup = function () {
                    if (this.title === 'EspoCRM') {
                        this.title = getBrandName();
                    }
                    if (this.data && this.data.title === 'EspoCRM') {
                        this.data.title = getBrandName();
                    }
                    return typeof origHeaderSetup === 'function' ? origHeaderSetup.apply(this, arguments) : undefined;
                };
                HeaderView.prototype.__cgitPatched = true;
            }

            if (FooterView && FooterView.prototype && !FooterView.prototype.__cgitPatched) {
                var origFooterAfterRender = FooterView.prototype.afterRender;
                FooterView.prototype.afterRender = function () {
                    var res = typeof origFooterAfterRender === 'function' ? origFooterAfterRender.apply(this, arguments) : undefined;
                    brandFooterElement(this.element || document.querySelector('body > footer'));
                    return res;
                };
                FooterView.prototype.__cgitPatched = true;
            }

            if (PopupNotificationView && PopupNotificationView.prototype && !PopupNotificationView.prototype.__cgitPatched) {
                var origPopupOnShow = PopupNotificationView.prototype.onShow;
                PopupNotificationView.prototype.onShow = function () {
                    brandPopupNotificationEl(this.element || document.getElementById(this.id));
                    return typeof origPopupOnShow === 'function' ? origPopupOnShow.apply(this, arguments) : undefined;
                };
                PopupNotificationView.prototype.__cgitPatched = true;
            }
        });
    }

    function patchApp(App) {
        if (patchedApp || !App || !App.prototype) {
            return;
        }
        patchedApp = true;

        var origStart = App.prototype.start;
        if (typeof origStart !== 'function') {
            return;
        }

        App.prototype.start = function () {
            appInstance = this;
            patchCoreViews();
            syncDarkThemeClass();

            if (typeof this.on === 'function') {
                this.on('login', function () {
                    window.setTimeout(scanVisibleBranding, 50);
                });
                this.on('logout', function () {
                    window.setTimeout(scanVisibleBranding, 50);
                });
            }

            return origStart.apply(this, arguments);
        };
    }

    function hookRequire() {
        if (hookedRequire) {
            return;
        }
        if (typeof window.require !== 'function') {
            window.setTimeout(hookRequire, 20);
            return;
        }
        hookedRequire = true;

        patchCoreViews();

        var originalRequire = window.require;
        window.require = function (name, callback) {
            if (name === 'app' && typeof callback === 'function') {
                var args = Array.prototype.slice.call(arguments);
                args[1] = function (App) {
                    patchApp(App);
                    return callback.apply(this, arguments);
                };
                return originalRequire.apply(window, args);
            }
            return originalRequire.apply(window, arguments);
        };
    }

    ensureFaviconLinks();
    wrapBrowserNotification();
    hookRequire();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            attachObserver();
            scanVisibleBranding();
        });
    } else {
        attachObserver();
        scanVisibleBranding();
    }
})();
