<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["CSubscriptionPlan","CClientSubscription"];
            $insertAfterTab = function (array $list, string $tab, array $anchors): array {
                $existingIdx = null;
                foreach ($list as $k => $item) {
                    if (is_string($item) && $item === $tab) {
                        $existingIdx = $k;
                        break;
                    }
                }
                if ($existingIdx !== null) {
                    array_splice($list, $existingIdx, 1);
                }
                foreach ($anchors as $anchor) {
                    foreach ($list as $k => $item) {
                        if (is_string($item) && $item === $anchor) {
                            array_splice($list, $k + 1, 0, [$tab]);
                            return array_values($list);
                        }
                    }
                }
                foreach ($list as $k => $item) {
                    if (is_string($item) && $item === '_delimiter_') {
                        array_splice($list, $k, 0, [$tab]);
                        return array_values($list);
                    }
                }
                $list[] = $tab;
                return array_values($list);
            };
            $anchorMap = [
                'CProductService' => ['Call'],
                'CSubscriptionPlan' => ['CProductService', 'Call'],
                'CClientSubscription' => ['CSubscriptionPlan', 'CProductService', 'Call'],
            ];

            $tabList = $config->get('tabList') ?? [];
            foreach ($tabs as $tab) {
                if (isset($anchorMap[$tab])) {
                    $tabList = $insertAfterTab($tabList, $tab, $anchorMap[$tab]);
                } else {
                    $exists = false;
                    foreach ($tabList as $item) {
                        if (is_string($item) && $item === $tab) {
                            $exists = true;
                            break;
                        }
                    }
                    if (!$exists) {
                        $tabList[] = $tab;
                    }
                }
            }
            $configWriter->set('tabList', array_values($tabList));
            $configWriter->save();

            // Also place CProductService in quickCreateList right after Call if Call exists
            if (in_array('CProductService', $tabs)) {
                $qcList = $config->get('quickCreateList') ?? [];
                if (!in_array('CProductService', $qcList)) {
                    $callQcIdx = array_search('Call', $qcList);
                    if ($callQcIdx !== false) {
                        array_splice($qcList, $callQcIdx + 1, 0, ['CProductService']);
                    } else {
                        $qcList[] = 'CProductService';
                    }
                    $configWriter->set('quickCreateList', array_values($qcList));
                    $configWriter->save();
                }
            }

            // Update preferences for any user who customized tabList
            try {
                $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
                if ($em && $em->hasRepository('Preferences')) {
                    $prefsList = $em->getRDBRepository('Preferences')->where(['tabList!=' => null])->find();
                    foreach ($prefsList as $pref) {
                        $pTabList = $pref->get('tabList');
                        if (is_array($pTabList)) {
                            $pChanged = false;
                            foreach ($tabs as $tab) {
                                if (isset($anchorMap[$tab])) {
                                    $pTabList = $insertAfterTab($pTabList, $tab, $anchorMap[$tab]);
                                    $pChanged = true;
                                }
                            }
                            if ($pChanged) {
                                $pref->set('tabList', array_values($pTabList));
                                $em->saveEntity($pref);
                            }
                        }
                    }
                }
            } catch (\Throwable $e) {}


            $scopes = [
                'Account' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Contact' => ['panel' => 'cSubscriptions', 'index' => 10],
                'Lead' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Opportunity' => ['panel' => 'cWonSubscriptions', 'index' => 110]
            ];
            foreach ($scopes as $scope => $info) {
                $file = "custom/Espo/Custom/Resources/layouts/{$scope}/bottomPanelsDetail.json";
                $panelName = $info['panel'];
                $data = [];
                if (file_exists($file)) {
                    $json = @json_decode(file_get_contents($file), true);
                    if (is_array($json)) $data = $json;
                }
                if (!isset($data[$panelName]) || !empty($data[$panelName]['disabled'])) {
                    $data[$panelName] = ['disabled' => false, 'index' => $info['index']];
                    if (!is_dir(dirname($file))) @mkdir(dirname($file), 0777, true);
                    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                }
            }
            try {
                $dataManager = $container->getByClass(\Espo\Core\DataManager::class) ?? $container->get('dataManager');
                if ($dataManager && method_exists($dataManager, 'clearCache')) {
                    $dataManager->clearCache();
                }
            } catch (\Throwable $e) {}
        
        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
