<?php
namespace Espo\Custom\Services;

use Espo\Core\Record\Collection as RecordCollection;
use Espo\Core\Select\SearchParams;
use Espo\Core\Acl\Table as AclTable;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\Exceptions\NotFound;

class Account extends \Espo\Services\Record
{
    public function findLinked(string $id, string $link, SearchParams $searchParams): RecordCollection
    {
        if ($link === 'cSubscriptions') {
            return $this->findLinkedSubscriptions($id, $searchParams);
        }

        return parent::findLinked($id, $link, $searchParams);
    }

    private function findLinkedSubscriptions(string $accountId, SearchParams $searchParams): RecordCollection
    {
        $account = $this->getRepository()->getById($accountId);
        if (!$account) {
            throw new NotFound();
        }

        if (!$this->acl->check($account, AclTable::ACTION_READ)) {
            throw new Forbidden();
        }

        $whereOr = [
            [
                'clientType' => 'Account',
                'clientId' => $accountId
            ]
        ];

        // Find contacts belonging to this account
        $contacts = $this->entityManager->getRDBRepository('Contact')
            ->select(['id'])
            ->where([
                'accountId' => $accountId,
                'deleted' => 0
            ])
            ->find();
        $contactIds = [];
        foreach ($contacts as $c) {
            $contactIds[] = $c->getId();
        }
        if (!empty($contactIds)) {
            $whereOr[] = [
                'clientType' => 'Contact',
                'clientId' => $contactIds
            ];
        }

        // Also find by opportunities associated with this account
        $opps = $this->entityManager->getRDBRepository('Opportunity')
            ->select(['id'])
            ->where([
                'accountId' => $accountId,
                'deleted' => 0
            ])
            ->find();
        $oppIds = [];
        foreach ($opps as $o) {
            $oppIds[] = $o->getId();
        }
        if (!empty($oppIds)) {
            $whereOr[] = [
                'cWonOpportunityId' => $oppIds
            ];
        }

        $subRepo = $this->entityManager->getRDBRepository('CClientSubscription');
        $queryBuilder = $subRepo->where([
            'deleted' => 0,
            'OR' => $whereOr
        ]);

        $total = $queryBuilder->count();

        $maxSize = $searchParams->getMaxSize() ?: 20;
        $offset = $searchParams->getOffset() ?: 0;
        $orderBy = $searchParams->getOrderBy() ?: 'createdAt';
        $order = $searchParams->getOrder() ?: 'desc';

        $queryBuilder->limit($offset, $maxSize);
        $queryBuilder->order($orderBy, $order);

        $collection = $queryBuilder->find();

        $recordService = $this->recordServiceContainer->get('CClientSubscription');
        foreach ($collection as $itemEntity) {
            $recordService->prepareEntityForOutput($itemEntity);
        }

        return RecordCollection::create($collection, $total);
    }
}
