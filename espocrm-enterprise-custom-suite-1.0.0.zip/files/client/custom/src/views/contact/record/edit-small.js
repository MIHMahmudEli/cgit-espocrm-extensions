define('custom:views/contact/record/edit-small', ['custom:views/contact/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({});

});
