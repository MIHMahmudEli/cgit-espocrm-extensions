<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM — Open Source CRM application.
 * Copyright (C) 2014-2026 EspoCRM, Inc.
 * Website: https://www.espocrm.com
 ************************************************************************/

namespace Espo\Custom\Hooks\Note;

use Espo\Core\Hook\Hook\AfterSave;
use Espo\Core\Hook\Hook\BeforeSave;
use Espo\Custom\WebPush\NotificationDispatcher;
use Espo\Entities\Note;
use Espo\Entities\Notification;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\SaveOptions;

/**
 * Catches stream/note notifications inserted via massInsert() in Espo\Tools\Notification\Service::notifyAboutNote()
 * after NoteHookProcessor ($order = 14) runs, mirroring WebSocket delivery to Web Push devices.
 *
 * @implements BeforeSave<Note>
 * @implements AfterSave<Note>
 */
class WebPushSubmit implements BeforeSave, AfterSave
{
    public static int $order = 25;

    /** @var array<string, array<string, bool>> */
    private array $existingBeforeSave = [];

    public function __construct(
        private EntityManager $entityManager,
        private NotificationDispatcher $dispatcher,
    ) {}

    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        if (!$entity instanceof Note || $entity->isNew() || !$options->get('forceProcessNotifications')) {
            return;
        }

        $noteId = (string) ($entity->getId() ?? '');
        if ($noteId === '') {
            return;
        }

        $existing = $this->entityManager
            ->getRDBRepository(Notification::ENTITY_TYPE)
            ->select(['id'])
            ->where([
                'type' => [Notification::TYPE_NOTE, Notification::TYPE_MENTION_IN_POST],
                'relatedType' => Note::ENTITY_TYPE,
                'relatedId' => $noteId,
            ])
            ->find();

        $map = [];
        foreach ($existing as $row) {
            $id = (string) ($row->getId() ?? '');
            if ($id !== '') {
                $map[$id] = true;
            }
        }
        $this->existingBeforeSave[$noteId] = $map;
    }

    public function afterSave(Entity $entity, SaveOptions $options): void
    {
        if (!$entity instanceof Note) {
            return;
        }

        if ($options->get('skipWebPush')) {
            return;
        }

        if (!$entity->isNew() && !$options->get('forceProcessNotifications')) {
            return;
        }

        $noteId = (string) ($entity->getId() ?? '');
        if ($noteId === '') {
            return;
        }

        $skipIds = $this->existingBeforeSave[$noteId] ?? [];
        unset($this->existingBeforeSave[$noteId]);

        $notifications = $this->entityManager
            ->getRDBRepositoryByClass(Notification::class)
            ->where([
                'type' => [Notification::TYPE_NOTE, Notification::TYPE_MENTION_IN_POST],
                'relatedType' => Note::ENTITY_TYPE,
                'relatedId' => $noteId,
            ])
            ->find();

        foreach ($notifications as $notification) {
            $id = (string) ($notification->getId() ?? '');
            if ($id !== '' && isset($skipIds[$id])) {
                continue;
            }

            $this->dispatcher->dispatchNotification($notification, $entity);
        }
    }
}
