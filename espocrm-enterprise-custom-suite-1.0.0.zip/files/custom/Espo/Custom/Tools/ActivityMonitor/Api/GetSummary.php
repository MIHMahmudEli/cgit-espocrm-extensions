<?php

namespace Espo\Custom\Tools\ActivityMonitor\Api;

use Espo\Core\Acl;
use Espo\Core\Api\Action;
use Espo\Core\Api\Request;
use Espo\Core\Api\Response;
use Espo\Core\Api\ResponseComposer;
use Espo\Core\Exceptions\Forbidden;
use Espo\Custom\Tools\ActivityMonitor\Service;
use Espo\Entities\User;

class GetSummary implements Action
{
    public function __construct(
        private Service $service,
        private Acl $acl,
        private User $user,
    ) {}

    public function process(Request $request): Response
    {
        if (!$this->user->isAdmin()) {
            throw new Forbidden();
        }

        $params = $request->getQueryParams();
        $result = $this->service->getSummary($params);

        return ResponseComposer::json($result);
    }
}
