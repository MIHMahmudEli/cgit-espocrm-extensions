define('custom:views/fields/lead-source', ['views/fields/enum', 'views/modal'], function (Dep, ModalView) {

    Dep = Dep && Dep.default ? Dep.default : Dep;
    ModalView = ModalView && ModalView.default ? ModalView.default : ModalView;

    var AddSourceModal = ModalView.extend({
        headerText: 'Add Lead Source',
        templateContent: '<div class="form-group">' +
            '<label class="control-label">New Source Name</label>' +
            '<input type="text" class="form-control" data-name="newSourceName" placeholder="e.g. LinkedIn, Referral..." maxlength="100">' +
            '</div>',
        buttonList: [
            { name: 'save', label: 'Save', style: 'primary' },
            { name: 'cancel', label: 'Cancel' }
        ],
        afterRender: function () {
            ModalView.prototype.afterRender.call(this);
            var $input = this.$el.find('[data-name="newSourceName"]');
            setTimeout(function () { $input.focus(); }, 50);
            $input.on('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.actionSave();
                }
            }.bind(this));
        },
        actionSave: function () {
            var val = (this.$el.find('[data-name="newSourceName"]').val() || '').trim();
            if (!val) {
                Espo.Ui.warning('Please enter a source name.');
                return;
            }
            this.trigger('add-source', val);
            this.close();
        }
    });

    return Dep.extend({

        afterRender: function () {
            Dep.prototype.afterRender.call(this);

            if (!this.isEditMode() || !this.getUser().isAdmin()) {
                return;
            }

            var $select = this.$el.find('select').first();
            if (!$select.length) {
                return;
            }

            if (this.$el.find('.lead-source-add-btn').length) {
                return;
            }

            var $wrapper = $('<div class="input-group" style="display:flex;align-items:stretch;width:100%;"></div>');
            $select.css({ flex: '1 1 auto', minWidth: 0 });
            $select.wrap($wrapper);

            var $btnWrap = $('<span class="input-group-btn" style="flex:0 0 auto;width:auto;"></span>');
            var $btn = $('<button type="button" class="btn btn-default btn-icon lead-source-add-btn" title="Add Source">' +
                '<span class="fas fa-plus"></span>' +
                '</button>');

            $btn.on('click', function () {
                this.openAddSourceModal();
            }.bind(this));

            $btnWrap.append($btn);
            $select.after($btnWrap);
        },

        openAddSourceModal: function () {
            var modal = new AddSourceModal({});
            this.assignView('addSourceDialog', modal);
            modal.render();

            this.listenToOnce(modal, 'add-source', function (newSource) {
                this.saveNewSourceOption(newSource);
            }.bind(this));
        },

        saveNewSourceOption: function (newSource) {
            Espo.Ui.notify('Saving...');

            Espo.Ajax.getRequest('FieldManager/Lead/source').then(function (fieldData) {
                var options = Array.isArray(fieldData.options)
                    ? fieldData.options.slice()
                    : (this.params.options || []).slice();

                var exists = options.some(function (opt) {
                    return String(opt).toLowerCase() === newSource.toLowerCase();
                });

                if (exists) {
                    Espo.Ui.warning('Source "' + newSource + '" already exists.');
                    var existing = options.find(function (opt) {
                        return String(opt).toLowerCase() === newSource.toLowerCase();
                    });
                    if (existing !== undefined) {
                        this.model.set(this.name, existing);
                        this.reRender();
                    }
                    return;
                }

                var othersIdx = options.indexOf('Others');
                if (othersIdx !== -1) {
                    options.splice(othersIdx, 0, newSource);
                } else {
                    options.push(newSource);
                }

                var translatedOptions = Object.assign({}, fieldData.translatedOptions || this.translatedOptions || {});
                translatedOptions[newSource] = newSource;

                fieldData.options = options;
                fieldData.translatedOptions = translatedOptions;

                Espo.Ajax.putRequest('FieldManager/Lead/source', fieldData).then(function () {
                    this.params.options = options;
                    this.translatedOptions = translatedOptions;

                    var meta = this.getMetadata();
                    if (meta && meta.data && meta.data.entityDefs && meta.data.entityDefs.Lead &&
                        meta.data.entityDefs.Lead.fields && meta.data.entityDefs.Lead.fields.source) {
                        meta.data.entityDefs.Lead.fields.source.options = options;
                    }

                    this.model.set(this.name, newSource);
                    this.reRender();
                    Espo.Ui.success('Added source "' + newSource + '".');
                }.bind(this));
            }.bind(this));
        }

    });

});
