<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["CSubscriptionPlan","CClientSubscription"];
            $tabList = $config->get('tabList') ?? [];
            $modified = false;
            foreach ($tabs as $tab) {
                if (!in_array($tab, $tabList)) {
                    $tabList[] = $tab;
                    $modified = true;
                }
            }
            if ($modified) {
                $configWriter->set('tabList', $tabList);
                $configWriter->save();
            }


            $scopes = [
                'Account' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Contact' => ['panel' => 'cSubscriptions', 'index' => 10],
                'Lead' => ['panel' => 'cSubscriptions', 'index' => 100],
                'Opportunity' => ['panel' => 'cWonSubscriptions', 'index' => 110]
            ];
            foreach ($scopes as $scope => $info) {
                $file = "custom/Espo/Custom/Resources/layouts/{$scope}/bottomPanelsDetail.json";
                $panelName = $info['panel'];
                $data = [];
                if (file_exists($file)) {
                    $json = @json_decode(file_get_contents($file), true);
                    if (is_array($json)) $data = $json;
                }
                if (!isset($data[$panelName]) || !empty($data[$panelName]['disabled'])) {
                    $data[$panelName] = ['disabled' => false, 'index' => $info['index']];
                    if (!is_dir(dirname($file))) @mkdir(dirname($file), 0777, true);
                    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                }
            }
            try {
                $dataManager = $container->getByClass(\Espo\Core\DataManager::class) ?? $container->get('dataManager');
                if ($dataManager && method_exists($dataManager, 'clearCache')) {
                    $dataManager->clearCache();
                }
            } catch (\Throwable $e) {}
        
        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
