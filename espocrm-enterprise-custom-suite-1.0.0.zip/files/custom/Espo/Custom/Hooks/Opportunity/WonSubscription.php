<?php
namespace Espo\Custom\Hooks\Opportunity;

use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\SaveOptions;
use Espo\Core\Acl;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\Forbidden;

class WonSubscription implements \Espo\Core\Hook\Hook\BeforeSave, \Espo\Core\Di\EntityManagerAware, \Espo\Core\Di\AclAware
{
    public static int $order = 5;
    private ?EntityManager $em = null;
    private ?Acl $acl = null;

    public function setEntityManager(EntityManager $em): void
    {
        $this->em = $em;
    }

    public function setAcl(Acl $acl): void
    {
        $this->acl = $acl;
    }

    public function populateProductData(Entity $entity): void
    {
        $productId = $entity->get('cProductServiceId') ?: $entity->get('cWonProductId');
        if ($productId) {
            $product = $this->em->getEntityById('CProductService', $productId);
            if ($product) {
                $entity->set('cProductServiceType', $product->get('type'));
                $entity->set('cProductServiceRootDomain', $product->get('cRootDomain'));
            }
        }
    }

    private function money($value): float
    {
        if (!is_numeric($value) || !is_finite((float)$value) || $value < 0 || $value > 100000000000) {
            throw new BadRequest('Enter a valid non-negative charge.');
        }
        return round((float)$value, 2);
    }

    public function beforeSave(Entity $e, SaveOptions $options): void
    {
        // Sync cProductServiceId and cWonProductId
        if ($e->isAttributeChanged('cProductServiceId')) {
            $productId = $e->get('cProductServiceId');
            $e->set('cWonProductId', $productId);
        } else if ($e->isAttributeChanged('cWonProductId')) {
            $productId = $e->get('cWonProductId');
            $e->set('cProductServiceId', $productId);
        } else {
            $productId = $e->get('cProductServiceId') ?: $e->get('cWonProductId');
            if ($productId) {
                $e->set('cProductServiceId', $productId);
                $e->set('cWonProductId', $productId);
            }
        }

        if ($e->get('stage') !== 'Closed Won' && $e->get('amount') === null) {
            throw new BadRequest('Opportunity Amount is required before Closed Won.');
        }

        $planId = $e->get('cWonPlanId');
        $chargeFields = [
            'cWonPlanId',
            'cWonHasSetupFee',
            'cWonSetupFee',
            'cWonSetupFeeCurrency',
            'cWonHasDiscount',
            'cWonDiscountType',
            'cWonDiscountPercent',
            'cWonDiscountAmount',
        ];
        $chargeChanged = false;
        foreach ($chargeFields as $field) {
            if ($e->isAttributeChanged($field)) {
                $chargeChanged = true;
                break;
            }
        }

        if (!$e->isNew()) {
            foreach (['cWonOriginalAmount', 'cWonOriginalAmountCurrency'] as $field) {
                $e->set($field, $e->getFetched($field));
            }
        }

        $product = $productId ? $this->em->getEntityById('CProductService', $productId) : null;
        $isSubscription = $product && $product->get('type') === 'Subscription';
        if ($product) {
            $e->set('cProductServiceType', $product->get('type'));
        }

        if ($isSubscription && $e->get('stage') !== 'Closed Won') {
            if (($e->isNew() && ($planId || $e->get('cWonHasSetupFee') || $e->get('cWonHasDiscount'))) || (!$e->isNew() && $chargeChanged)) {
                throw new BadRequest('Configure subscription charges only when the opportunity is Closed Won.');
            }
            return;
        }

        if ($e->get('stage') === 'Closed Won') {
            $subdomain = trim((string)$e->get('cSubdomain'));
            $prodName = $product ? $product->get('name') : '';
            $rootDomain = $product ? trim((string)$product->get('cRootDomain')) : '';
            $cleanRootDomain = '';
            if ($rootDomain !== '') {
                $cleanRootDomain = preg_replace('#^https?://#i', '', $rootDomain);
                $cleanRootDomain = explode('/', $cleanRootDomain)[0];
                $cleanRootDomain = trim($cleanRootDomain, '.');
            }
            $prodSlug = $prodName ? strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '', $prodName))) : 'coachsys';
            $fallbackDomain = ($prodSlug ?: 'coachsys') . '.com';
            $rootDomainPart = $cleanRootDomain !== '' ? '.' . $cleanRootDomain : '.' . $fallbackDomain;

            // If subdomain is empty or starts with '.', auto-fill it from Account Name or Opportunity Name
            if ($subdomain === '' || str_starts_with($subdomain, '.')) {
                $accountName = $e->get('accountName');
                if (!$accountName && $e->get('accountId')) {
                    $acc = $this->em->getEntityById('Account', $e->get('accountId'));
                    if ($acc) {
                        $accountName = $acc->get('name');
                    }
                }
                if (!$accountName && $e->get('leadName')) {
                    $accountName = $e->get('leadName');
                }
                if (!$accountName && $e->get('name')) {
                    $oppName = trim((string)$e->get('name'));
                    if (str_contains($oppName, '-')) {
                        $parts = explode('-', $oppName);
                        $cand = trim($parts[0]);
                        if ($cand !== '' && $cand !== 'Opportunity') {
                            $accountName = $cand;
                        }
                    }
                }
                $accSlug = $accountName ? strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $accountName), '-')) : 'client';
                if ($accSlug === '') {
                    $accSlug = 'client';
                }
                $subdomain = $accSlug . $rootDomainPart;
                $e->set('cSubdomain', $subdomain);
            } else if (!str_contains($subdomain, '.')) {
                // If user typed only a prefix (e.g. "spacex") without a dot, append root domain part
                $subdomain = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $subdomain), '-')) . $rootDomainPart;
                $e->set('cSubdomain', $subdomain);
            }

            // Validate that actual subdomain is typed (not empty, not just ".cuda.com" or starting with ".")
            if ($subdomain === '' || str_starts_with($subdomain, '.') || !str_contains($subdomain, '.')) {
                throw new BadRequest('Please enter the subdomain.');
            }
            $parts = explode('.', $subdomain);
            if (trim($parts[0]) === '') {
                throw new BadRequest('Please enter the subdomain.');
            }
        }

        if (!$isSubscription) {
            // For non-subscription products (e.g. Custom Development, Products, Services), handle discount calculation if specified
            if ($e->get('cWonHasDiscount')) {
                $discount = 0.0;
                $price = $e->get('cWonOriginalAmount') !== null ? (float)$e->get('cWonOriginalAmount') : (float)$e->get('amount');
                $discountType = $e->get('cWonDiscountType') ?: 'Percentage';
                if ($discountType === 'Percentage') {
                    $pct = $e->get('cWonDiscountPercent');
                    if ($pct !== null && is_numeric($pct) && (float)$pct >= 0 && (float)$pct <= 100) {
                        $discount = round($price * ((float)$pct / 100), 2);
                    }
                } else if ($discountType === 'Amount') {
                    $amt = $e->get('cWonDiscountAmount');
                    if ($amt !== null && is_numeric($amt) && (float)$amt >= 0) {
                        $discount = min($price, (float)$amt);
                    }
                }
                $e->set('cWonDiscountTotal', $discount);
                $e->set('amount', max(0.0, round($price - $discount, 2)));
            }
            return;
        }

        if ($e->get('stage') === 'Closed Won' && (!$planId || !$productId)) {
            if (!$planId && $productId) {
                $plans = $this->em->getRepository('CSubscriptionPlan')->where([
                    'productId' => $productId,
                    'status' => 'Active'
                ])->find();
                if (count($plans) === 1) {
                    $singlePlan = $plans[0];
                    $planId = $singlePlan->getId();
                    $e->set('cWonPlanId', $planId);
                    $e->set('cWonPlanName', $singlePlan->get('name'));
                    if ($singlePlan->get('monthlyPrice') !== null) {
                        $e->set('cWonPlanPrice', $singlePlan->get('monthlyPrice'));
                        $e->set('cWonPlanPriceCurrency', $singlePlan->get('monthlyPriceCurrency'));
                    }
                    if ($singlePlan->get('billingPeriod')) {
                        $e->set('cWonPeriod', $singlePlan->get('billingPeriod'));
                    }
                }
            }
            if (!$planId || !$productId) {
                throw new BadRequest('Closed Won opportunities require a product and subscription plan.');
            }
        }

        if (!$planId && !$productId && !$e->getFetched('cWonPlanId') && !$e->getFetched('cWonProductId') && !$e->get('cWonHasSetupFee') && !$e->get('cWonHasDiscount')) {
            return;
        }

        if (!$planId && !$productId) {
            if ($e->get('cWonHasSetupFee')) {
                throw new BadRequest('Select a product and subscription plan before entering a setup fee.');
            }
            if ($e->get('cWonHasDiscount')) {
                throw new BadRequest('Select a product and subscription plan before applying a discount.');
            }
            if (!$e->isNew() && $e->getFetched('cWonPlanId')) {
                foreach (['cWonPlanPrice', 'cWonPeriod', 'cWonInitialTotal', 'cWonSetupFee', 'cWonDiscountTotal'] as $field) {
                    $e->set($field, null);
                }
                if ($e->get('cWonOriginalAmount') !== null) {
                    $e->set('amount', $e->get('cWonOriginalAmount'));
                    $e->set('amountCurrency', $e->get('cWonOriginalAmountCurrency'));
                }
            }
            return;
        }

        if (!$planId || !$productId) {
            throw new BadRequest('Select both a product and one of its subscription plans.');
        }

        $selectionChanged = $e->isNew() || $e->isAttributeChanged('cWonPlanId') || $e->isAttributeChanged('cWonProductId') || $e->isAttributeChanged('cProductServiceId') || $e->getFetched('cWonPlanPrice') === null;
        if ($selectionChanged) {
            $plan = $this->em->getEntityById('CSubscriptionPlan', $planId);
            $product = $this->em->getEntityById('CProductService', $productId);
            if (!$plan || !$product || $plan->get('productId') !== $productId) {
                throw new BadRequest('Select a plan belonging to the selected product.');
            }
            if (!$this->acl->checkEntityRead($plan) || !$this->acl->checkEntityRead($product)) {
                throw new Forbidden('No access to the selected product or plan.');
            }
            if ($product->get('type') !== 'Subscription' || $product->get('status') !== 'Active' || $plan->get('status') !== 'Active') {
                throw new BadRequest('Select an active subscription product and plan.');
            }
            $price = $this->money($plan->get('monthlyPrice'));
            $currency = $plan->get('monthlyPriceCurrency');
            $period = $plan->get('billingPeriod');
        } else {
            $price = $this->money($e->getFetched('cWonPlanPrice'));
            $currency = $e->getFetched('cWonPlanPriceCurrency');
            $period = $e->getFetched('cWonPeriod');
        }

        if (!$currency || !in_array($period, ['Monthly', 'Quarterly', 'Semiannual', 'Annual'], true)) {
            throw new BadRequest('The plan must have a valid currency and billing period.');
        }

        $fee = 0.0;
        if ($e->get('cWonHasSetupFee')) {
            if ($e->get('cWonSetupFee') === null) {
                throw new BadRequest('Enter the one-time fee or turn off Include Setup / One-time Fee.');
            }
            $fee = $this->money($e->get('cWonSetupFee'));
            if ($e->get('cWonSetupFeeCurrency') !== $currency) {
                throw new BadRequest('The setup fee must use the plan currency; automatic currency conversion is not supported.');
            }
        }

        // Discount calculation
        $discount = 0.0;
        if ($e->get('cWonHasDiscount')) {
            $discountType = $e->get('cWonDiscountType') ?: 'Percentage';
            if ($discountType === 'Percentage') {
                $pct = $e->get('cWonDiscountPercent');
                if ($pct === null || !is_numeric($pct) || (float)$pct < 0 || (float)$pct > 100) {
                    throw new BadRequest('Enter a valid discount percentage between 0 and 100.');
                }
                $discount = round($price * ((float)$pct / 100), 2);
            } else if ($discountType === 'Amount') {
                $amt = $e->get('cWonDiscountAmount');
                if ($amt === null || !is_numeric($amt) || (float)$amt < 0) {
                    throw new BadRequest('Enter a valid non-negative discount amount.');
                }
                if ($e->get('cWonDiscountAmountCurrency') && $e->get('cWonDiscountAmountCurrency') !== $currency) {
                    throw new BadRequest('The discount amount must use the plan currency; automatic currency conversion is not supported.');
                }
                $discount = min($price, $this->money($amt));
            }
            $e->set('cWonDiscountType', $discountType);
        }
        $discount = min($price, max(0.0, $discount));

        if (!$e->isNew() && !$e->getFetched('cWonPlanId') && $e->getFetched('cWonOriginalAmount') === null) {
            $e->set('cWonOriginalAmount', $e->getFetched('amount'));
            $e->set('cWonOriginalAmountCurrency', $e->getFetched('amountCurrency'));
        }

        $netPrice = round($price - $discount, 2);
        $total = $this->money($netPrice + $fee);

        $e->set('cWonPlanPrice', $price);
        $e->set('cWonPlanPriceCurrency', $currency);
        $e->set('cWonPeriod', $period);
        $e->set('cWonDiscountTotal', $discount);
        $e->set('cWonDiscountTotalCurrency', $currency);
        $e->set('cWonSetupFee', $e->get('cWonHasSetupFee') ? $fee : null);
        $e->set('cWonSetupFeeCurrency', $currency);
        $e->set('cWonInitialTotal', $total);
        $e->set('cWonInitialTotalCurrency', $currency);
        $e->set('amount', $total);
        $e->set('amountCurrency', $currency);
    }
}
