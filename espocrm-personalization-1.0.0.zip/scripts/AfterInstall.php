<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);


            $brandChanged = false;
            $currentAppName = (string) ($config->get('applicationName') ?? '');
            if ($currentAppName === '' || $currentAppName === 'EspoCRM') {
                $configWriter->set('applicationName', 'CGIT CRM');
                $brandChanged = true;
            }
            $currentAppDesc = (string) ($config->get('applicationDescription') ?? '');
            if ($currentAppDesc === '' || str_starts_with($currentAppDesc, 'EspoCRM')) {
                $configWriter->set('applicationDescription', 'CGIT CRM — Business & Customer Management Platform.');
                $brandChanged = true;
            }
            $currentFromName = (string) ($config->get('outboundEmailFromName') ?? '');
            if ($currentFromName === '' || $currentFromName === 'EspoCRM') {
                $configWriter->set('outboundEmailFromName', 'CGIT CRM');
                $brandChanged = true;
            }
            if ($brandChanged) {
                $configWriter->save();
            }

        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
