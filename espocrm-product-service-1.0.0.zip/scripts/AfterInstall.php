<?php

class AfterInstall
{
    public function run($container, array $params = []): void
    {
        try {
            $config = $container->getByClass(\Espo\Core\Utils\Config::class) ?? $container->get('config');
            $injectableFactory = $container->getByClass(\Espo\Core\InjectableFactory::class) ?? $container->get('injectableFactory');
            $configWriter = $injectableFactory->create(\Espo\Core\Utils\Config\ConfigWriter::class);

            $tabs = ["CProductService"];
            $insertRelativeTab = function (array $list, string $tab, array $anchors, bool $before = false): array {
                $existingIdx = null;
                foreach ($list as $k => $item) {
                    if (is_string($item) && $item === $tab) {
                        $existingIdx = $k;
                        break;
                    }
                }
                if ($existingIdx !== null) {
                    array_splice($list, $existingIdx, 1);
                }
                foreach ($anchors as $anchor) {
                    foreach ($list as $k => $item) {
                        if (is_string($item) && $item === $anchor) {
                            array_splice($list, $before ? $k : ($k + 1), 0, [$tab]);
                            return array_values($list);
                        }
                    }
                }
                foreach ($list as $k => $item) {
                    if (is_string($item) && $item === '_delimiter_') {
                        array_splice($list, $k, 0, [$tab]);
                        return array_values($list);
                    }
                }
                $list[] = $tab;
                return array_values($list);
            };
            $anchorMap = [
                'CProductService' => ['Call'],
                'CSubscriptionPlan' => ['CProductService', 'Call'],
                'CClientSubscription' => ['CSubscriptionPlan', 'CProductService', 'Call'],
            ];
            $beforeAnchorMap = [
                'ActivityMonitor' => ['Email'],
            ];

            $tabList = $config->get('tabList') ?? [];
            foreach ($tabs as $tab) {
                if (isset($beforeAnchorMap[$tab])) {
                    $tabList = $insertRelativeTab($tabList, $tab, $beforeAnchorMap[$tab], true);
                } elseif (isset($anchorMap[$tab])) {
                    $tabList = $insertRelativeTab($tabList, $tab, $anchorMap[$tab], false);
                } else {
                    $exists = false;
                    foreach ($tabList as $item) {
                        if (is_string($item) && $item === $tab) {
                            $exists = true;
                            break;
                        }
                    }
                    if (!$exists) {
                        $tabList[] = $tab;
                    }
                }
            }
            $configWriter->set('tabList', array_values($tabList));
            $configWriter->save();

            // Also place CProductService in quickCreateList right after Call if Call exists
            if (in_array('CProductService', $tabs)) {
                $qcList = $config->get('quickCreateList') ?? [];
                if (!in_array('CProductService', $qcList)) {
                    $callQcIdx = array_search('Call', $qcList);
                    if ($callQcIdx !== false) {
                        array_splice($qcList, $callQcIdx + 1, 0, ['CProductService']);
                    } else {
                        $qcList[] = 'CProductService';
                    }
                    $configWriter->set('quickCreateList', array_values($qcList));
                    $configWriter->save();
                }
            }

            // Update preferences for any user who customized tabList
            try {
                $em = $container->getByClass(\Espo\ORM\EntityManager::class) ?? $container->get('entityManager');
                if ($em && $em->hasRepository('Preferences')) {
                    $prefsList = $em->getRDBRepository('Preferences')->where(['tabList!=' => null])->find();
                    foreach ($prefsList as $pref) {
                        $pTabList = $pref->get('tabList');
                        if (is_array($pTabList)) {
                            $pChanged = false;
                            foreach ($tabs as $tab) {
                                if (isset($anchorMap[$tab])) {
                                    $pTabList = $insertAfterTab($pTabList, $tab, $anchorMap[$tab]);
                                    $pChanged = true;
                                }
                            }
                            if ($pChanged) {
                                $pref->set('tabList', array_values($pTabList));
                                $em->saveEntity($pref);
                            }
                        }
                    }
                }
            } catch (\Throwable $e) {}


        } catch (\Throwable $e) {
            // Silently continue
        }
    }
}
