define('custom:controllers/lead', ['modules/crm/controllers/lead'], function (Dep) {

    return Dep.extend({

        actionConvert: function (options) {
            this.main('custom:views/lead/convert', {
                id: options.id
            });
        }

    });

});
