define('custom:views/lead/record/edit-small', ['custom:views/lead/record/edit'], function (Dep) {

    Dep = Dep && Dep.default ? Dep.default : Dep;

    return Dep.extend({});

});
